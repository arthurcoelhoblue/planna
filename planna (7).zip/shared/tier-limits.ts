/**
 * PATCH 8.8.0 - Tier Limits
 * 
 * Definição centralizada de limites e recursos por tier de assinatura.
 * Usado tanto no backend (enforcement) quanto no frontend (UI locks).
 */

export type SubscriptionTier = "free" | "pro" | "premium" | "vip";

export interface TierLimits {
  maxPlansPerMonth: number;
  maxServings: number;
  maxVarieties: number;
  allowAdvancedModes: boolean;
  allowRegenerateDish: boolean;
  allowRegenerateList: boolean;
  maxIngredientDetectionsPerMonth: number;
  allowVersionHistory: boolean;
  // PATCH 9.3.0: Exportação de lista de compras
  allowExportCsv: boolean;
  allowExportXlsx: boolean;
  // PATCH 9.6.0: Compartilhamento de plano
  allowShare: boolean;
  // PATCH 9.6.0: Exportação de PDF de lista de compras
  allowExportShoppingListPdf: boolean;
}

export const TIER_LIMITS: Record<SubscriptionTier, TierLimits> = {
  free: {
    maxPlansPerMonth: 2,
    maxServings: 10,
    maxVarieties: 3,
    allowAdvancedModes: false,
    allowRegenerateDish: false,
    allowRegenerateList: false,
    maxIngredientDetectionsPerMonth: 3,
    allowVersionHistory: false,
    allowExportCsv: true,
    allowExportXlsx: false,
    allowShare: false,
    allowExportShoppingListPdf: false,
  },
  pro: {
    maxPlansPerMonth: 10,
    maxServings: 20,
    maxVarieties: 6,
    allowAdvancedModes: true,
    allowRegenerateDish: true,
    allowRegenerateList: true,
    maxIngredientDetectionsPerMonth: 30,
    allowVersionHistory: true,
    allowExportCsv: true,
    allowExportXlsx: true,
    allowShare: false,
    allowExportShoppingListPdf: true,
  },
  premium: {
    maxPlansPerMonth: Infinity,
    maxServings: 20,
    maxVarieties: 6,
    allowAdvancedModes: true,
    allowRegenerateDish: true,
    allowRegenerateList: true,
    maxIngredientDetectionsPerMonth: Infinity,
    allowVersionHistory: true,
    allowExportCsv: true,
    allowExportXlsx: true,
    allowShare: true,
    allowExportShoppingListPdf: true,
  },
  vip: {
    // VIP = Premium turbo (sem limites)
    maxPlansPerMonth: Infinity,
    maxServings: 20,
    maxVarieties: 6,
    allowAdvancedModes: true,
    allowRegenerateDish: true,
    allowRegenerateList: true,
    maxIngredientDetectionsPerMonth: Infinity,
    allowVersionHistory: true,
    allowExportCsv: true,
    allowExportXlsx: true,
    allowShare: true,
    allowExportShoppingListPdf: true,
  },
} as const;

/**
 * Helper para obter limites de um tier específico
 */
export function getTierLimits(tier: SubscriptionTier): TierLimits {
  return TIER_LIMITS[tier];
}

/**
 * Helper para verificar se um tier tem acesso a um recurso
 */
export function canAccessFeature(
  tier: SubscriptionTier,
  feature: keyof TierLimits
): boolean {
  const limits = TIER_LIMITS[tier];
  const value = limits[feature];
  
  // Para booleanos, retorna direto
  if (typeof value === "boolean") {
    return value;
  }
  
  // Para números, verifica se é > 0
  if (typeof value === "number") {
    return value > 0;
  }
  
  return false;
}

/**
 * Helper para verificar se um tier atingiu um limite numérico
 */
export function hasReachedLimit(
  tier: SubscriptionTier,
  feature: keyof TierLimits,
  currentUsage: number
): boolean {
  const limits = TIER_LIMITS[tier];
  const maxValue = limits[feature];
  
  // Se não for número, não há limite numérico
  if (typeof maxValue !== "number") {
    return false;
  }
  
  // Infinity nunca é atingido
  if (maxValue === Infinity) {
    return false;
  }
  
  return currentUsage >= maxValue;
}

/**
 * Descrições de cada tier para exibição na UI
 */
export const TIER_DESCRIPTIONS: Record<SubscriptionTier, string> = {
  free: "Plano gratuito para experimentar o Planna",
  pro: "Para quem cozinha toda semana",
  premium: "Para quem vive de marmita / família / casal fitness",
  vip: "Acesso ilimitado e prioritário",
};

/**
 * Nomes de exibição dos tiers
 */
export const TIER_LABELS: Record<SubscriptionTier, string> = {
  free: "Gratuito",
  pro: "Pro",
  premium: "Premium",
  vip: "VIP",
};
