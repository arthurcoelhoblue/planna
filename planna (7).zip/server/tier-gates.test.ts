/**
 * PATCH 9.6.0 - Testes de gates de tier
 * 
 * Valida que os gates de tier estão funcionando corretamente:
 * - Free não regenera
 * - Free não dá feedback
 * - Free/Pro não compartilham
 * - Premium não faz downgrade para Pro
 */

import { describe, it, expect } from "vitest";
import { canAccessFeature, TIER_LIMITS } from "../shared/tier-limits";

describe("Tier Gates - PATCH 9.6.0", () => {
  describe("Correção 2: Free não regenera", () => {
    it("Free não pode regenerar pratos", () => {
      const canRegenerate = canAccessFeature("free", "allowRegenerateDish");
      expect(canRegenerate).toBe(false);
    });

    it("Pro pode regenerar pratos", () => {
      const canRegenerate = canAccessFeature("pro", "allowRegenerateDish");
      expect(canRegenerate).toBe(true);
    });

    it("Premium pode regenerar pratos", () => {
      const canRegenerate = canAccessFeature("premium", "allowRegenerateDish");
      expect(canRegenerate).toBe(true);
    });

    it("VIP pode regenerar pratos", () => {
      const canRegenerate = canAccessFeature("vip", "allowRegenerateDish");
      expect(canRegenerate).toBe(true);
    });
  });

  describe("Correção 7: Compartilhar exclusivo Premium/VIP", () => {
    it("Free não pode compartilhar", () => {
      const canShare = canAccessFeature("free", "allowShare");
      expect(canShare).toBe(false);
    });

    it("Pro não pode compartilhar", () => {
      const canShare = canAccessFeature("pro", "allowShare");
      expect(canShare).toBe(false);
    });

    it("Premium pode compartilhar", () => {
      const canShare = canAccessFeature("premium", "allowShare");
      expect(canShare).toBe(true);
    });

    it("VIP pode compartilhar", () => {
      const canShare = canAccessFeature("vip", "allowShare");
      expect(canShare).toBe(true);
    });
  });

  describe("Correção 8: Export PDF Premium", () => {
    it("Free não pode exportar PDF", () => {
      const canExportPdf = canAccessFeature("free", "allowExportShoppingListPdf");
      expect(canExportPdf).toBe(false);
    });

    it("Pro pode exportar PDF", () => {
      const canExportPdf = canAccessFeature("pro", "allowExportShoppingListPdf");
      expect(canExportPdf).toBe(true);
    });

    it("Premium pode exportar PDF", () => {
      const canExportPdf = canAccessFeature("premium", "allowExportShoppingListPdf");
      expect(canExportPdf).toBe(true);
    });

    it("VIP pode exportar PDF", () => {
      const canExportPdf = canAccessFeature("vip", "allowExportShoppingListPdf");
      expect(canExportPdf).toBe(true);
    });
  });

  describe("TIER_LIMITS structure validation", () => {
    it("deve ter todos os tiers definidos", () => {
      expect(TIER_LIMITS.free).toBeDefined();
      expect(TIER_LIMITS.pro).toBeDefined();
      expect(TIER_LIMITS.premium).toBeDefined();
      expect(TIER_LIMITS.vip).toBeDefined();
    });

    it("deve ter allowShare definido para todos os tiers", () => {
      expect(TIER_LIMITS.free.allowShare).toBe(false);
      expect(TIER_LIMITS.pro.allowShare).toBe(false);
      expect(TIER_LIMITS.premium.allowShare).toBe(true);
      expect(TIER_LIMITS.vip.allowShare).toBe(true);
    });

    it("deve ter allowExportShoppingListPdf definido para todos os tiers", () => {
      expect(TIER_LIMITS.free.allowExportShoppingListPdf).toBe(false);
      expect(TIER_LIMITS.pro.allowExportShoppingListPdf).toBe(true);
      expect(TIER_LIMITS.premium.allowExportShoppingListPdf).toBe(true);
      expect(TIER_LIMITS.vip.allowExportShoppingListPdf).toBe(true);
    });

    it("deve ter allowRegenerateDish definido para todos os tiers", () => {
      expect(TIER_LIMITS.free.allowRegenerateDish).toBe(false);
      expect(TIER_LIMITS.pro.allowRegenerateDish).toBe(true);
      expect(TIER_LIMITS.premium.allowRegenerateDish).toBe(true);
      expect(TIER_LIMITS.vip.allowRegenerateDish).toBe(true);
    });
  });

  describe("Correção 5: Hierarquia de tiers", () => {
    it("Free é o tier mais baixo", () => {
      const freeLimits = TIER_LIMITS.free;
      expect(freeLimits.maxPlansPerMonth).toBe(2);
      expect(freeLimits.allowAdvancedModes).toBe(false);
      expect(freeLimits.allowRegenerateDish).toBe(false);
      expect(freeLimits.allowShare).toBe(false);
    });

    it("Pro tem mais recursos que Free", () => {
      const proLimits = TIER_LIMITS.pro;
      expect(proLimits.maxPlansPerMonth).toBeGreaterThan(TIER_LIMITS.free.maxPlansPerMonth);
      expect(proLimits.allowAdvancedModes).toBe(true);
      expect(proLimits.allowRegenerateDish).toBe(true);
    });

    it("Premium tem mais recursos que Pro", () => {
      const premiumLimits = TIER_LIMITS.premium;
      expect(premiumLimits.maxPlansPerMonth).toBe(Infinity);
      expect(premiumLimits.allowShare).toBe(true);
      expect(TIER_LIMITS.pro.allowShare).toBe(false);
    });

    it("VIP tem todos os recursos do Premium", () => {
      const vipLimits = TIER_LIMITS.vip;
      const premiumLimits = TIER_LIMITS.premium;
      
      expect(vipLimits.maxPlansPerMonth).toBe(premiumLimits.maxPlansPerMonth);
      expect(vipLimits.allowShare).toBe(premiumLimits.allowShare);
      expect(vipLimits.allowRegenerateDish).toBe(premiumLimits.allowRegenerateDish);
    });
  });
});
