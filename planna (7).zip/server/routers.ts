import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { TRPCError } from "@trpc/server"; // PATCH 8.5.0: Para erros tipados
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    // PATCH 8.2.0: Retornar objeto estruturado para mobile
    // PATCH 8.3.0: Incluir subscriptionTier unificado
    me: publicProcedure.query(async ({ ctx }) => {
      if (!ctx.user) {
        return null; // Não autenticado
      }

      // Get unified tier from all sources
      const { getUserTier } = await import("./_core/subscription-tier");
      const subscriptionTier = await getUserTier(ctx.user.id);

      return {
        id: ctx.user.id,
        email: ctx.user.email,
        name: ctx.user.name,
        subscriptionTier,
        isAdmin: ctx.user.role === "admin",
        emailVerified: ctx.user.emailVerified,
      };
    }),
    
    // PATCH 8.2.0: Logout idempotente para web/mobile
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),

    // Local authentication (email/password) with 2FA
    registerLocal: publicProcedure
      .input(
        z.object({
          name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
          email: z.string().email("Email inválido"),
          password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
          source: z.string().max(64).optional(), // PATCH 8.1.0: Acquisition source
        })
      )
      .mutation(async ({ ctx, input }) => {
        // PATCH 8.4.1: Rate limit (3 registros por minuto por IP)
        const { assertRateLimit } = await import("./_core/rateLimit");
        const ip = ctx.ip ?? "unknown";
        await assertRateLimit(`auth:register:${ip}`, {
          windowMs: 60_000,
          max: 3,
        });
        const { getDb } = await import("./db");
        const { hashPassword } = await import("./_core/passwords");
        const { users, emailVerificationCodes } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const { generateVerificationCode, sendVerificationEmail } = await import("./_core/emailVerification");

        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Check if email already exists
        const existing = await db
          .select()
          .from(users)
          .where(eq(users.email, input.email))
          .limit(1);

        if (existing.length > 0) {
          throw new Error("Já existe um usuário com esse e-mail");
        }

        // Hash password
        const passwordHash = await hashPassword(input.password);

        // Generate internal openId for local users
        const openId = `local_${crypto.randomUUID()}`;

        // Insert user (pending verification)
        const [newUser] = await db.insert(users).values({
          openId,
          name: input.name,
          email: input.email,
          passwordHash,
          loginMethod: "local",
          emailVerified: false, // Pending verification
          source: (input.source && input.source.trim()) || "unknown", // PATCH 8.1.0
        }).$returningId();

        // Generate verification code
        const code = generateVerificationCode();
        const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes

        // Save code to database
        await db.insert(emailVerificationCodes).values({
          userId: newUser.id,
          code,
          expiresAt,
          verified: false,
        });

        // Send verification email
        const emailSent = await sendVerificationEmail(input.email, code, input.name);

        if (!emailSent) {
          console.error("[Auth] Failed to send verification email");
          // Don't throw error, allow user to resend
        }

        return { 
          success: true, 
          userId: newUser.id,
          email: input.email,
          message: "Código de verificação enviado para seu e-mail" 
        };
      }),

    verifyEmailCode: publicProcedure
      .input(
        z.object({
          userId: z.number(),
          code: z.string().length(6, "Código deve ter 6 dígitos"),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // PATCH 8.4.1: Rate limit (5 tentativas por minuto por IP)
        const { assertRateLimit } = await import("./_core/rateLimit");
        await assertRateLimit(`auth:verify:${ctx.ip}`, {
          windowMs: 60_000,
          max: 5,
        });
        const { getDb } = await import("./db");
        const { users, emailVerificationCodes } = await import("../drizzle/schema");
        const { eq, and, gt } = await import("drizzle-orm");
        const { sdk } = await import("./_core/sdk");

        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Find valid code
        const codes = await db
          .select()
          .from(emailVerificationCodes)
          .where(
            and(
              eq(emailVerificationCodes.userId, input.userId),
              eq(emailVerificationCodes.code, input.code),
              eq(emailVerificationCodes.verified, false),
              gt(emailVerificationCodes.expiresAt, new Date())
            )
          )
          .limit(1);

        if (codes.length === 0) {
          throw new Error("Código inválido ou expirado");
        }

        // Mark code as verified
        await db
          .update(emailVerificationCodes)
          .set({ verified: true })
          .where(eq(emailVerificationCodes.id, codes[0].id));

        // Mark user as verified
        await db
          .update(users)
          .set({ emailVerified: true })
          .where(eq(users.id, input.userId));

        // Get user data
        const [user] = await db
          .select()
          .from(users)
          .where(eq(users.id, input.userId))
          .limit(1);

        if (!user) throw new Error("Usuário não encontrado");

        // Create session
        const token = await sdk.createSessionToken(user.openId, {
          name: user.name || "",
        });

        const cookieOptions = getSessionCookieOptions(ctx.req);
        const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1000;
        ctx.res.cookie(COOKIE_NAME, token, {
          ...cookieOptions,
          maxAge: ONE_YEAR_MS,
        });

        // PATCH 8.2.0: Retornar sessionJwt para mobile
        return { 
          success: true, 
          needsOnboarding: true,
          sessionJwt: token, // mesmo JWT que vai no cookie planna_session
        };
      }),

    resendVerificationCode: publicProcedure
      .input(
        z.object({
          userId: z.number(),
        }),
      )
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { users, emailVerificationCodes } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const { generateVerificationCode, sendVerificationEmail } = await import(
          "./_core/emailVerification"
        );

        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Buscar usuário
        const [user] = await db
          .select()
          .from(users)
          .where(eq(users.id, input.userId))
          .limit(1);

        if (!user || !user.email) {
          throw new Error("Usuário não encontrado");
        }

        // 👉 DIFERENTE DO CÓDIGO ANTIGO:
        // NÃO bloqueamos mais se emailVerified = true,
        // porque agora esse endpoint também serve para login com 2FA.

        // Gerar novo código
        const code = generateVerificationCode();
        const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutos

        // Salvar novo código
        await db.insert(emailVerificationCodes).values({
          userId: user.id,
          code,
          expiresAt,
          verified: false,
        });

        // Enviar e-mail
        const emailSent = await sendVerificationEmail(
          user.email,
          code,
          user.name || undefined,
        );

        if (!emailSent) {
          throw new Error("Falha ao enviar e-mail. Tente novamente.");
        }

        return {
          success: true,
          message: "Novo código enviado para seu e-mail",
        };
      }),

    // 🔐 LOGIN EM 2 ETAPAS (1: senha + envio de código)
    loginStart: publicProcedure
      .input(
        z.object({
          email: z.string().email("Email inválido"),
          password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        // PATCH 8.4.1: Rate limit (5 tentativas por minuto por IP)
        const { assertRateLimit } = await import("./_core/rateLimit");
        await assertRateLimit(`auth:login:${ctx.ip}`, {
          windowMs: 60_000,
          max: 5,
        });
        const { getDb } = await import("./db");
        const { verifyPassword } = await import("./_core/passwords");
        const { users, emailVerificationCodes } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const { generateVerificationCode, sendVerificationEmail } = await import(
          "./_core/emailVerification"
        );

        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // 1) Buscar usuário pelo e-mail
        const existing = await db
          .select()
          .from(users)
          .where(eq(users.email, input.email))
          .limit(1);

        const user = existing[0];

        if (!user || user.loginMethod !== "local" || !user.passwordHash) {
          throw new Error("Usuário ou senha inválidos");
        }

        // Validar que o email existe
        if (!user.email) {
          throw new Error("Usuário sem email cadastrado");
        }

        // 2) Verificar senha
        const ok = await verifyPassword(input.password, user.passwordHash);
        if (!ok) {
          throw new Error("Usuário ou senha inválidos");
        }

        // 3) (opcional) Atualizar lastSignedIn só depois do login completo,
        // mas se você quiser manter aqui, tudo bem. Eu sugiro manter no verifyEmailCode
        // para garantir que o login só é considerado completo após o 2FA.

        // 4) Gerar código de 2FA para LOGIN
        const code = generateVerificationCode();
        const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutos

        await db.insert(emailVerificationCodes).values({
          userId: user.id,
          code,
          expiresAt,
          verified: false,
        });

        // 5) Enviar e-mail com código
        const emailSent = await sendVerificationEmail(
          user.email,
          code,
          user.name || undefined,
        );

        if (!emailSent) {
          console.error("[Auth] Failed to send login 2FA email");
          throw new Error(
            "Não foi possível enviar o código de verificação. Tente novamente em alguns instantes.",
          );
        }

        // 6) NÃO cria sessão aqui – sessão só é criada em verifyEmailCode
        // depois do usuário informar o código.
        return {
          success: true,
          userId: user.id,
          email: user.email,
          message: "Código de login enviado para seu e-mail",
        };
      }),

    // Password reset
    requestPasswordReset: publicProcedure
      .input(
        z.object({
          email: z.string().email(),
        })
      )
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { users, passwordResetTokens } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const { sendPasswordResetEmail } = await import("./_core/email");

        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Find user by email
        const existing = await db
          .select()
          .from(users)
          .where(eq(users.email, input.email))
          .limit(1);

        const user = existing[0];
        if (!user || user.loginMethod !== "local" || !user.email) {
          // Don't reveal if email exists or not (security)
          return { success: true };
        }

        // Generate reset token
        const token = crypto.randomUUID().replace(/-/g, "");
        const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

        // Save token
        await db.insert(passwordResetTokens).values({
          userId: user.id,
          token,
          expiresAt,
        });

        // Send password reset email
        const resetUrl = `${process.env.VITE_APP_URL || "http://localhost:3000"}/reset-password?token=${token}`;
        const emailSent = await sendPasswordResetEmail(user.email, resetUrl, user.name || undefined);
        
        if (!emailSent) {
          console.warn("[PasswordReset] Failed to send email, but token was created");
        }

        return { success: true };
      }),

    resetPassword: publicProcedure
      .input(
        z.object({
          token: z.string(),
          newPassword: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
        })
      )
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { hashPassword } = await import("./_core/passwords");
        const { users, passwordResetTokens } = await import("../drizzle/schema");
        const { eq, and } = await import("drizzle-orm");

        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Find token
        const tokenResult = await db
          .select()
          .from(passwordResetTokens)
          .where(
            and(
              eq(passwordResetTokens.token, input.token),
              eq(passwordResetTokens.used, "no")
            )
          )
          .limit(1);

        const tokenRecord = tokenResult[0];
        if (!tokenRecord) {
          throw new Error("Token inválido ou já utilizado");
        }

        // Check if expired
        if (new Date() > tokenRecord.expiresAt) {
          throw new Error("Token expirado");
        }

        // Hash new password
        const passwordHash = await hashPassword(input.newPassword);

        // Update user password
        await db
          .update(users)
          .set({ passwordHash })
          .where(eq(users.id, tokenRecord.userId));

        // Mark token as used
        await db
          .update(passwordResetTokens)
          .set({ used: "yes" })
          .where(eq(passwordResetTokens.id, tokenRecord.id));

        return { success: true };
      }),
  }),

  // Planna routers
  ingredients: router({
    parse: publicProcedure
      .input(z.object({ text: z.string() }))
      .mutation(async ({ input }) => {
        const { parseIngredients } = await import("./ingredients-dictionary");
        return parseIngredients(input.text);
      }),
    suggestions: publicProcedure
      .input(z.object({ partial: z.string(), limit: z.number().optional() }))
      .query(async ({ input }) => {
        const { getSuggestions } = await import("./ingredients-dictionary");
        return getSuggestions(input.partial, input.limit);
      }),
    detectFromImage: protectedProcedure
      .input(
        z.object({
          imageUrl: z.string().url(),
          location: z.enum(["geladeira", "congelador", "armario"]).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // PATCH 8.4.1: Rate limit (10 detecções por minuto por usuário)
        const { assertRateLimit } = await import("./_core/rateLimit");
        await assertRateLimit(`ingredients:detect:${ctx.user.id}`, {
          windowMs: 60_000,
          max: 10,
        });
        const { detectIngredientsFromImage } = await import("./image-detection");
        const ingredients = await detectIngredientsFromImage({
          imageUrl: input.imageUrl,
          location: input.location,
        });
        return { ingredients };
      }),
    detectFromMultipleImages: protectedProcedure
      .input(
        z.object({
          images: z.array(
            z.object({
              url: z.string().url(),
            })
          ),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // PATCH 8.4.1: Rate limit (10 detecções por minuto por usuário)
        const { assertRateLimit } = await import("./_core/rateLimit");
        await assertRateLimit(`ingredients:detectMultiple:${ctx.user.id}`, {
          windowMs: 60_000,
          max: 10,
        });
        const { detectIngredientsFromMultipleImages } = await import("./image-detection");
        const ingredients = await detectIngredientsFromMultipleImages(input.images);
        return { ingredients };
      }),
  }),

  mealPlan: router({
    generate: protectedProcedure
      .input(
        z.object({
          ingredients: z.string(),
          servings: z.number().min(1).max(20),
          exclusions: z.array(z.string()).optional(),
          objective: z.enum(["normal", "aproveitamento", "lowcal", "highprotein"]).optional(),
          varieties: z.number().min(1).max(6).optional(),
          allowNewIngredients: z.boolean().optional(),
          sophistication: z.enum(["simples", "gourmet"]).optional(),
          calorieLimit: z.number().min(200).max(2000).optional(),
          skillLevel: z.enum(["beginner", "intermediate", "advanced"]).optional(),
          availableTime: z.number().min(1).max(24).optional(),
          dietType: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // PATCH 8.4.1: Rate limit (3 gerações por minuto por usuário)
        const { assertRateLimit } = await import("./_core/rateLimit");
        await assertRateLimit(`mealPlan:generate:${ctx.user.id}`, {
          windowMs: 60_000,
          max: 3,
        });

        const { getUserPreference, getUserDishFeedback } = await import("./db");
        const { createAndStorePlan } = await import("./_core/meal-plan");

        // 1) Preferências do usuário + feedback em pratos
        const userPref = await getUserPreference(ctx.user.id);
        const feedback = await getUserDishFeedback(ctx.user.id);

        const userFavorites = userPref?.favorites
          ? JSON.parse(userPref.favorites)
          : [];

        const userDislikes = feedback
          .filter(f => f.rating === "disliked")
          .map(f => f.dishName);

        const userExclusions = userPref?.exclusions
          ? JSON.parse(userPref.exclusions)
          : [];

        // PATCH 8.8.0: Enforcement de limites por tier
        const { getUserTier } = await import("./_core/subscription-tier");
        const { getTierLimits, hasReachedLimit } = await import("../shared/tier-limits");
        const { countUserPlansThisMonth } = await import("./db");

        const tier = await getUserTier(ctx.user.id);
        const limits = getTierLimits(tier);
        const usedThisMonth = await countUserPlansThisMonth(ctx.user.id);

        // Verificar limite de planos por mês
        if (hasReachedLimit(tier, "maxPlansPerMonth", usedThisMonth)) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Você atingiu o limite de planos do seu plano atual. Faça upgrade para criar mais planos!",
          });
        }

        // Clamp de parâmetros por tier
        const clampedServings = Math.min(
          input.servings ?? limits.maxServings,
          limits.maxServings
        );
        
        const clampedVarieties = Math.min(
          input.varieties ?? limits.maxVarieties,
          limits.maxVarieties
        );
        
        // Modos avançados só se allowAdvancedModes
        const allowedMode = limits.allowAdvancedModes
          ? input.objective ?? "normal"
          : "normal";

        // Criar input ajustado com limites aplicados
        const adjustedInput = {
          ...input,
          servings: clampedServings,
          varieties: clampedVarieties,
          objective: allowedMode,
        };

        // 3) Usar função reutilizável com input ajustado
        const result = await createAndStorePlan({
          userId: ctx.user.id,
          input: adjustedInput,
          userPreferences: {
            favorites: userFavorites,
            exclusions: userExclusions,
            skillLevel: userPref?.skillLevel || undefined,
            dietType: userPref?.dietType || undefined,
          },
          userDislikes,
        });

        return {
          planId: result.id,
          sessionId: result.sessionId,
          plan: result,
        };
      }),

    // PATCH 7.9.0: Endpoint para geração anônima (1 plano gratis sem login)
    generateAnonymousPlan: publicProcedure
      .input(
        z.object({
          anonymousId: z.string().min(1),
          source: z.string().max(64).optional(), // PATCH 8.1.0: Acquisition source
          payload: z.object({
            ingredients: z.string(),
            servings: z.number().min(1).max(20),
            exclusions: z.array(z.string()).optional(),
            objective: z.enum(["normal", "aproveitamento", "lowcal", "highprotein"]).optional(),
            varieties: z.number().min(1).max(6).optional(),
            allowNewIngredients: z.boolean().optional(),
            sophistication: z.enum(["simples", "gourmet"]).optional(),
            calorieLimit: z.number().min(200).max(2000).optional(),
            skillLevel: z.enum(["beginner", "intermediate", "advanced"]).optional(),
            availableTime: z.number().min(1).max(24).optional(),
            dietType: z.string().optional(),
          }),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // PATCH 8.4.1: Rate limit (2 gerações por minuto por anonymousId)
        const { assertRateLimit } = await import("./_core/rateLimit");
        await assertRateLimit(`mealPlan:generateAnon:${input.anonymousId}`, {
          windowMs: 60_000,
          max: 2,
        });

        const { anonymousId, payload } = input;
        
        // PATCH 8.7.0: Aplicar limitações de plano anônimo
        const { ANONYMOUS_LIMITS } = await import("../shared/free-trial");
        
        const clampedServings = Math.min(
          payload.servings ?? ANONYMOUS_LIMITS.maxServings,
          ANONYMOUS_LIMITS.maxServings
        );
        
        const clampedVarieties = Math.min(
          payload.varieties ?? ANONYMOUS_LIMITS.maxVarieties,
          ANONYMOUS_LIMITS.maxVarieties
        );
        
        const mode = ANONYMOUS_LIMITS.allowedModes.includes(payload.objective as any)
          ? payload.objective
          : "normal";
        
        const sophistication = ANONYMOUS_LIMITS.allowAdvancedSophistication
          ? payload.sophistication ?? "simples"
          : "simples";
        
        const clampedPayload = {
          ...payload,
          objective: mode,
          servings: clampedServings,
          varieties: clampedVarieties,
          sophistication,
        };
        const db = await import("./db").then(m => m.getDb());
        const { anonymousPlans } = await import("../drizzle/schema");
        const { eq, count } = await import("drizzle-orm");
        const { createAndStorePlan } = await import("./_core/meal-plan");
        const { TRPCError } = await import("@trpc/server");

        if (!db) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Database not available",
          });
        }

        // 1) Checar quantos planos esse anonymousId já gerou
        const [row] = await db
          .select({ total: count() })
          .from(anonymousPlans)
          .where(eq(anonymousPlans.anonymousId, anonymousId))
          .limit(1);

        const total = row?.total ?? 0;

        if (total >= 1) {
          // 2) Limite atingido
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "LIMIT_REACHED",
          });
        }

        // 3) Gerar plano usando a MESMA lógica do usuário logado (com payload limitado)
        const plan = await createAndStorePlan({
          userId: null, // plano órfão
          input: clampedPayload,
        });

        // 4) Gravar em anonymous_plans com source
        await db.insert(anonymousPlans).values({
          anonymousId,
          planId: plan.id,
          source: (input.source && input.source.trim()) || "unknown", // PATCH 8.1.0
        });

        // 5) Retornar o plano (com flag isAnonymous)
        return {
          planId: plan.id,
          sessionId: plan.sessionId,
          plan: {
            ...plan,
            isAnonymous: true, // PATCH 8.7.0: Flag para UI
          },
        };
      }),

    getById: protectedProcedure
      .input(z.object({ planId: z.number() }))
      .query(async ({ ctx, input }) => {
        const { getPlanById } = await import("./db");
        const plan = await getPlanById(input.planId);
        if (!plan) return null;

        return {
          ...plan,
          dishes: JSON.parse(plan.dishes),
          shoppingList: JSON.parse(plan.shoppingList),
          prepSchedule: JSON.parse(plan.prepSchedule),
        };
      }),

    getHistory: protectedProcedure.query(async ({ ctx }) => {
      const { getUserSessions } = await import("./db");
      return getUserSessions(ctx.user.id);
    }),

    // PATCH 8.4.0: Soft delete de plano
    delete: protectedProcedure
      .input(z.object({ planId: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        const { TRPCError } = await import("@trpc/server");
        const { getDb } = await import("./db");
        const { plans } = await import("../drizzle/schema");
        const { and, eq, isNull } = await import("drizzle-orm");

        const db = await getDb();
        if (!db) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Database not available",
          });
        }

        // 1) Garantir ownership e não deletado
        const [plan] = await db
          .select()
          .from(plans)
          .where(
            and(
              eq(plans.id, input.planId),
              isNull(plans.deletedAt)
            )
          )
          .limit(1);

        if (!plan) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Plano não encontrado.",
          });
        }

        // Verificar ownership via sessionId
        const { sessions } = await import("../drizzle/schema");
        const [session] = await db
          .select()
          .from(sessions)
          .where(eq(sessions.id, plan.sessionId))
          .limit(1);

        if (!session || session.userId !== ctx.user.id) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Plano não encontrado.",
          });
        }

        // 2) Soft delete
        await db
          .update(plans)
          .set({ deletedAt: new Date() })
          .where(eq(plans.id, input.planId));

        return { success: true };
      }),

    exportPDF: protectedProcedure
      .input(z.object({ planId: z.number() }))
      .mutation(async ({ input }) => {
        const { getPlanById } = await import("./db");
        const { generatePlanHTML } = await import("./pdf-exporter");
        
        const plan = await getPlanById(input.planId);
        if (!plan) {
          throw new Error("Plano não encontrado");
        }

        const mealPlan = {
          dishes: JSON.parse(plan.dishes),
          shoppingList: JSON.parse(plan.shoppingList),
          prepSchedule: JSON.parse(plan.prepSchedule),
          estimatedCost: "médio" as const,
          totalPrepTime: 90,
        };

        const html = generatePlanHTML(mealPlan);
        return { html };
      }),

    getWhatsAppText: protectedProcedure
      .input(z.object({ planId: z.number() }))
      .query(async ({ ctx, input }) => {
        // PATCH 9.6.0: Gate por tier (apenas Premium/VIP podem compartilhar)
        const { getUserTier } = await import("./_core/subscription-tier");
        const { canAccessFeature } = await import("../shared/tier-limits");
        const { TRPCError } = await import("@trpc/server");

        const tier = await getUserTier(ctx.user.id);
        
        if (!canAccessFeature(tier, "allowShare")) {
          console.log(`[upgrade-opportunity] user=${ctx.user.id} reason=feature_locked_share tier=${tier}`);
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Compartilhar planos é exclusivo dos planos Premium e VIP. Faça upgrade para liberar este recurso.",
          });
        }

        const { getPlanById } = await import("./db");
        
        const plan = await getPlanById(input.planId);
        if (!plan) {
          throw new Error("Plano não encontrado");
        }

        const dishes = JSON.parse(plan.dishes);
        const shoppingList = JSON.parse(plan.shoppingList);

        let text = "🍱 *MEU PLANO SEMANAL DE MARMITAS*\n";
        text += `Gerado por Planna em ${new Date(plan.createdAt).toLocaleDateString("pt-BR")}\n\n`;

        text += "📋 *CARDÁPIO:*\n";
        dishes.forEach((dish: any, i: number) => {
          text += `${i + 1}. ${dish.name} (${dish.servings} porções)\n`;
        });

        text += "\n🛒 *LISTA DE COMPRAS:*\n";
        const grouped = shoppingList.reduce((acc: any, item: any) => {
          if (!acc[item.category]) acc[item.category] = [];
          acc[item.category].push(item);
          return acc;
        }, {});

        Object.entries(grouped).forEach(([category, items]: [string, any]) => {
          text += `\n*${category}:*\n`;
          items.forEach((item: any) => {
            text += `☐ ${item.item} - ${item.quantity} ${item.unit}\n`;
          });
        });

        return { text };
      }),

    regenerateDish: protectedProcedure
      .input(
        z.object({
          planId: z.number(),
          dishIndex: z.number().min(0),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // PATCH 8.8.0: Gate por tier
        const { getUserTier } = await import("./_core/subscription-tier");
        const { canAccessFeature } = await import("../shared/tier-limits");

        const tier = await getUserTier(ctx.user.id);
        
        if (!canAccessFeature(tier, "allowRegenerateDish")) {
          console.log(`[upgrade-opportunity] user=${ctx.user.id} reason=feature_locked_regen_dish tier=${tier}`);
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Seu plano atual não permite regenerar pratos. Faça upgrade para liberar este recurso.",
          });
        }

        const { getPlanById, updatePlan } = await import("./db");
        const { regenerateDish } = await import("./_core/llm");
        const { saveNewPlanVersion } = await import("./_core/planVersion");

        // 1) Buscar o plano atual no banco
        const plan = await getPlanById(input.planId);
        if (!plan) {
          throw new Error("Plano não encontrado");
        }

        // 2) Extrair a lista de pratos
        const dishes = JSON.parse(plan.dishes);
        
        // 3) Validar índice do prato
        if (input.dishIndex >= dishes.length) {
          throw new Error("Prato não encontrado");
        }

        const oldDish = dishes[input.dishIndex];

        // 4) Regenerar o prato usando o LLM (PATCH 7.3.0: passa mode do plano)
        let newDish;
        try {
          newDish = await regenerateDish(oldDish, plan.mode || undefined);
        } catch (error) {
          console.error("[regenerateDish] LLM error:", error);
          throw new Error("Erro ao regenerar prato. Tente novamente.");
        }

        // 5) Substituir o prato antigo pelo novo
        dishes[input.dishIndex] = newDish;

        // 6) Atualizar o plano no banco
        await updatePlan(input.planId, {
          dishes: JSON.stringify(dishes),
        });

        // 7) Criar uma nova versão do plano
        const newVersion = await saveNewPlanVersion(input.planId, {
          dishes: dishes,
          shoppingList: JSON.parse(plan.shoppingList),
          prepSchedule: plan.prepSchedule ? JSON.parse(plan.prepSchedule) : undefined,
          usedStock: plan.usedStock ? JSON.parse(plan.usedStock) : undefined,
          remainingStock: plan.remainingStock ? JSON.parse(plan.remainingStock) : undefined,
          substitutions: plan.substitutions ? JSON.parse(plan.substitutions) : undefined,
        });

        // 8) Retornar resultado
        return {
          ok: true,
          newPlan: {
            ...plan,
            dishes,
            shoppingList: JSON.parse(plan.shoppingList),
            prepSchedule: plan.prepSchedule ? JSON.parse(plan.prepSchedule) : undefined,
          },
          newVersion: {
            id: newVersion.id,
            version: newVersion.version,
          },
          diff: {
            oldDish,
            newDish,
          },
        };
      }),

    listVersions: protectedProcedure
      .input(
        z.object({
          planId: z.number().int().positive(),
        })
      )
      .query(async ({ input }) => {
        const { getPlanVersions } = await import("./_core/planVersion");

        const versions = await getPlanVersions(input.planId);

        return versions.map((v) => ({
          id: v.id,
          version: v.version,
          createdAt: v.createdAt,
        }));
      }),

    rollbackToVersion: protectedProcedure
      .input(
        z.object({
          planId: z.number().int().positive(),
          version: z.number().int().positive(),
        })
      )
      .mutation(async ({ input }) => {
        const { getPlanVersionSnapshot, saveNewPlanVersion } = await import("./_core/planVersion");
        const { getDb, getPlanById, updatePlan } = await import("./db");
        const { eq } = await import("drizzle-orm");
        const { plans } = await import("../drizzle/schema");

        const { planId, version } = input;

        // 1) Buscar snapshot da versão solicitada
        const snapshot = await getPlanVersionSnapshot(planId, version);
        if (!snapshot) {
          throw new Error("Versão do plano não encontrada");
        }

        // 2) Atualizar plano principal com dados do snapshot
        const db = await getDb();
        if (!db) {
          throw new Error("Database not available");
        }

        await db
          .update(plans)
          .set({
            dishes: typeof snapshot.dishes === 'string' ? snapshot.dishes : JSON.stringify(snapshot.dishes),
            shoppingList: typeof snapshot.shoppingList === 'string' ? snapshot.shoppingList : JSON.stringify(snapshot.shoppingList),
            prepSchedule: snapshot.prepSchedule ? (typeof snapshot.prepSchedule === 'string' ? snapshot.prepSchedule : JSON.stringify(snapshot.prepSchedule)) : undefined,
            usedStock: snapshot.usedStock ? (typeof snapshot.usedStock === 'string' ? snapshot.usedStock : JSON.stringify(snapshot.usedStock)) : null,
            remainingStock: snapshot.remainingStock ? (typeof snapshot.remainingStock === 'string' ? snapshot.remainingStock : JSON.stringify(snapshot.remainingStock)) : null,
            substitutions: snapshot.substitutions ? (typeof snapshot.substitutions === 'string' ? snapshot.substitutions : JSON.stringify(snapshot.substitutions)) : null,
          })
          .where(eq(plans.id, planId));

        // 3) Carregar plano atualizado
        const updated = await getPlanById(planId);
        if (!updated) {
          throw new Error("Plano não encontrado após rollback");
        }

        // 4) Registrar rollback como nova versão no histórico
        const newVersion = await saveNewPlanVersion(planId, {
          dishes: JSON.parse(updated.dishes),
          shoppingList: JSON.parse(updated.shoppingList),
          prepSchedule: updated.prepSchedule ? JSON.parse(updated.prepSchedule) : undefined,
          usedStock: updated.usedStock ? JSON.parse(updated.usedStock) : undefined,
          remainingStock: updated.remainingStock ? JSON.parse(updated.remainingStock) : undefined,
          substitutions: updated.substitutions ? JSON.parse(updated.substitutions) : undefined,
        });

        // 5) Retornar plano atualizado
        return {
          ok: true,
          plan: {
            ...updated,
            dishes: JSON.parse(updated.dishes),
            shoppingList: JSON.parse(updated.shoppingList),
            prepSchedule: updated.prepSchedule ? JSON.parse(updated.prepSchedule) : undefined,
          },
          version: newVersion.version,
        };
      }),

    // PATCH 8.6.0: Regenerar lista de compras
    regenerateShoppingList: protectedProcedure
      .input(
        z.object({
          planId: z.number(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // PATCH 8.8.0: Gate por tier
        const { getUserTier } = await import("./_core/subscription-tier");
        const { canAccessFeature } = await import("../shared/tier-limits");

        const tier = await getUserTier(ctx.user.id);
        
        if (!canAccessFeature(tier, "allowRegenerateList")) {
          console.log(`[upgrade-opportunity] user=${ctx.user.id} reason=feature_locked_regen_list tier=${tier}`);
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Seu plano atual não permite regenerar a lista de compras. Faça upgrade para liberar este recurso.",
          });
        }

        const { getPlanById, updatePlan } = await import("./db");
        const { regenerateShoppingList } = await import("./_core/llm");
        const { saveNewPlanVersion } = await import("./_core/planVersion");

        // 1) Buscar o plano atual no banco
        const plan = await getPlanById(input.planId);
        if (!plan) {
          throw new Error("Plano não encontrado");
        }

        // 2) Extrair dados do plano
        const dishes = JSON.parse(plan.dishes);
        const oldShoppingList = JSON.parse(plan.shoppingList);
        const servings = plan.requestedServings || 10;

        // 3) Regenerar lista de compras usando o LLM
        let newShoppingList;
        try {
          newShoppingList = await regenerateShoppingList({
            currentList: oldShoppingList,
            dishes,
            servings,
          });
        } catch (error) {
          console.error("[regenerateShoppingList] LLM error:", error);
          throw new Error("Erro ao regenerar lista de compras. Tente novamente.");
        }

        // 4) Atualizar o plano no banco
        await updatePlan(input.planId, {
          shoppingList: JSON.stringify(newShoppingList),
        });

        // 5) Criar uma nova versão do plano
        const newVersion = await saveNewPlanVersion(input.planId, {
          dishes,
          shoppingList: newShoppingList,
          prepSchedule: plan.prepSchedule ? JSON.parse(plan.prepSchedule) : undefined,
          usedStock: plan.usedStock ? JSON.parse(plan.usedStock) : undefined,
          remainingStock: plan.remainingStock ? JSON.parse(plan.remainingStock) : undefined,
          substitutions: plan.substitutions ? JSON.parse(plan.substitutions) : undefined,
        });

        // 6) Retornar resultado
        return {
          ok: true,
          newPlan: {
            ...plan,
            dishes,
            shoppingList: newShoppingList,
            prepSchedule: plan.prepSchedule ? JSON.parse(plan.prepSchedule) : undefined,
          },
          newVersion: {
            id: newVersion.id,
            version: newVersion.version,
          },
          diff: {
            oldList: oldShoppingList,
            newList: newShoppingList,
          },
        };
      }),
  }),

  feedback: router({
    submit: protectedProcedure
      .input(
        z.object({
          planId: z.number(),
          dishName: z.string(),
          rating: z.enum(["liked", "disliked"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // PATCH 9.6.0: Gate por tier (Free não pode dar feedback)
        const { getUserTier } = await import("./_core/subscription-tier");
        const { canAccessFeature } = await import("../shared/tier-limits");
        const { TRPCError } = await import("@trpc/server");

        const tier = await getUserTier(ctx.user.id);
        
        // Free não pode dar feedback
        if (!canAccessFeature(tier, "allowRegenerateDish")) {
          console.log(`[upgrade-opportunity] user=${ctx.user.id} reason=feature_locked_feedback tier=${tier}`);
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Seu plano atual não permite dar feedback em pratos. Faça upgrade para liberar este recurso.",
          });
        }

        const { createDishFeedback } = await import("./db");
        await createDishFeedback({
          userId: ctx.user.id,
          planId: input.planId,
          dishName: input.dishName,
          rating: input.rating,
        });
        return { success: true };
      }),
  }),

  preferences: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      // PATCH 7.1.0: Usar helper getUserPreferences para sempre retornar defaults
      const { getUserPreferences } = await import("./_core/preferences");
      const { getDb } = await import("./db");
      const db = await getDb();
      if (!db) {
        throw new Error("Database not available");
      }
      return getUserPreferences(db, ctx.user.id);
    }),

    update: protectedProcedure
      .input(
        z.object({
          // PATCH 7.0.0: New fields
          mode: z.string().optional(),
          servings: z.number().int().positive().optional(),
          varieties: z.number().int().positive().optional(),
          time: z.number().int().positive().nullable().optional(),
          allowNewIngredients: z.boolean().optional(),
          // Existing fields
          exclusions: z.array(z.string()).optional(),
          favorites: z.array(z.string()).optional(),
          skillLevel: z.enum(["beginner", "intermediate", "advanced"]).optional(),
          dietType: z.string().optional(),
          maxKcalPerServing: z.number().int().positive().nullable().optional(),
          // PATCH 7.8.0: Analytics source tracking
          _source: z.enum(["dashboard", "planner"]).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { getUserPreference, createUserPreference, updateUserPreference } = await import("./db");
        const existing = await getUserPreference(ctx.user.id);

        const updates: any = {};
        // PATCH 7.0.0: New fields
        if (input.mode !== undefined) updates.mode = input.mode;
        if (input.servings !== undefined) updates.servings = input.servings;
        if (input.varieties !== undefined) updates.varieties = input.varieties;
        if (input.time !== undefined) updates.time = input.time;
        if (input.allowNewIngredients !== undefined) updates.allowNewIngredients = input.allowNewIngredients;
        // Existing fields
        if (input.exclusions !== undefined) {
          updates.exclusions = JSON.stringify(input.exclusions);
        }
        if (input.favorites !== undefined) {
          updates.favorites = JSON.stringify(input.favorites);
        }
        if (input.skillLevel !== undefined) {
          updates.skillLevel = input.skillLevel;
        }
        if (input.dietType !== undefined) {
          updates.dietType = input.dietType;
        }
        if (input.maxKcalPerServing !== undefined) {
          updates.maxKcalPerServing = input.maxKcalPerServing;
        }

        if (!existing) {
          await createUserPreference({
            userId: ctx.user.id,
            ...updates,
          });
        } else {
          await updateUserPreference(ctx.user.id, updates);
        }

        // PATCH 7.8.0: Log analytics (removido em 9.4.1)
        console.log(`[preferences] user=${ctx.user.id} source=${input._source ?? "dashboard"} at=${new Date().toISOString()}`);

        return { success: true };
      }),
  }),

  // Stripe / Subscription router
  subscription: router({
    // PATCH 8.3.0: Return plans with mobile product IDs
    plans: publicProcedure.query(() => {
      const { PRICING_PLANS } = require("./stripe-products");
      return PRICING_PLANS.map((p: any) => ({
        tier: p.id,
        name: p.name,
        description: p.description,
        price: p.price,
        interval: p.interval,
        appleProductId: p.appleProductId ?? null,
        googleProductId: p.googleProductId ?? null,
        features: p.features,
      }));
    }),
    // PATCH 8.3.0: Return unified tier from all sources
    current: protectedProcedure.query(async ({ ctx }) => {
      const { getUserTier } = await import("./_core/subscription-tier");
      const tier = await getUserTier(ctx.user.id);
      return { tier };
    }),
    createCheckout: protectedProcedure
      .input(z.object({ priceId: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const stripe = (await import("./_core/stripe")).default;
        const { getUserActiveSubscription } = await import("./subscription-service");
        const { getUserTier } = await import("./_core/subscription-tier");
        const { TRPCError } = await import("@trpc/server");

        // Guard extra por segurança e clareza
        const user = ctx.user;
        if (!user) {
          throw new Error("Usuário não autenticado");
        }
        if (!user.email) {
          throw new Error("Usuário sem e-mail cadastrado");
        }
        
        // PATCH 9.6.0: Bloquear downgrade
        const currentTier = await getUserTier(user.id);
        
        // Mapear priceId para tier (precisa buscar do Stripe)
        const price = await stripe.prices.retrieve(input.priceId);
        const product = await stripe.products.retrieve(price.product as string);
        const targetTier = product.metadata?.tier || "free";
        
        // Hierarquia de tiers: free < pro < premium < vip
        const tierHierarchy: Record<string, number> = {
          free: 0,
          pro: 1,
          premium: 2,
          vip: 3,
        };
        
        const currentLevel = tierHierarchy[currentTier] || 0;
        const targetLevel = tierHierarchy[targetTier] || 0;
        
        if (currentLevel >= targetLevel && currentTier !== "free") {
          console.log(`[downgrade-blocked] user=${user.id} current=${currentTier} target=${targetTier}`);
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Não é possível fazer downgrade para um plano inferior. Use o portal de assinatura para cancelar.",
          });
        }
        
        if (user.subscriptionTier && user.subscriptionTier !== "free") {
          // Opcional: impedir criar novo checkout se já tem tier Pro/Premium ativo
          const active = await getUserActiveSubscription(user.id);
          if (active) {
            throw new Error("Você já possui uma assinatura ativa.");
          }
        }

        const session = await stripe.checkout.sessions.create({
          mode: "subscription",
          customer_email: user.email,
          client_reference_id: user.id.toString(),
          line_items: [
            {
              price: input.priceId,
              quantity: 1,
            },
          ],
          success_url: `${ctx.req.headers.origin}/planner?checkout=success`,
          cancel_url: `${ctx.req.headers.origin}/?checkout=canceled`,
          allow_promotion_codes: true,
          metadata: {
            user_id: user.id.toString(),
            customer_email: user.email,
            customer_name: user.name || "",
          },
        });

        return { checkoutUrl: session.url };
      }),
    // PATCH 8.3.0: Create mobile subscription from IAP receipt
    createMobileSubscription: protectedProcedure
      .input(
        z.object({
          platform: z.enum(["apple", "google"]),
          receiptData: z.string().optional(), // Apple
          purchaseToken: z.string().optional(), // Google
          productId: z.string().optional(), // Google (or redundant for Apple)
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { TRPCError } = await import("@trpc/server");
        const {
          verifyAppleReceipt,
          verifyGooglePurchase,
          mapProductToTier,
          upsertMobileSubscription,
        } = await import("./_core/iap");

        const userId = ctx.user.id;
        let verificationResult: {
          valid: boolean;
          productId: string;
          expiresAt: Date | null;
        };

        // Validate inputs based on platform
        if (input.platform === "apple") {
          if (!input.receiptData) {
            throw new TRPCError({
              code: "BAD_REQUEST",
              message: "receiptData is required for Apple",
            });
          }
          verificationResult = await verifyAppleReceipt(input.receiptData);
        } else {
          if (!input.purchaseToken || !input.productId) {
            throw new TRPCError({
              code: "BAD_REQUEST",
              message: "purchaseToken and productId are required for Google",
            });
          }
          verificationResult = await verifyGooglePurchase(
            input.purchaseToken,
            input.productId
          );
        }

        // Validate receipt
        if (!verificationResult.valid) {
          console.warn(
            `[IAP] Invalid receipt for user=${userId} platform=${input.platform} productId=${verificationResult.productId}`
          );
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Invalid purchase",
          });
        }

        // Map product to tier
        const productId = verificationResult.productId;
        const tier = mapProductToTier(productId, input.platform);
        const expiresAt = verificationResult.expiresAt ?? null;

        // Save to database
        await upsertMobileSubscription({
          userId,
          platform: input.platform,
          productId,
          tier,
          status: "active",
          expiresAt,
          rawReceipt: input.receiptData ?? input.purchaseToken ?? undefined,
        });

        // Log success
        console.log(
          `[IAP] user=${userId} platform=${input.platform} productId=${productId} tier=${tier} expiresAt=${expiresAt?.toISOString()}`
        );

        return {
          tier,
          expiresAt,
          status: "active" as const,
        };
      }),

    createPortalSession: protectedProcedure.mutation(async ({ ctx }) => {
      const stripe = (await import("./_core/stripe")).default;
      const { getUserActiveSubscription } = await import("./subscription-service");

      // Buscar subscription ativa
      const subscription = await getUserActiveSubscription(ctx.user.id);
      if (!subscription || !subscription.stripeCustomerId) {
        throw new Error("Nenhuma assinatura ativa encontrada");
      }

      // Criar portal session
      const session = await stripe.billingPortal.sessions.create({
        customer: subscription.stripeCustomerId,
        return_url: `${ctx.req.headers.origin}/planner`,
      });

      return { portalUrl: session.url };
    }),
  }),

  // Dashboard and user stats
  dashboard: router({
    stats: protectedProcedure.query(async ({ ctx }) => {
      const { getUserStats } = await import("./dashboard-stats");
      return getUserStats(ctx.user.id);
    }),

    subscription: protectedProcedure.query(async ({ ctx }) => {
      const { getUserSubscription } = await import("./dashboard-stats");
      return getUserSubscription(ctx.user.id);
    }),

    updatePreferences: protectedProcedure
      .input(
        z.object({
          dietType: z.string().optional(),
          exclusions: z.array(z.string()).optional(),
          favorites: z.array(z.string()).optional(),
          skillLevel: z.enum(["beginner", "intermediate", "advanced"]).optional(),
          maxKcalPerServing: z.number().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const { updateUserPreference } = await import("./db");
        await updateUserPreference(ctx.user.id, {
          dietType: input.dietType,
          exclusions: input.exclusions ? JSON.stringify(input.exclusions) : undefined,
          favorites: input.favorites ? JSON.stringify(input.favorites) : undefined,
          skillLevel: input.skillLevel,
          maxKcalPerServing: input.maxKcalPerServing,
        });
        return { success: true };
      }),
  }),

  // PATCH 8.1.0: Admin analytics
  admin: router({
    funnelStats: publicProcedure
      .input(
        z.object({
          adminSecret: z.string(),
        })
      )
      .query(async ({ input }) => {
        const { ENV } = await import("./_core/env");
        const { TRPCError } = await import("@trpc/server");
        
        // Proteger endpoint com secret
        if (input.adminSecret !== ENV.adminFunnelSecret) {
          throw new TRPCError({ code: "UNAUTHORIZED" });
        }

        const { getDb } = await import("./db");
        const { anonymousPlans, users } = await import("../drizzle/schema");
        const { sql } = await import("drizzle-orm");

        const db = await getDb();
        if (!db) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Database not available",
          });
        }

        // PATCH 8.4.0: Implementação completa do funil
        const { isNotNull } = await import("drizzle-orm");

        // 1) Anonymous plans por source
        const anonBySource = await db
          .select({
            source: anonymousPlans.source,
            count: sql<number>`COUNT(*)`.as("count"),
          })
          .from(anonymousPlans)
          .groupBy(anonymousPlans.source);

        // 2) Signups por source
        const signupsBySource = await db
          .select({
            source: users.source,
            count: sql<number>`COUNT(*)`.as("count"),
          })
          .from(users)
          .where(isNotNull(users.source))
          .groupBy(users.source);

        // 3) Indexar por source
        const anonMap = new Map<string, number>();
        for (const row of anonBySource) {
          anonMap.set(row.source ?? "unknown", row.count);
        }

        const signupMap = new Map<string, number>();
        for (const row of signupsBySource) {
          signupMap.set(row.source ?? "unknown", row.count);
        }

        const allSources = new Set<string>([
          ...Array.from(anonMap.keys()),
          ...Array.from(signupMap.keys()),
        ]);

        const rows = Array.from(allSources).map((src) => {
          const anonymousPlansCount = anonMap.get(src) ?? 0;
          const signupsCount = signupMap.get(src) ?? 0;
          const conversionRate =
            anonymousPlansCount === 0
              ? 0
              : signupsCount / anonymousPlansCount;

          return {
            source: src,
            anonymousPlans: anonymousPlansCount,
            signups: signupsCount,
            conversionRate,
          };
        });

        const totalAnonymous = rows.reduce((acc, r) => acc + r.anonymousPlans, 0);
        const totalSignups = rows.reduce((acc, r) => acc + r.signups, 0);
        const totalConversion =
          totalAnonymous === 0 ? 0 : totalSignups / totalAnonymous;

        return {
          sources: rows.sort((a, b) => b.anonymousPlans - a.anonymousPlans),
          totals: {
            anonymousPlans: totalAnonymous,
            signups: totalSignups,
            conversionRate: totalConversion,
          },
        };
      }),
  }),

  // PATCH 9.1.0: Shopping list export
  shoppingList: router({
    // PATCH 9.3.0: CSV/XLSX export with tier gating
    export: protectedProcedure
      .input(
        z.object({
          planId: z.number().int().positive(),
          format: z.enum(["csv", "xlsx"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { getDb } = await import("./db");
        const { getUserTier } = await import("./_core/subscription-tier");
        const { getTierLimits } = await import("../shared/tier-limits");
        const { plans, sessions } = await import("../drizzle/schema");
        const { eq, and, isNull } = await import("drizzle-orm");
        const { TRPCError } = await import("@trpc/server");

        const db = await getDb();
        if (!db) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Não foi possível acessar o banco de dados.",
          });
        }

        // 1. Validar tier
        const tier = await getUserTier(ctx.user.id);
        const limits = getTierLimits(tier);

        if (input.format === "csv" && !limits.allowExportCsv) {
          console.log(
            `[upgrade-opportunity] user=${ctx.user.id} reason=feature_locked_export_csv tier=${tier}`
          );
          throw new TRPCError({
            code: "FORBIDDEN",
            message:
              "Seu plano atual não permite exportar a lista de compras em CSV. Faça upgrade para liberar este recurso.",
          });
        }

        if (input.format === "xlsx" && !limits.allowExportXlsx) {
          console.log(
            `[upgrade-opportunity] user=${ctx.user.id} reason=feature_locked_export_xlsx tier=${tier}`
          );
          throw new TRPCError({
            code: "FORBIDDEN",
            message:
              "Exportar para Excel é um recurso de planos Pro e Premium. Faça upgrade para liberar este recurso.",
          });
        }

        // 2. Checar ownership e deletedAt
        const [result] = await db
          .select()
          .from(plans)
          .innerJoin(sessions, eq(plans.sessionId, sessions.id))
          .where(
            and(
              eq(plans.id, input.planId),
              eq(sessions.userId, ctx.user.id),
              isNull(plans.deletedAt)
            )
          )
          .limit(1);

        if (!result) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Plano não encontrado.",
          });
        }

        const plan = result.plans;

        // 3. Parsear shoppingList
        const parsedShoppingList = Array.isArray(plan.shoppingList)
          ? plan.shoppingList
          : JSON.parse(plan.shoppingList ?? "[]");

        // 4. Normalizar lista usando normalizador universal
        const { normalizeShoppingList } = await import("./_core/shopping-list-normalizer");
        const normalizedList = normalizeShoppingList(parsedShoppingList);

        // 5. Exportar
        const { exportShoppingList } = await import(
          "./export/shoppingList-export"
        );

        const exportResult = exportShoppingList(normalizedList, input.format, {
          planId: plan.id,
          createdAt: plan.createdAt,
          dietType: plan.dietType,
        });

        // 6. Retornar base64 para o front baixar
        return {
          fileName: exportResult.fileName,
          mimeType: exportResult.mimeType,
          dataBase64: exportResult.buffer.toString("base64"),
        };
      }),

    exportPremiumPdf: protectedProcedure
      .input(z.object({ planId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const { getUserTier } = await import("./_core/subscription-tier");
        const { getPlanById } = await import("./db");
        const { generateShoppingListPdf } = await import("./_core/pdf-export");
        const { normalizeShoppingList } = await import("./_core/shopping-list-normalizer");
        const { TRPCError } = await import("@trpc/server");

        // PATCH 9.6.0: Validar tier usando allowExportShoppingListPdf
        const { canAccessFeature } = await import("../shared/tier-limits");
        const tier = await getUserTier(ctx.user.id);
        
        if (!canAccessFeature(tier, "allowExportShoppingListPdf")) {
          console.log(`[upgrade-opportunity] user=${ctx.user.id} reason=feature_locked_pdf_export tier=${tier}`);
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Exportar PDF de lista de compras é exclusivo dos planos Pro, Premium e VIP.",
          });
        }

        // 2. Carregar plano e validar ownership
        const plan = await getPlanById(input.planId);
        if (!plan) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Plano não encontrado.",
          });
        }

        // Verificar ownership via sessionId
        const { getDb } = await import("./db");
        const { sessions } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        
        const db = await getDb();
        if (!db) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Database not available",
          });
        }

        const [session] = await db
          .select()
          .from(sessions)
          .where(eq(sessions.id, plan.sessionId))
          .limit(1);

        if (!session || session.userId !== ctx.user.id) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Plano não encontrado ou você não tem permissão para acessá-lo.",
          });
        }

        // 3. Parsear lista de compras
        const shoppingList = JSON.parse(plan.shoppingList);

        // 4. Normalizar lista usando normalizador universal
        const normalizedItems = normalizeShoppingList(shoppingList);

        // 5. Converter para formato esperado pelo PDF
        const items = normalizedItems.map((item) => ({
          category: item.category || "Outros",
          name: item.name,
          quantityLabel: item.quantity && item.unit
            ? `${item.quantity} ${item.unit}`
            : item.quantity
            ? `${item.quantity}`
            : "a gosto",
        }));

        // 6. Gerar PDF
        const pdfBuffer = await generateShoppingListPdf({
          userId: ctx.user.id,
          planId: plan.id,
          items,
          planMeta: {
            createdAt: plan.createdAt,
            mode: plan.mode || "normal",
            servings: plan.requestedServings ?? undefined,
          },
        });

        // 6. Retornar base64 para download no frontend
        const base64 = pdfBuffer.toString("base64");
        return {
          filename: `lista-compras-planna-${plan.id}.pdf`,
          mimeType: "application/pdf",
          base64,
        };
      }),
  }),

  // Plan sharing
  share: router({
    generateLink: protectedProcedure
      .input(z.object({ planId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const { generateShareLink } = await import("./share-service");
        const token = await generateShareLink(input.planId, ctx.user.id);
        const origin = ctx.req.headers.origin || "";
        return {
          token,
          url: `${origin}/shared/${token}`,
        };
      }),

    getSharedPlan: publicProcedure
      .input(z.object({ token: z.string() }))
      .query(async ({ input }) => {
        const { getSharedPlan } = await import("./share-service");
        const plan = await getSharedPlan(input.token);

        // PATCH 8.5.0: Lançar TRPCError NOT_FOUND se plano não existir ou foi deletado
        if (!plan) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Plano compartilhado não encontrado ou foi removido.",
          });
        }

        return plan;
      }),

    revokeLink: protectedProcedure
       .input(z.object({ planId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const { revokeShareLink } = await import("./share-service");
        await revokeShareLink(input.planId, ctx.user.id);
        return { success: true };
      }),
  }),

});
export type AppRouter = typeof appRouter;
