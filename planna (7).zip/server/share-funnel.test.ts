/**
 * PATCH 8.1.0: Share Funnel Tests
 * Tests for acquisition source tracking and funnel analytics
 */

import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { anonymousPlans, users } from "../drizzle/schema";
import { eq, sql } from "drizzle-orm";

describe("PATCH 8.1.0 - Share Funnel & Source Tracking", () => {
  let db: Awaited<ReturnType<typeof getDb>>;

  beforeAll(async () => {
    db = await getDb();
    if (!db) throw new Error("Database not available");
  });

  afterAll(async () => {
    // Cleanup test data
    if (db) {
      // Clean up test anonymous plans
      await db.delete(anonymousPlans).where(
        sql`${anonymousPlans.anonymousId} LIKE 'test_%'`
      );
      // Clean up test users
      await db.delete(users).where(
        sql`${users.email} LIKE 'test_%@funnel.test'`
      );
    }
  });

  describe("1. anonymous_plans.source", () => {
    it("should store source='home' when anonymous plan is created from home", async () => {
      const testAnonId = `test_home_${Date.now()}`;
      const testPlanId = Math.floor(Math.random() * 1000000);

      await db!.insert(anonymousPlans).values({
        anonymousId: testAnonId,
        planId: testPlanId,
        source: "home",
      });

      const [result] = await db!
        .select()
        .from(anonymousPlans)
        .where(eq(anonymousPlans.anonymousId, testAnonId))
        .limit(1);

      expect(result).toBeDefined();
      expect(result.source).toBe("home");
    });

    it("should default to 'unknown' when source is not provided", async () => {
      const testAnonId = `test_unknown_${Date.now()}`;
      const testPlanId = Math.floor(Math.random() * 1000000);

      await db!.insert(anonymousPlans).values({
        anonymousId: testAnonId,
        planId: testPlanId,
        // source not provided, should default to "unknown"
      });

      const [result] = await db!
        .select()
        .from(anonymousPlans)
        .where(eq(anonymousPlans.anonymousId, testAnonId))
        .limit(1);

      expect(result).toBeDefined();
      expect(result.source).toBe("unknown");
    });
  });

  describe("2. users.source", () => {
    it("should store source='share' when user registers from shared link", async () => {
      const testEmail = `test_share_${Date.now()}@funnel.test`;
      const testOpenId = `test_openid_${Date.now()}`;

      await db!.insert(users).values({
        openId: testOpenId,
        name: "Test User Share",
        email: testEmail,
        source: "share",
        loginMethod: "local",
      });

      const [result] = await db!
        .select()
        .from(users)
        .where(eq(users.email, testEmail))
        .limit(1);

      expect(result).toBeDefined();
      expect(result.source).toBe("share");
    });

    it("should default to 'unknown' when source is not provided", async () => {
      const testEmail = `test_nosource_${Date.now()}@funnel.test`;
      const testOpenId = `test_openid_nosource_${Date.now()}`;

      await db!.insert(users).values({
        openId: testOpenId,
        name: "Test User No Source",
        email: testEmail,
        loginMethod: "local",
        // source not provided, should default to "unknown"
      });

      const [result] = await db!
        .select()
        .from(users)
        .where(eq(users.email, testEmail))
        .limit(1);

      expect(result).toBeDefined();
      expect(result.source).toBe("unknown");
    });
  });

  describe("3. generateAnonymousPlan limit enforcement", () => {
    it("should allow first anonymous plan", async () => {
      const testAnonId = `test_limit_${Date.now()}`;
      const testPlanId = Math.floor(Math.random() * 1000000);

      // Check count before
      const [countBefore] = await db!
        .select({ count: sql<number>`COUNT(*)`.as("count") })
        .from(anonymousPlans)
        .where(eq(anonymousPlans.anonymousId, testAnonId));

      expect(countBefore.count).toBe(0);

      // Insert first plan
      await db!.insert(anonymousPlans).values({
        anonymousId: testAnonId,
        planId: testPlanId,
        source: "home",
      });

      // Check count after
      const [countAfter] = await db!
        .select({ count: sql<number>`COUNT(*)`.as("count") })
        .from(anonymousPlans)
        .where(eq(anonymousPlans.anonymousId, testAnonId));

      expect(countAfter.count).toBe(1);
    });

    it("should enforce limit of 1 plan per anonymousId", async () => {
      const testAnonId = `test_limit_enforce_${Date.now()}`;
      const testPlanId1 = Math.floor(Math.random() * 1000000);
      const testPlanId2 = Math.floor(Math.random() * 1000000);

      // Insert first plan
      await db!.insert(anonymousPlans).values({
        anonymousId: testAnonId,
        planId: testPlanId1,
        source: "home",
      });

      // Check count
      const [count] = await db!
        .select({ count: sql<number>`COUNT(*)`.as("count") })
        .from(anonymousPlans)
        .where(eq(anonymousPlans.anonymousId, testAnonId));

      // Should have exactly 1 plan
      expect(count.count).toBe(1);

      // Trying to insert second plan should be blocked by application logic
      // (This test validates the count check logic)
      expect(count.count).toBeGreaterThanOrEqual(1);
    });
  });

  describe("4. admin.funnelStats calculation", () => {
    it("should calculate conversion rate correctly", async () => {
      const timestamp = Date.now();
      const testSource = `test_conversion_${timestamp}`;

      // Create 3 anonymous plans with same source
      for (let i = 0; i < 3; i++) {
        await db!.insert(anonymousPlans).values({
          anonymousId: `test_anon_${timestamp}_${i}`,
          planId: Math.floor(Math.random() * 1000000),
          source: testSource,
        });
      }

      // Create 1 user with same source
      await db!.insert(users).values({
        openId: `test_openid_conversion_${timestamp}`,
        name: "Test Conversion User",
        email: `test_conversion_${timestamp}@funnel.test`,
        source: testSource,
        loginMethod: "local",
      });

      // Query anonymous plans by source
      const [anonCount] = await db!
        .select({ count: sql<number>`COUNT(*)`.as("count") })
        .from(anonymousPlans)
        .where(eq(anonymousPlans.source, testSource));

      // Query users by source
      const [userCount] = await db!
        .select({ count: sql<number>`COUNT(*)`.as("count") })
        .from(users)
        .where(eq(users.source, testSource));

      // Calculate conversion
      const conversion = userCount.count / anonCount.count;

      expect(anonCount.count).toBe(3);
      expect(userCount.count).toBe(1);
      expect(conversion).toBeCloseTo(0.333, 2); // 33.3%
    });

    it("should handle different sources independently", async () => {
      const timestamp = Date.now();
      const sourceA = `test_source_a_${timestamp}`;
      const sourceB = `test_source_b_${timestamp}`;

      // Source A: 2 anonymous, 1 signup
      await db!.insert(anonymousPlans).values({
        anonymousId: `test_a1_${timestamp}`,
        planId: Math.floor(Math.random() * 1000000),
        source: sourceA,
      });
      await db!.insert(anonymousPlans).values({
        anonymousId: `test_a2_${timestamp}`,
        planId: Math.floor(Math.random() * 1000000),
        source: sourceA,
      });
      await db!.insert(users).values({
        openId: `test_user_a_${timestamp}`,
        name: "Test User A",
        email: `test_a_${timestamp}@funnel.test`,
        source: sourceA,
        loginMethod: "local",
      });

      // Source B: 1 anonymous, 0 signups
      await db!.insert(anonymousPlans).values({
        anonymousId: `test_b1_${timestamp}`,
        planId: Math.floor(Math.random() * 1000000),
        source: sourceB,
      });

      // Verify counts
      const [anonCountA] = await db!
        .select({ count: sql<number>`COUNT(*)`.as("count") })
        .from(anonymousPlans)
        .where(eq(anonymousPlans.source, sourceA));

      const [userCountA] = await db!
        .select({ count: sql<number>`COUNT(*)`.as("count") })
        .from(users)
        .where(eq(users.source, sourceA));

      const [anonCountB] = await db!
        .select({ count: sql<number>`COUNT(*)`.as("count") })
        .from(anonymousPlans)
        .where(eq(anonymousPlans.source, sourceB));

      const [userCountB] = await db!
        .select({ count: sql<number>`COUNT(*)`.as("count") })
        .from(users)
        .where(eq(users.source, sourceB));

      expect(anonCountA.count).toBe(2);
      expect(userCountA.count).toBe(1);
      expect(anonCountB.count).toBe(1);
      expect(userCountB.count).toBe(0);
    });
  });

  describe("5. Source tracking persistence", () => {
    it("should persist source across multiple queries", async () => {
      const timestamp = Date.now();
      const testAnonId = `test_persist_${timestamp}`;
      const testSource = "share_whatsapp";

      await db!.insert(anonymousPlans).values({
        anonymousId: testAnonId,
        planId: Math.floor(Math.random() * 1000000),
        source: testSource,
      });

      // Query 1
      const [result1] = await db!
        .select()
        .from(anonymousPlans)
        .where(eq(anonymousPlans.anonymousId, testAnonId))
        .limit(1);

      // Query 2
      const [result2] = await db!
        .select()
        .from(anonymousPlans)
        .where(eq(anonymousPlans.anonymousId, testAnonId))
        .limit(1);

      expect(result1.source).toBe(testSource);
      expect(result2.source).toBe(testSource);
      expect(result1.source).toBe(result2.source);
    });
  });
});
