/**
 * PATCH 8.5.0 - Testes para share.getSharedPlan
 * 
 * Valida que erros de plano compartilhado retornam TRPCError NOT_FOUND
 */

import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import { getDb } from "./db";
import { users, sessions, plans } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

describe("share.getSharedPlan", () => {
  let testUserId: number;
  let testSessionId: number;
  let testPlanId: number;
  let shareToken: string;

  beforeAll(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Criar usuário de teste
    const [user] = await db
      .insert(users)
      .values({
        openId: `test_${Date.now()}`,
        name: "Test User",
        email: `test_${Date.now()}@example.com`,
        loginMethod: "local",
      })
      .$returningId();

    testUserId = user.id;

    // Criar sessão de teste
    const [session] = await db
      .insert(sessions)
      .values({
        userId: testUserId,
        inputText: "frango, arroz, feijão",
        servings: 5,
        objective: "normal",
      })
      .$returningId();

    testSessionId = session.id;

    // Criar plano de teste
    const [plan] = await db
      .insert(plans)
      .values({
        sessionId: testSessionId,
        dishes: JSON.stringify([{ name: "Test Dish" }]),
        shoppingList: JSON.stringify([]),
        prepSchedule: JSON.stringify([]),
        shareToken: "test_token_12345",
        requestedServings: 5,
        requestedVarieties: 3,
      })
      .$returningId();

    testPlanId = plan.id;
    shareToken = "test_token_12345";
  });

  afterAll(async () => {
    const db = await getDb();
    if (!db) return;

    // Limpar dados de teste
    await db.delete(plans).where(eq(plans.id, testPlanId));
    await db.delete(sessions).where(eq(sessions.id, testSessionId));
    await db.delete(users).where(eq(users.id, testUserId));
  });

  it("deve retornar plano válido quando token existe e plano não está deletado", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
      ip: "127.0.0.1",
    });

    const result = await caller.share.getSharedPlan({ token: shareToken });

    expect(result).toBeDefined();
    expect(result.id).toBe(testPlanId);
    expect(result.dishes).toBeDefined();
    expect(result.shoppingList).toBeDefined();
  });

  it("deve lançar TRPCError NOT_FOUND quando token é inválido", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
      ip: "127.0.0.1",
    });

    await expect(
      caller.share.getSharedPlan({ token: "invalid_token_xyz" })
    ).rejects.toThrow(TRPCError);

    try {
      await caller.share.getSharedPlan({ token: "invalid_token_xyz" });
    } catch (error) {
      expect((error as TRPCError).code).toBe("NOT_FOUND");
      expect((error as TRPCError).message).toContain("não encontrado");
    }
  });

  it("deve lançar TRPCError NOT_FOUND quando plano está deletado", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Marcar plano como deletado
    await db
      .update(plans)
      .set({ deletedAt: new Date() })
      .where(eq(plans.id, testPlanId));

    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
      ip: "127.0.0.1",
    });

    await expect(
      caller.share.getSharedPlan({ token: shareToken })
    ).rejects.toThrow(TRPCError);

    try {
      await caller.share.getSharedPlan({ token: shareToken });
    } catch (error) {
      expect((error as TRPCError).code).toBe("NOT_FOUND");
      expect((error as TRPCError).message).toContain("removido");
    }

    // Restaurar plano para não quebrar outros testes
    await db
      .update(plans)
      .set({ deletedAt: null })
      .where(eq(plans.id, testPlanId));
  });
});
