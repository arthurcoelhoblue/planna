/**
 * PATCH 8.8.0 - Tier Limits Tests
 * 
 * Testes unitários para validar limites e helpers de tiers
 */

import { describe, it, expect } from "vitest";
import {
  TIER_LIMITS,
  getTierLimits,
  canAccessFeature,
  hasReachedLimit,
  TIER_DESCRIPTIONS,
  TIER_LABELS,
  type SubscriptionTier,
} from "../shared/tier-limits";

describe("TIER_LIMITS", () => {
  it("deve ter definições para todos os tiers", () => {
    expect(TIER_LIMITS.free).toBeDefined();
    expect(TIER_LIMITS.pro).toBeDefined();
    expect(TIER_LIMITS.premium).toBeDefined();
    expect(TIER_LIMITS.vip).toBeDefined();
  });

  it("free deve ter limites restritivos", () => {
    const free = TIER_LIMITS.free;
    expect(free.maxPlansPerMonth).toBe(2);
    expect(free.maxServings).toBe(10);
    expect(free.maxVarieties).toBe(3);
    expect(free.allowAdvancedModes).toBe(false);
    expect(free.allowRegenerateDish).toBe(false);
    expect(free.allowRegenerateList).toBe(false);
    expect(free.maxIngredientDetectionsPerMonth).toBe(3);
    expect(free.allowVersionHistory).toBe(false);
  });

  it("pro deve ter limites intermediários", () => {
    const pro = TIER_LIMITS.pro;
    expect(pro.maxPlansPerMonth).toBe(10);
    expect(pro.maxServings).toBe(20);
    expect(pro.maxVarieties).toBe(6);
    expect(pro.allowAdvancedModes).toBe(true);
    expect(pro.allowRegenerateDish).toBe(true);
    expect(pro.allowRegenerateList).toBe(true);
    expect(pro.maxIngredientDetectionsPerMonth).toBe(30);
    expect(pro.allowVersionHistory).toBe(true);
  });

  it("premium deve ter limites generosos", () => {
    const premium = TIER_LIMITS.premium;
    expect(premium.maxPlansPerMonth).toBe(Infinity);
    expect(premium.maxServings).toBe(20);
    expect(premium.maxVarieties).toBe(6);
    expect(premium.allowAdvancedModes).toBe(true);
    expect(premium.allowRegenerateDish).toBe(true);
    expect(premium.allowRegenerateList).toBe(true);
    expect(premium.maxIngredientDetectionsPerMonth).toBe(Infinity);
    expect(premium.allowVersionHistory).toBe(true);
  });

  it("vip deve ter limites ilimitados", () => {
    const vip = TIER_LIMITS.vip;
    expect(vip.maxPlansPerMonth).toBe(Infinity);
    expect(vip.maxServings).toBe(20);
    expect(vip.maxVarieties).toBe(6);
    expect(vip.allowAdvancedModes).toBe(true);
    expect(vip.allowRegenerateDish).toBe(true);
    expect(vip.allowRegenerateList).toBe(true);
    expect(vip.maxIngredientDetectionsPerMonth).toBe(Infinity);
    expect(vip.allowVersionHistory).toBe(true);
  });
});

describe("getTierLimits", () => {
  it("deve retornar limites corretos para cada tier", () => {
    const free = getTierLimits("free");
    expect(free.maxPlansPerMonth).toBe(2);

    const pro = getTierLimits("pro");
    expect(pro.maxPlansPerMonth).toBe(10);

    const premium = getTierLimits("premium");
    expect(premium.maxPlansPerMonth).toBe(Infinity);

    const vip = getTierLimits("vip");
    expect(vip.maxPlansPerMonth).toBe(Infinity);
  });
});

describe("canAccessFeature", () => {
  it("free não pode acessar features avançadas", () => {
    expect(canAccessFeature("free", "allowAdvancedModes")).toBe(false);
    expect(canAccessFeature("free", "allowRegenerateDish")).toBe(false);
    expect(canAccessFeature("free", "allowRegenerateList")).toBe(false);
    expect(canAccessFeature("free", "allowVersionHistory")).toBe(false);
  });

  it("pro pode acessar features avançadas", () => {
    expect(canAccessFeature("pro", "allowAdvancedModes")).toBe(true);
    expect(canAccessFeature("pro", "allowRegenerateDish")).toBe(true);
    expect(canAccessFeature("pro", "allowRegenerateList")).toBe(true);
    expect(canAccessFeature("pro", "allowVersionHistory")).toBe(true);
  });

  it("premium pode acessar todas as features", () => {
    expect(canAccessFeature("premium", "allowAdvancedModes")).toBe(true);
    expect(canAccessFeature("premium", "allowRegenerateDish")).toBe(true);
    expect(canAccessFeature("premium", "allowRegenerateList")).toBe(true);
    expect(canAccessFeature("premium", "allowVersionHistory")).toBe(true);
  });

  it("vip pode acessar todas as features", () => {
    expect(canAccessFeature("vip", "allowAdvancedModes")).toBe(true);
    expect(canAccessFeature("vip", "allowRegenerateDish")).toBe(true);
    expect(canAccessFeature("vip", "allowRegenerateList")).toBe(true);
    expect(canAccessFeature("vip", "allowVersionHistory")).toBe(true);
  });

  it("deve retornar true para limites numéricos > 0", () => {
    expect(canAccessFeature("free", "maxPlansPerMonth")).toBe(true); // 2 > 0
    expect(canAccessFeature("pro", "maxIngredientDetectionsPerMonth")).toBe(true); // 30 > 0
  });
});

describe("hasReachedLimit", () => {
  it("free atinge limite de planos após 2", () => {
    expect(hasReachedLimit("free", "maxPlansPerMonth", 0)).toBe(false);
    expect(hasReachedLimit("free", "maxPlansPerMonth", 1)).toBe(false);
    expect(hasReachedLimit("free", "maxPlansPerMonth", 2)).toBe(true);
    expect(hasReachedLimit("free", "maxPlansPerMonth", 3)).toBe(true);
  });

  it("pro atinge limite de planos após 10", () => {
    expect(hasReachedLimit("pro", "maxPlansPerMonth", 9)).toBe(false);
    expect(hasReachedLimit("pro", "maxPlansPerMonth", 10)).toBe(true);
    expect(hasReachedLimit("pro", "maxPlansPerMonth", 11)).toBe(true);
  });

  it("premium nunca atinge limite de planos", () => {
    expect(hasReachedLimit("premium", "maxPlansPerMonth", 0)).toBe(false);
    expect(hasReachedLimit("premium", "maxPlansPerMonth", 100)).toBe(false);
    expect(hasReachedLimit("premium", "maxPlansPerMonth", 1000)).toBe(false);
  });

  it("vip nunca atinge limite de planos", () => {
    expect(hasReachedLimit("vip", "maxPlansPerMonth", 0)).toBe(false);
    expect(hasReachedLimit("vip", "maxPlansPerMonth", 100)).toBe(false);
    expect(hasReachedLimit("vip", "maxPlansPerMonth", 1000)).toBe(false);
  });

  it("deve retornar false para features booleanas", () => {
    expect(hasReachedLimit("free", "allowAdvancedModes", 0)).toBe(false);
    expect(hasReachedLimit("pro", "allowRegenerateDish", 100)).toBe(false);
  });
});

describe("TIER_DESCRIPTIONS", () => {
  it("deve ter descrições para todos os tiers", () => {
    expect(TIER_DESCRIPTIONS.free).toBeDefined();
    expect(TIER_DESCRIPTIONS.pro).toBeDefined();
    expect(TIER_DESCRIPTIONS.premium).toBeDefined();
    expect(TIER_DESCRIPTIONS.vip).toBeDefined();
  });

  it("descrições devem ser strings não vazias", () => {
    expect(TIER_DESCRIPTIONS.free.length).toBeGreaterThan(0);
    expect(TIER_DESCRIPTIONS.pro.length).toBeGreaterThan(0);
    expect(TIER_DESCRIPTIONS.premium.length).toBeGreaterThan(0);
    expect(TIER_DESCRIPTIONS.vip.length).toBeGreaterThan(0);
  });
});

describe("TIER_LABELS", () => {
  it("deve ter labels para todos os tiers", () => {
    expect(TIER_LABELS.free).toBeDefined();
    expect(TIER_LABELS.pro).toBeDefined();
    expect(TIER_LABELS.premium).toBeDefined();
    expect(TIER_LABELS.vip).toBeDefined();
  });

  it("labels devem ser strings não vazias", () => {
    expect(TIER_LABELS.free.length).toBeGreaterThan(0);
    expect(TIER_LABELS.pro.length).toBeGreaterThan(0);
    expect(TIER_LABELS.premium.length).toBeGreaterThan(0);
    expect(TIER_LABELS.vip.length).toBeGreaterThan(0);
  });
});

describe("Hierarquia de Tiers", () => {
  it("free < pro < premium < vip em termos de limites", () => {
    expect(TIER_LIMITS.free.maxPlansPerMonth).toBeLessThan(
      TIER_LIMITS.pro.maxPlansPerMonth
    );
    expect(TIER_LIMITS.pro.maxPlansPerMonth).toBeLessThan(
      TIER_LIMITS.premium.maxPlansPerMonth
    );
    expect(TIER_LIMITS.premium.maxPlansPerMonth).toBe(
      TIER_LIMITS.vip.maxPlansPerMonth
    );
  });

  it("free tem menos features que pro", () => {
    expect(TIER_LIMITS.free.allowAdvancedModes).toBe(false);
    expect(TIER_LIMITS.pro.allowAdvancedModes).toBe(true);
  });

  it("pro e premium têm mesmas features booleanas", () => {
    expect(TIER_LIMITS.pro.allowAdvancedModes).toBe(
      TIER_LIMITS.premium.allowAdvancedModes
    );
    expect(TIER_LIMITS.pro.allowRegenerateDish).toBe(
      TIER_LIMITS.premium.allowRegenerateDish
    );
    expect(TIER_LIMITS.pro.allowRegenerateList).toBe(
      TIER_LIMITS.premium.allowRegenerateList
    );
  });

  it("premium e vip têm mesmas features", () => {
    expect(TIER_LIMITS.premium.allowAdvancedModes).toBe(
      TIER_LIMITS.vip.allowAdvancedModes
    );
    expect(TIER_LIMITS.premium.maxPlansPerMonth).toBe(
      TIER_LIMITS.vip.maxPlansPerMonth
    );
  });
});
