import { describe, it, expect } from "vitest";
import { generateShoppingListPdf, ShoppingListPdfInput } from "./_core/pdf-export";

describe("generateShoppingListPdf", () => {
  it("deve gerar PDF com lista de compras válida", async () => {
    const input: ShoppingListPdfInput = {
      userId: 1,
      planId: 123,
      items: [
        { category: "Proteínas", name: "Frango", quantityLabel: "1 kg" },
        { category: "Proteínas", name: "Ovos", quantityLabel: "12 unidades" },
        { category: "Grãos", name: "Arroz", quantityLabel: "500 g" },
        { category: "Vegetais", name: "Brócolis", quantityLabel: "300 g" },
      ],
      planMeta: {
        createdAt: new Date("2024-01-15"),
        mode: "normal",
        servings: 10,
      },
    };

    const pdfBuffer = await generateShoppingListPdf(input);

    // Verificar que retornou um Buffer
    expect(Buffer.isBuffer(pdfBuffer)).toBe(true);

    // Verificar que o buffer não está vazio
    expect(pdfBuffer.length).toBeGreaterThan(0);

    // Verificar que começa com assinatura PDF (%PDF)
    const header = pdfBuffer.toString("utf-8", 0, 4);
    expect(header).toBe("%PDF");
  });

  it("deve gerar PDF com modo 'aproveitamento'", async () => {
    const input: ShoppingListPdfInput = {
      userId: 2,
      planId: 456,
      items: [
        { category: "Sobras", name: "Arroz cozido", quantityLabel: "200 g" },
        { category: "Proteínas", name: "Frango desfiado", quantityLabel: "150 g" },
      ],
      planMeta: {
        createdAt: new Date("2024-02-20"),
        mode: "aproveitamento",
        servings: 5,
      },
    };

    const pdfBuffer = await generateShoppingListPdf(input);

    expect(Buffer.isBuffer(pdfBuffer)).toBe(true);
    expect(pdfBuffer.length).toBeGreaterThan(0);
  });

  it("deve gerar PDF sem servings (opcional)", async () => {
    const input: ShoppingListPdfInput = {
      userId: 3,
      planId: 789,
      items: [
        { category: "Temperos", name: "Sal", quantityLabel: "a gosto" },
        { category: "Temperos", name: "Pimenta", quantityLabel: "a gosto" },
      ],
      planMeta: {
        createdAt: new Date("2024-03-10"),
        mode: "lowcal",
      },
    };

    const pdfBuffer = await generateShoppingListPdf(input);

    expect(Buffer.isBuffer(pdfBuffer)).toBe(true);
    expect(pdfBuffer.length).toBeGreaterThan(0);
  });

  it("deve gerar PDF com lista vazia", async () => {
    const input: ShoppingListPdfInput = {
      userId: 4,
      planId: 999,
      items: [],
      planMeta: {
        createdAt: new Date("2024-04-01"),
        mode: "normal",
        servings: 1,
      },
    };

    const pdfBuffer = await generateShoppingListPdf(input);

    // Mesmo com lista vazia, deve gerar PDF válido
    expect(Buffer.isBuffer(pdfBuffer)).toBe(true);
    expect(pdfBuffer.length).toBeGreaterThan(0);
  });

  it("deve agrupar itens por categoria corretamente", async () => {
    const input: ShoppingListPdfInput = {
      userId: 5,
      planId: 111,
      items: [
        { category: "Proteínas", name: "Frango", quantityLabel: "1 kg" },
        { category: "Grãos", name: "Arroz", quantityLabel: "500 g" },
        { category: "Proteínas", name: "Ovos", quantityLabel: "12 unidades" },
        { category: "Grãos", name: "Feijão", quantityLabel: "300 g" },
        { category: "Vegetais", name: "Tomate", quantityLabel: "4 unidades" },
      ],
      planMeta: {
        createdAt: new Date("2024-05-15"),
        mode: "highprotein",
        servings: 15,
      },
    };

    const pdfBuffer = await generateShoppingListPdf(input);

    expect(Buffer.isBuffer(pdfBuffer)).toBe(true);
    expect(pdfBuffer.length).toBeGreaterThan(0);
    
    // Verificar assinatura PDF
    const header = pdfBuffer.toString("utf-8", 0, 4);
    expect(header).toBe("%PDF");
  });
});
