/**
 * PATCH 7.5.0 - Testes de Integração
 * Validar lógica de derivação de exclusions e favorites no PlanView
 */

import { describe, it, expect } from "vitest";

describe("PATCH 7.5.0 - Derivação de Exclusions e Favorites", () => {
  /**
   * Helper para simular a lógica de derivação de exclusions
   * Replicando a lógica do PlanView.tsx
   */
  function deriveExclusions(preferences: any): string[] {
    if (!preferences?.exclusions) return [];
    
    // Caso 1: Array direto
    if (Array.isArray(preferences.exclusions)) {
      return preferences.exclusions as string[];
    }
    
    // Caso 2: JSON string
    try {
      const parsed = JSON.parse(preferences.exclusions as any);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  /**
   * Helper para simular a lógica de derivação de favorites
   */
  function deriveFavorites(preferences: any): string[] {
    if (!preferences?.favorites) return [];
    
    if (Array.isArray(preferences.favorites)) {
      return preferences.favorites as string[];
    }
    
    try {
      const parsed = JSON.parse(preferences.favorites as any);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  describe("Derivação de Exclusions", () => {
    it("deve retornar array vazio quando preferences é null", () => {
      const result = deriveExclusions(null);
      expect(result).toEqual([]);
    });

    it("deve retornar array vazio quando exclusions é undefined", () => {
      const result = deriveExclusions({ exclusions: undefined });
      expect(result).toEqual([]);
    });

    it("deve retornar array direto quando exclusions já é array", () => {
      const preferences = {
        exclusions: ["leite", "glúten", "amendoim"]
      };
      const result = deriveExclusions(preferences);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve parsear JSON string para array", () => {
      const preferences = {
        exclusions: '["leite", "glúten", "amendoim"]'
      };
      const result = deriveExclusions(preferences);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve retornar array vazio quando JSON é inválido", () => {
      const preferences = {
        exclusions: "invalid json {"
      };
      const result = deriveExclusions(preferences);
      expect(result).toEqual([]);
    });

    it("deve retornar array vazio quando JSON não é array", () => {
      const preferences = {
        exclusions: '{"item": "leite"}'
      };
      const result = deriveExclusions(preferences);
      expect(result).toEqual([]);
    });
  });

  describe("Derivação de Favorites", () => {
    it("deve retornar array vazio quando preferences é null", () => {
      const result = deriveFavorites(null);
      expect(result).toEqual([]);
    });

    it("deve retornar array vazio quando favorites é undefined", () => {
      const result = deriveFavorites({ favorites: undefined });
      expect(result).toEqual([]);
    });

    it("deve retornar array direto quando favorites já é array", () => {
      const preferences = {
        favorites: ["frango", "arroz", "brócolis"]
      };
      const result = deriveFavorites(preferences);
      expect(result).toEqual(["frango", "arroz", "brócolis"]);
    });

    it("deve parsear JSON string para array", () => {
      const preferences = {
        favorites: '["frango", "arroz", "brócolis"]'
      };
      const result = deriveFavorites(preferences);
      expect(result).toEqual(["frango", "arroz", "brócolis"]);
    });

    it("deve retornar array vazio quando JSON é inválido", () => {
      const preferences = {
        favorites: "invalid json ["
      };
      const result = deriveFavorites(preferences);
      expect(result).toEqual([]);
    });

    it("deve retornar array vazio quando JSON não é array", () => {
      const preferences = {
        favorites: '{"item": "frango"}'
      };
      const result = deriveFavorites(preferences);
      expect(result).toEqual([]);
    });
  });

  describe("Cenários de Integração", () => {
    it("Cenário 1: Usuário com preferences preenchidas", () => {
      const preferences = {
        exclusions: ["leite", "glúten"],
        favorites: ["frango", "arroz"]
      };

      const exclusions = deriveExclusions(preferences);
      const favorites = deriveFavorites(preferences);

      expect(exclusions).toEqual(["leite", "glúten"]);
      expect(favorites).toEqual(["frango", "arroz"]);
    });

    it("Cenário 2: Usuário sem preferences (novo usuário)", () => {
      const preferences = {
        exclusions: null,
        favorites: null
      };

      const exclusions = deriveExclusions(preferences);
      const favorites = deriveFavorites(preferences);

      expect(exclusions).toEqual([]);
      expect(favorites).toEqual([]);
    });

    it("Cenário 3: Preferences com JSON string (dados antigos)", () => {
      const preferences = {
        exclusions: '["leite", "glúten", "amendoim"]',
        favorites: '["frango", "arroz", "brócolis", "batata"]'
      };

      const exclusions = deriveExclusions(preferences);
      const favorites = deriveFavorites(preferences);

      expect(exclusions).toEqual(["leite", "glúten", "amendoim"]);
      expect(favorites).toEqual(["frango", "arroz", "brócolis", "batata"]);
    });

    it("Cenário 4: Preferences mistas (array + JSON string)", () => {
      const preferences = {
        exclusions: ["leite", "glúten"],
        favorites: '["frango", "arroz"]'
      };

      const exclusions = deriveExclusions(preferences);
      const favorites = deriveFavorites(preferences);

      expect(exclusions).toEqual(["leite", "glúten"]);
      expect(favorites).toEqual(["frango", "arroz"]);
    });
  });

  describe("Formatação de Exibição", () => {
    it("deve formatar lista vazia corretamente", () => {
      const exclusions: string[] = [];
      const display = exclusions.length > 0 
        ? exclusions.join(", ") 
        : "Nenhum cadastrado";
      
      expect(display).toBe("Nenhum cadastrado");
    });

    it("deve formatar lista com um item", () => {
      const exclusions = ["leite"];
      const display = exclusions.length > 0 
        ? exclusions.join(", ") 
        : "Nenhum cadastrado";
      
      expect(display).toBe("leite");
    });

    it("deve formatar lista com múltiplos itens", () => {
      const exclusions = ["leite", "glúten", "amendoim"];
      const display = exclusions.length > 0 
        ? exclusions.join(", ") 
        : "Nenhum cadastrado";
      
      expect(display).toBe("leite, glúten, amendoim");
    });

    it("deve usar mensagem alternativa para favorites vazios", () => {
      const favorites: string[] = [];
      const display = favorites.length > 0 
        ? favorites.join(", ") 
        : "Nenhum destaque";
      
      expect(display).toBe("Nenhum destaque");
    });
  });
});
