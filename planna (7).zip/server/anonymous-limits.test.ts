/**
 * PATCH 8.7.0 - Testes de Limitações do Plano Anônimo
 * 
 * Validar que o backend aplica corretamente os limites:
 * - maxServings: 10
 * - maxVarieties: 3
 * - allowedModes: ["normal"]
 * - allowAdvancedSophistication: false
 */

import { describe, it, expect } from "vitest";
import { ANONYMOUS_LIMITS } from "../shared/free-trial";

describe("PATCH 8.7.0 - Anonymous Limits", () => {
  describe("1. Configuração de limites", () => {
    it("should have correct maxServings limit", () => {
      expect(ANONYMOUS_LIMITS.maxServings).toBe(10);
    });

    it("should have correct maxVarieties limit", () => {
      expect(ANONYMOUS_LIMITS.maxVarieties).toBe(3);
    });

    it("should allow only normal mode", () => {
      expect(ANONYMOUS_LIMITS.allowedModes).toEqual(["normal"]);
      expect(ANONYMOUS_LIMITS.allowedModes).toHaveLength(1);
    });

    it("should not allow advanced sophistication", () => {
      expect(ANONYMOUS_LIMITS.allowAdvancedSophistication).toBe(false);
    });
  });

  describe("2. Clamp de servings", () => {
    it("should clamp servings to max when exceeding", () => {
      const requestedServings = 15;
      const clamped = Math.min(requestedServings, ANONYMOUS_LIMITS.maxServings);
      expect(clamped).toBe(10);
    });

    it("should keep servings when below max", () => {
      const requestedServings = 8;
      const clamped = Math.min(requestedServings, ANONYMOUS_LIMITS.maxServings);
      expect(clamped).toBe(8);
    });

    it("should keep servings when equal to max", () => {
      const requestedServings = 10;
      const clamped = Math.min(requestedServings, ANONYMOUS_LIMITS.maxServings);
      expect(clamped).toBe(10);
    });
  });

  describe("3. Clamp de varieties", () => {
    it("should clamp varieties to max when exceeding", () => {
      const requestedVarieties = 5;
      const clamped = Math.min(requestedVarieties, ANONYMOUS_LIMITS.maxVarieties);
      expect(clamped).toBe(3);
    });

    it("should keep varieties when below max", () => {
      const requestedVarieties = 2;
      const clamped = Math.min(requestedVarieties, ANONYMOUS_LIMITS.maxVarieties);
      expect(clamped).toBe(2);
    });

    it("should keep varieties when equal to max", () => {
      const requestedVarieties = 3;
      const clamped = Math.min(requestedVarieties, ANONYMOUS_LIMITS.maxVarieties);
      expect(clamped).toBe(3);
    });
  });

  describe("4. Enforcement de mode", () => {
    it("should allow normal mode", () => {
      const requestedMode = "normal";
      const allowed = ANONYMOUS_LIMITS.allowedModes.includes(requestedMode as any);
      expect(allowed).toBe(true);
    });

    it("should block aproveitamento mode", () => {
      const requestedMode = "aproveitamento";
      const allowed = ANONYMOUS_LIMITS.allowedModes.includes(requestedMode as any);
      expect(allowed).toBe(false);
    });

    it("should block lowcal mode", () => {
      const requestedMode = "lowcal";
      const allowed = ANONYMOUS_LIMITS.allowedModes.includes(requestedMode as any);
      expect(allowed).toBe(false);
    });

    it("should block highprotein mode", () => {
      const requestedMode = "highprotein";
      const allowed = ANONYMOUS_LIMITS.allowedModes.includes(requestedMode as any);
      expect(allowed).toBe(false);
    });

    it("should fallback to normal when mode not allowed", () => {
      const requestedMode = "lowcal";
      const finalMode = ANONYMOUS_LIMITS.allowedModes.includes(requestedMode as any)
        ? requestedMode
        : "normal";
      expect(finalMode).toBe("normal");
    });
  });

  describe("5. Enforcement de sophistication", () => {
    it("should force simples when advanced not allowed", () => {
      const requestedSophistication = "gourmet";
      const finalSophistication = ANONYMOUS_LIMITS.allowAdvancedSophistication
        ? requestedSophistication
        : "simples";
      expect(finalSophistication).toBe("simples");
    });

    it("should keep simples when requested", () => {
      const requestedSophistication = "simples";
      const finalSophistication = ANONYMOUS_LIMITS.allowAdvancedSophistication
        ? requestedSophistication
        : "simples";
      expect(finalSophistication).toBe("simples");
    });
  });

  describe("6. Payload completo clamped", () => {
    it("should clamp all fields correctly", () => {
      const payload = {
        servings: 20,
        varieties: 6,
        objective: "lowcal" as any,
        sophistication: "gourmet" as any,
      };

      const clampedPayload = {
        servings: Math.min(payload.servings, ANONYMOUS_LIMITS.maxServings),
        varieties: Math.min(payload.varieties, ANONYMOUS_LIMITS.maxVarieties),
        objective: ANONYMOUS_LIMITS.allowedModes.includes(payload.objective)
          ? payload.objective
          : "normal",
        sophistication: ANONYMOUS_LIMITS.allowAdvancedSophistication
          ? payload.sophistication
          : "simples",
      };

      expect(clampedPayload.servings).toBe(10);
      expect(clampedPayload.varieties).toBe(3);
      expect(clampedPayload.objective).toBe("normal");
      expect(clampedPayload.sophistication).toBe("simples");
    });
  });
});
