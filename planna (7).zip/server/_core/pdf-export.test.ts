import { describe, it, expect } from "vitest";
import { generateShoppingListPdf, ShoppingListPdfInput } from "./pdf-export";

describe("PDF Export - PATCH 9.2.0 Branding & Polish", () => {
  it("deve gerar PDF válido com categorias vazias", async () => {
    const input: ShoppingListPdfInput = {
      userId: 1,
      planId: 1,
      items: [],
      planMeta: {
        createdAt: new Date(),
        mode: "normal",
        servings: 4,
      },
    };

    const pdfBuffer = await generateShoppingListPdf(input);

    expect(pdfBuffer).toBeInstanceOf(Buffer);
    expect(pdfBuffer.length).toBeGreaterThan(0);
    
    // Verificar que é um PDF válido (começa com %PDF)
    const pdfHeader = pdfBuffer.toString("utf8", 0, 4);
    expect(pdfHeader).toBe("%PDF");
  });

  it("deve gerar PDF válido com itens normais", async () => {
    const input: ShoppingListPdfInput = {
      userId: 1,
      planId: 1,
      items: [
        { category: "Proteínas", name: "Frango", quantityLabel: "500 g" },
        { category: "Proteínas", name: "Ovo", quantityLabel: "12 unidades" },
        { category: "Carboidratos", name: "Arroz", quantityLabel: "1 kg" },
      ],
      planMeta: {
        createdAt: new Date(),
        mode: "aproveitamento",
        servings: 2,
      },
    };

    const pdfBuffer = await generateShoppingListPdf(input);

    expect(pdfBuffer).toBeInstanceOf(Buffer);
    expect(pdfBuffer.length).toBeGreaterThan(0);
    
    // Verificar que é um PDF válido
    const pdfHeader = pdfBuffer.toString("utf8", 0, 4);
    expect(pdfHeader).toBe("%PDF");
  });

  it("deve incluir elementos de branding no PDF", async () => {
    const input: ShoppingListPdfInput = {
      userId: 1,
      planId: 1,
      items: [
        { category: "Vegetais", name: "Tomate", quantityLabel: "500 g" },
      ],
      planMeta: {
        createdAt: new Date(),
        mode: "normal",
        servings: 4,
      },
    };

    const pdfBuffer = await generateShoppingListPdf(input);
    
    // Verificar que o PDF foi gerado com tamanho razoável (branding adiciona conteúdo)
    expect(pdfBuffer.length).toBeGreaterThan(1000);
    
    // Verificar estrutura do PDF
    const pdfHeader = pdfBuffer.toString("utf8", 0, 4);
    expect(pdfHeader).toBe("%PDF");
  });

  it("deve incluir rodapé em todas as páginas", async () => {
    const input: ShoppingListPdfInput = {
      userId: 1,
      planId: 1,
      items: [
        { category: "Teste", name: "Item", quantityLabel: "1 unidade" },
      ],
      planMeta: {
        createdAt: new Date(),
        mode: "normal",
      },
    };

    const pdfBuffer = await generateShoppingListPdf(input);
    
    // Verificar que o PDF foi gerado com rodapé (tamanho maior)
    expect(pdfBuffer.length).toBeGreaterThan(1000);
  });

  it("não deve lançar exceção com dados mínimos", async () => {
    const input: ShoppingListPdfInput = {
      userId: 1,
      planId: 1,
      items: [],
      planMeta: {
        createdAt: new Date(),
        mode: "normal",
      },
    };

    await expect(generateShoppingListPdf(input)).resolves.not.toThrow();
  });

  it("deve processar categorias corretamente", async () => {
    const input: ShoppingListPdfInput = {
      userId: 1,
      planId: 1,
      items: [
        { category: "proteínas", name: "Frango", quantityLabel: "500 g" },
      ],
      planMeta: {
        createdAt: new Date(),
        mode: "normal",
      },
    };

    const pdfBuffer = await generateShoppingListPdf(input);
    
    // Verificar que o PDF foi gerado com conteúdo
    expect(pdfBuffer.length).toBeGreaterThan(1000);
    
    // Verificar estrutura do PDF
    const pdfHeader = pdfBuffer.toString("utf8", 0, 4);
    expect(pdfHeader).toBe("%PDF");
  });
});
