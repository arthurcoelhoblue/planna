/**
 * PATCH 9.6.0 - Testes do normalizador de lista de compras
 * 
 * Valida que o normalizador aceita múltiplos formatos de entrada
 * e sempre retorna formato padronizado.
 */

import { describe, it, expect } from "vitest";
import { normalizeShoppingList } from "./shopping-list-normalizer";

describe("normalizeShoppingList", () => {
  it("deve normalizar lista vazia", () => {
    const result = normalizeShoppingList([]);
    expect(result).toEqual([]);
  });

  it("deve normalizar lista com strings simples", () => {
    const input = ["Frango 500g", "Arroz 1kg", "Feijão 500g"];
    const result = normalizeShoppingList(input);
    
    expect(result).toHaveLength(3);
    expect(result[0]).toMatchObject({
      name: "Frango 500g",
      quantity: "",
      unit: "",
      category: "Outros",
    });
  });

  it("deve normalizar lista com objetos completos", () => {
    const input = [
      { name: "Frango", quantity: "500", unit: "g", category: "Proteínas" },
      { name: "Arroz", quantity: "1", unit: "kg", category: "Grãos" },
    ];
    const result = normalizeShoppingList(input);
    
    expect(result).toHaveLength(2);
    expect(result[0]).toMatchObject({
      name: "Frango",
      quantity: "500",
      unit: "g",
      category: "Proteínas",
    });
  });

  it("deve normalizar lista com objetos parciais", () => {
    const input = [
      { name: "Frango", quantity: "500" },
      { name: "Arroz" },
    ];
    const result = normalizeShoppingList(input);
    
    expect(result).toHaveLength(2);
    expect(result[0]).toMatchObject({
      name: "Frango",
      quantity: "500",
      unit: "",
      category: "Outros",
    });
    expect(result[1]).toMatchObject({
      name: "Arroz",
      quantity: "",
      unit: "",
      category: "Outros",
    });
  });

  it("deve normalizar lista mista (strings + objetos)", () => {
    const input = [
      "Frango 500g",
      { name: "Arroz", quantity: "1", unit: "kg" },
      "Feijão",
    ];
    const result = normalizeShoppingList(input);
    
    expect(result).toHaveLength(3);
    expect(result[0].name).toBe("Frango 500g");
    expect(result[1].name).toBe("Arroz");
    expect(result[2].name).toBe("Feijão");
  });

  it("deve filtrar nulls e undefined", () => {
    const input = [
      "Frango",
      null,
      { name: "Arroz" },
      undefined,
      "Feijão",
    ];
    const result = normalizeShoppingList(input as any);
    
    expect(result).toHaveLength(3);
    expect(result.map(i => i.name)).toEqual(["Frango", "Arroz", "Feijão"]);
  });

  it("deve filtrar strings vazias", () => {
    const input = ["Frango", "", "Arroz", "   ", "Feijão"];
    const result = normalizeShoppingList(input);
    
    expect(result).toHaveLength(3);
    expect(result.map(i => i.name)).toEqual(["Frango", "Arroz", "Feijão"]);
  });

  it("deve normalizar objetos com campos extras", () => {
    const input = [
      { 
        name: "Frango", 
        quantity: "500", 
        unit: "g", 
        category: "Proteínas",
        extraField: "ignored",
        anotherField: 123,
      },
    ];
    const result = normalizeShoppingList(input as any);
    
    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({
      name: "Frango",
      quantity: "500",
      unit: "g",
      category: "Proteínas",
    });
    expect(result[0]).not.toHaveProperty("extraField");
  });

  it("deve converter números para strings", () => {
    const input = [
      { name: "Frango", quantity: 500, unit: "g" },
    ];
    const result = normalizeShoppingList(input as any);
    
    expect(result[0].quantity).toBe("500");
    expect(typeof result[0].quantity).toBe("string");
  });

  it("deve usar categoria padrão 'Outros' quando não especificada", () => {
    const input = [
      { name: "Frango", quantity: "500", unit: "g" },
      "Arroz",
    ];
    const result = normalizeShoppingList(input);
    
    expect(result[0].category).toBe("Outros");
    expect(result[1].category).toBe("Outros");
  });

  it("deve preservar categoria quando especificada", () => {
    const input = [
      { name: "Frango", quantity: "500", unit: "g", category: "Proteínas" },
    ];
    const result = normalizeShoppingList(input);
    
    expect(result[0].category).toBe("Proteínas");
  });
});
