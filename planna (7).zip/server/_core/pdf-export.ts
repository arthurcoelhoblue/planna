import PDFDocument from "pdfkit";

/**
 * Interface para item da lista de compras
 */
export interface ShoppingListItem {
  category: string;
  name: string;
  quantityLabel: string; // ex: "500 g", "2 unidades"
}

/**
 * Interface para metadados do plano
 */
export interface PlanMetadata {
  createdAt: Date;
  mode: string; // normal/lowcal/highprotein/aproveitamento
  servings?: number;
}

/**
 * Interface para input da geração de PDF
 */
export interface ShoppingListPdfInput {
  userId: number;
  planId: number;
  items: ShoppingListItem[];
  planMeta: PlanMetadata;
}

/**
 * Mapeia modo para label legível
 */
function getModeLabel(mode: string): string {
  const labels: Record<string, string> = {
    normal: "Modo Normal",
    aproveitamento: "Aproveitamento Total",
    lowcal: "Baixa Caloria",
    highprotein: "Alta Proteína",
  };
  return labels[mode] || mode;
}

/**
 * Formata data para exibição no PDF
 */
function formatDate(date: Date): string {
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  }).format(date);
}

/**
 * Gera PDF da lista de compras com layout premium
 * 
 * @param input - Dados da lista de compras e metadados do plano
 * @returns Buffer do PDF gerado
 */
export async function generateShoppingListPdf(
  input: ShoppingListPdfInput
): Promise<Buffer> {
  const { items, planMeta } = input;

  return new Promise((resolve, reject) => {
    try {
      // Criar documento PDF
      const doc = new PDFDocument({
        size: "A4",
        margins: {
          top: 50,
          bottom: 50,
          left: 50,
          right: 50,
        },
      });

      // Buffer para armazenar o PDF
      const chunks: Buffer[] = [];
      doc.on("data", (chunk) => chunks.push(chunk));
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.on("error", reject);

      // ===== CABEÇALHO =====
      
      // Logo/Nome Planna (texto estilizado por enquanto)
      doc
        .fontSize(28)
        .fillColor("#16a34a") // Verde do Planna
        .text("🍱 Planna", { align: "center" });

      doc.moveDown(0.3);

      // Linha de apoio
      doc
        .fontSize(9)
        .fillColor("#6b7280")
        .text("Gerado com Planna – Planejador de marmitas com IA", { align: "center" });

      doc.moveDown(1);

      // Título principal
      doc
        .fontSize(20)
        .fillColor("#000000")
        .text("Plano de Compras da Semana", { align: "center" });

      doc.moveDown(0.3);

      // Subtítulo com metadados
      const subtitle = [
        `Gerado em ${formatDate(planMeta.createdAt)}`,
        getModeLabel(planMeta.mode),
        planMeta.servings ? `${planMeta.servings} porções` : null,
      ]
        .filter(Boolean)
        .join(" • ");

      doc
        .fontSize(10)
        .fillColor("#666666")
        .text(subtitle, { align: "center" });

      doc.moveDown(1.5);

      // Linha separadora
      doc
        .strokeColor("#e5e7eb")
        .lineWidth(1)
        .moveTo(50, doc.y)
        .lineTo(545, doc.y)
        .stroke();

      doc.moveDown(1);

      // ===== LISTA DE COMPRAS POR CATEGORIA =====

      // Título da sessão
      doc
        .fontSize(16)
        .fillColor("#000000")
        .text("Lista de compras por categoria", { align: "left" });

      doc.moveDown(1);

      // Agrupar itens por categoria
      const itemsByCategory = items.reduce((acc, item) => {
        if (!acc[item.category]) {
          acc[item.category] = [];
        }
        acc[item.category].push(item);
        return acc;
      }, {} as Record<string, ShoppingListItem[]>);

      // Renderizar cada categoria
      Object.entries(itemsByCategory).forEach(([category, categoryItems], index) => {
        // Verificar se precisa de nova página
        if (doc.y > 680) {
          doc.addPage();
        }

        // Nome da categoria (negrito + caixa alta)
        doc
          .fontSize(13)
          .font("Helvetica-Bold")
          .fillColor("#16a34a")
          .text(category.toUpperCase());

        doc.moveDown(0.4);

        // Itens da categoria
        categoryItems.forEach((item) => {
          // Checkbox vazio + item (indentado)
          doc
            .fontSize(11)
            .font("Helvetica")
            .fillColor("#1f2937")
            .text(`☐  ${item.name} - ${item.quantityLabel}`, {
              indent: 15,
            });

          doc.moveDown(0.25);
        });

        doc.moveDown(0.7);
      });

      // ===== RODAPÉ =====
      
      // Adicionar rodapé em todas as páginas
      const range = doc.bufferedPageRange();
      for (let i = range.start; i < range.start + range.count; i++) {
        doc.switchToPage(i);
        
        // Posicionar no rodapé
        doc.y = 750;
        
        // Linha separadora
        doc
          .strokeColor("#e5e7eb")
          .lineWidth(0.5)
          .moveTo(50, 750)
          .lineTo(545, 750)
          .stroke();
        
        // Paginação (esquerda)
        doc
          .fontSize(8)
          .fillColor("#9ca3af")
          .text(`Página ${i + 1} de ${range.count}`, 50, 760, {
            width: 200,
            align: "left",
          });
        
        // Link do site (centro)
        doc
          .fontSize(8)
          .fillColor("#9ca3af")
          .text("Planna – www.planna.app", 50, 760, {
            width: 495,
            align: "center",
          });
        
        // Nota (direita)
        doc
          .fontSize(7)
          .fillColor("#9ca3af")
          .text("Este PDF foi gerado automaticamente", 345, 760, {
            width: 200,
            align: "right",
          });
        
        doc
          .fontSize(7)
          .fillColor("#9ca3af")
          .text("a partir do seu plano de marmitas.", 345, 770, {
            width: 200,
            align: "right",
          });
      }

      // Finalizar documento
      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}
