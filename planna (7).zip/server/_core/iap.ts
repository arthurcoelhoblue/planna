/**
 * IAP (In-App Purchase) Service
 * PATCH 8.3.0: Apple and Google purchase verification and subscription management
 */

import { PRICING_PLANS } from "../stripe-products";
import { getDb } from "../db";
import { mobileSubscriptions } from "../../drizzle/schema";

/**
 * Map productId to subscription tier
 * @param productId - Apple or Google product ID
 * @param platform - "apple" or "google"
 * @returns Subscription tier ("free" | "pro" | "premium")
 * @throws Error if productId is unknown
 */
export function mapProductToTier(
  productId: string,
  platform: "apple" | "google"
): "free" | "pro" | "premium" {
  const plan = PRICING_PLANS.find((p) =>
    platform === "apple"
      ? p.appleProductId === productId
      : p.googleProductId === productId
  );

  if (!plan) {
    throw new Error(`Unknown productId for platform ${platform}: ${productId}`);
  }

  return plan.id;
}

/**
 * Verify Apple receipt
 * TODO: Implement actual Apple verification using App Store Server API
 * For now, this is a mock/sandbox implementation
 * 
 * @param receiptData - Base64 encoded receipt from Apple
 * @returns Verification result with productId and expiration
 */
export async function verifyAppleReceipt(receiptData: string): Promise<{
  valid: boolean;
  productId: string;
  expiresAt: Date | null;
}> {
  // TODO: Implement actual Apple verification
  // 1. Use App Store Server API (recommended) or legacy verifyReceipt endpoint
  // 2. Use credentials from env (APPLE_IAP_SECRET, APPLE_SHARED_SECRET, etc.)
  // 3. Parse response and extract:
  //    - status (0 = valid)
  //    - productId (from latest_receipt_info or pending_renewal_info)
  //    - expires_date_ms (convert to Date)
  // 4. Handle sandbox vs production environments
  // 5. Validate receipt signature and authenticity
  
  console.log("[IAP] Apple receipt verification called (MOCK MODE)");
  console.log("[IAP] Receipt data length:", receiptData.length);
  
  // Mock implementation for development/testing
  // In production, this MUST be replaced with actual Apple API calls
  return {
    valid: false,
    productId: "",
    expiresAt: null,
  };
}

/**
 * Verify Google purchase
 * TODO: Implement actual Google verification using Google Play Developer API
 * For now, this is a mock/sandbox implementation
 * 
 * @param purchaseToken - Purchase token from Google Play
 * @param productId - Product ID to verify
 * @returns Verification result with productId and expiration
 */
export async function verifyGooglePurchase(
  purchaseToken: string,
  productId: string
): Promise<{
  valid: boolean;
  productId: string;
  expiresAt: Date | null;
}> {
  // TODO: Implement actual Google verification
  // 1. Use Google Play Developer API (purchases.subscriptions.get)
  // 2. Use service account credentials from env (GOOGLE_IAP_CREDENTIALS)
  // 3. Authenticate using OAuth 2.0 or service account JSON key
  // 4. Parse response and extract:
  //    - acknowledgementState (1 = acknowledged)
  //    - expiryTimeMillis (convert to Date)
  //    - paymentState (1 = payment received)
  // 5. Validate purchaseToken matches productId
  
  console.log("[IAP] Google purchase verification called (MOCK MODE)");
  console.log("[IAP] Purchase token:", purchaseToken.substring(0, 20) + "...");
  console.log("[IAP] Product ID:", productId);
  
  // Mock implementation for development/testing
  // In production, this MUST be replaced with actual Google API calls
  return {
    valid: false,
    productId,
    expiresAt: null,
  };
}

/**
 * Upsert mobile subscription record
 * Always inserts a new record (historical tracking)
 * 
 * @param params - Subscription data
 */
export async function upsertMobileSubscription(params: {
  userId: number;
  platform: "apple" | "google";
  productId: string;
  tier: "free" | "pro" | "premium";
  status: "active" | "canceled" | "expired";
  expiresAt?: Date | null;
  rawReceipt?: string;
}): Promise<void> {
  const { userId, platform, productId, tier, status, expiresAt, rawReceipt } = params;

  const db = await getDb();
  if (!db) {
    console.error("[IAP] Cannot upsert mobile subscription: database not available");
    throw new Error("Database not available");
  }

  // Insert new record (historical tracking)
  await db.insert(mobileSubscriptions).values({
    userId,
    platform,
    productId,
    tier,
    status,
    expiresAt: expiresAt ?? null,
    rawReceipt: rawReceipt ?? null,
  });

  console.log(
    `[IAP] Mobile subscription created: userId=${userId} platform=${platform} tier=${tier} status=${status}`
  );
}
