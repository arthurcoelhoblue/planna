/**
 * PATCH 8.4.0: Rate limit helper (in-memory)
 * 
 * Simple in-memory rate limiting for MVP.
 * For production with serverless/multinode, replace with Redis/Upstash.
 */

import { TRPCError } from "@trpc/server";

type RateLimitConfig = {
  windowMs: number; // Janela de tempo em ms
  max: number; // Máximo de requisições na janela
};

type Bucket = {
  count: number;
  expiresAt: number;
};

const buckets = new Map<string, Bucket>();

/**
 * Verifica rate limit e lança erro se excedido
 * @param key - Chave única para identificar o bucket (ex: "auth:verify:192.168.1.1")
 * @param config - Configuração de rate limit
 * @throws TRPCError(TOO_MANY_REQUESTS) se limite excedido
 */
export async function assertRateLimit(
  key: string,
  { windowMs, max }: RateLimitConfig
): Promise<void> {
  const now = Date.now();
  const bucket = buckets.get(key);

  // Se bucket não existe ou expirou, criar novo
  if (!bucket || bucket.expiresAt < now) {
    buckets.set(key, { count: 1, expiresAt: now + windowMs });
    return;
  }

  // Se atingiu o limite, lançar erro
  if (bucket.count >= max) {
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: "Muitas requisições. Tente novamente mais tarde.",
    });
  }

  // Incrementar contador
  bucket.count += 1;
}

/**
 * Limpa buckets expirados (opcional, para economizar memória)
 * Pode ser chamado periodicamente via setInterval
 */
export function cleanupExpiredBuckets(): void {
  const now = Date.now();
  const keysToDelete: string[] = [];
  
  buckets.forEach((bucket, key) => {
    if (bucket.expiresAt < now) {
      keysToDelete.push(key);
    }
  });
  
  keysToDelete.forEach((key) => buckets.delete(key));
}

// Cleanup automático a cada 5 minutos
if (typeof setInterval !== "undefined") {
  setInterval(cleanupExpiredBuckets, 5 * 60 * 1000);
}
