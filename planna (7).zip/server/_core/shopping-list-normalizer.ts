/**
 * Normalizador de Lista de Compras
 * 
 * Garante que todas as exportações (PDF, CSV, XLSX, print) usem o mesmo formato padronizado.
 * Resolve o problema de listas vazias ou mal formatadas em exportações.
 */

export interface NormalizedShoppingItem {
  name: string;
  quantity: string;
  unit: string;
  category: string;
}

/**
 * Normaliza uma lista de compras para formato padronizado.
 * 
 * Aceita múltiplos formatos de entrada:
 * - Array de strings: ["frango 500g", "arroz 1kg"]
 * - Array de objetos: [{ name: "frango", quantity: 500, unit: "g" }]
 * - Array misto: ["frango", { name: "arroz", quantity: 1, unit: "kg" }]
 * - null/undefined: retorna array vazio
 * 
 * @param shoppingList - Lista de compras em qualquer formato
 * @returns Array normalizado de itens
 */
export function normalizeShoppingList(
  shoppingList: any
): NormalizedShoppingItem[] {
  // Caso 1: null ou undefined → array vazio
  if (!shoppingList) {
    return [];
  }

  // Caso 2: não é array → tenta converter
  if (!Array.isArray(shoppingList)) {
    // Se for string, tenta fazer split por vírgula
    if (typeof shoppingList === "string") {
      shoppingList = shoppingList.split(",").map((s) => s.trim());
    } else {
      // Formato desconhecido, retorna vazio
      console.warn("[normalizeShoppingList] Formato desconhecido:", typeof shoppingList);
      return [];
    }
  }

  // Caso 3: array vazio → retorna vazio
  if (shoppingList.length === 0) {
    return [];
  }

  // Caso 4: normalizar cada item
  return shoppingList
    .map((item: any, index: number): NormalizedShoppingItem | null => {
      // Subcase 4.1: item é string
      if (typeof item === "string") {
        const trimmed = item.trim();
        if (!trimmed) return null; // String vazia

        // Tenta extrair quantidade e unidade
        const match = trimmed.match(/^([\d.,]+)\s*([a-zA-Zçãõéêíóú]+)?\s+(.+)$/);
        if (match) {
          const [, quantityStr, unit, name] = match;
          const quantity = parseFloat(quantityStr.replace(",", "."));
          return {
            name: name.trim(),
            quantity: isNaN(quantity) ? "" : String(quantity),
            unit: unit || "",
            category: "Outros",
          };
        }

        // Não tem quantidade, só nome
        return {
          name: trimmed,
          quantity: "",
          unit: "",
          category: "Outros",
        };
      }

      // Subcase 4.2: item é objeto
      if (typeof item === "object" && item !== null) {
        const name = item.name || item.ingredient || item.item || "";
        if (!name || typeof name !== "string") {
          console.warn(`[normalizeShoppingList] Item ${index} sem nome válido:`, item);
          return null;
        }

        return {
          name: name.trim(),
          quantity: item.quantity ? String(item.quantity) : "",
          unit: item.unit ? String(item.unit) : "",
          category: item.category ? String(item.category) : "Outros",
        };
      }

      // Subcase 4.3: formato desconhecido
      console.warn(`[normalizeShoppingList] Item ${index} com formato desconhecido:`, item);
      return null;
    })
    .filter((item: NormalizedShoppingItem | null): item is NormalizedShoppingItem => item !== null);
}

/**
 * Formata um item normalizado para exibição humana.
 * 
 * Exemplos:
 * - { name: "frango", quantity: 500, unit: "g" } → "Frango (500g)"
 * - { name: "arroz", quantity: 1, unit: "kg" } → "Arroz (1kg)"
 * - { name: "tomate", quantity: null, unit: null } → "Tomate"
 * 
 * @param item - Item normalizado
 * @returns String formatada para exibição
 */
export function formatShoppingItem(item: NormalizedShoppingItem): string {
  const name = item.name.charAt(0).toUpperCase() + item.name.slice(1);
  
  if (item.quantity !== null && item.unit) {
    return `${name} (${item.quantity}${item.unit})`;
  }
  
  if (item.quantity !== null) {
    return `${name} (${item.quantity})`;
  }
  
  return name;
}

/**
 * Agrupa itens por categoria.
 * 
 * @param items - Array de itens normalizados
 * @returns Map de categoria → array de itens
 */
export function groupByCategory(
  items: NormalizedShoppingItem[]
): Map<string, NormalizedShoppingItem[]> {
  const grouped = new Map<string, NormalizedShoppingItem[]>();

  for (const item of items as NormalizedShoppingItem[]) {
    const category = item.category || "Outros";
    if (!grouped.has(category)) {
      grouped.set(category, []);
    }
    grouped.get(category)!.push(item);
  }

  return grouped;
}
