# PATCH 8.7.0 – Nova Home Vendedora + Limitações do Plano de Teste (Anônimo)

**Data:** 06 de Dezembro de 2025  
**Versão:** 8.7.0  
**Status:** ✅ Implementado e testado

---

## 🎯 Objetivos

1. **Atualizar a Home** com copy orientada a vendas (emagrecimento, saúde, desperdício)
2. **Limitar o plano anônimo** (sem login) para criar contraste e empurrar para cadastro/assinatura
3. **Alinhar UI com copy** mostrando bloqueios claros de recursos avançados
4. **Manter compatibilidade total** com preferências, funil, pagamentos e PWA

---

## 📦 Implementação

### 1. Configuração de Marketing

**Arquivo criado:** `client/src/config/marketing.ts`

```typescript
export const HOME_COPY = {
  heroTitle: "Planeje suas marmitas saudáveis da semana em poucos minutos, com IA",
  heroSubtitle:
    "Diga o que tem em casa, escolha seu objetivo (emagrecer, ganhar massa ou só organizar a semana) e receba um plano completo com receitas, calorias por porção e lista de compras pronta.",
  heroCta: "Gerar meu primeiro plano grátis",
  heroMicrocopy: "Sem cartão de crédito, sem login. Você testa com 1 plano completo e depois decide se continua.",
  heroBullets: [
    "Aproveita melhor o que você já tem em casa",
    "Mostra calorias por porção e por prato",
    "Entrega lista de compras pronta para a semana",
  ],
  seoTitle: "Planna – Planejador de Marmitas Saudáveis com IA",
  seoDescription:
    "Planeje suas marmitas saudáveis da semana em poucos minutos. Use IA para montar planos de marmitas para emagrecer, ganhar massa e evitar desperdício, com calorias e lista de compras prontas.",
};
```

**Benefícios:**
- Copy centralizada em um único arquivo
- Fácil de atualizar sem tocar em componentes
- SEO otimizado

---

### 2. Limites do Plano Anônimo

**Arquivo criado:** `shared/free-trial.ts`

```typescript
export type PlannerMode = "normal" | "aproveitamento" | "lowcal" | "highprotein";

export const ANONYMOUS_LIMITS = {
  maxServings: 10,      // até 10 porções
  maxVarieties: 3,      // até 3 pratos diferentes
  allowedModes: ["normal"] as PlannerMode[], // só modo normal
  allowAdvancedSophistication: false,        // sem "gourmet"
};
```

**Limitações aplicadas:**
- ✅ Máximo de 10 porções (vs 20 para usuários logados)
- ✅ Máximo de 3 pratos diferentes (vs 6 para usuários logados)
- ✅ Apenas modo "Normal" (bloqueio de Aproveitamento, Low Cal, High Protein)
- ✅ Apenas nível "Simples" (bloqueio de Gourmet)

---

### 3. Backend Enforcement

**Arquivo modificado:** `server/routers.ts` (linha 622-712)

```typescript
.mutation(async ({ input, ctx }) => {
  // Rate limit existente
  await assertRateLimit(`mealPlan:generateAnon:${input.anonymousId}`, {
    windowMs: 60_000,
    max: 2,
  });

  const { anonymousId, payload } = input;
  
  // PATCH 8.7.0: Aplicar limitações de plano anônimo
  const { ANONYMOUS_LIMITS } = await import("../shared/free-trial");
  
  const clampedServings = Math.min(
    payload.servings ?? ANONYMOUS_LIMITS.maxServings,
    ANONYMOUS_LIMITS.maxServings
  );
  
  const clampedVarieties = Math.min(
    payload.varieties ?? ANONYMOUS_LIMITS.maxVarieties,
    ANONYMOUS_LIMITS.maxVarieties
  );
  
  const mode = ANONYMOUS_LIMITS.allowedModes.includes(payload.objective as any)
    ? payload.objective
    : "normal";
  
  const sophistication = ANONYMOUS_LIMITS.allowAdvancedSophistication
    ? payload.sophistication ?? "simples"
    : "simples";
  
  const clampedPayload = {
    ...payload,
    objective: mode,
    servings: clampedServings,
    varieties: clampedVarieties,
    sophistication,
  };
  
  // Gerar plano com payload limitado
  const plan = await createAndStorePlan({
    userId: null,
    input: clampedPayload,
  });
  
  // Retornar com flag isAnonymous
  return {
    planId: plan.id,
    sessionId: plan.sessionId,
    plan: {
      ...plan,
      isAnonymous: true,
    },
  };
})
```

**Garantias:**
- Mesmo que o frontend tente burlar, o backend força os limites
- Flag `isAnonymous: true` permite UI identificar planos de teste
- Compatível com rate limiting existente (PATCH 8.4.1)

---

### 4. Nova Home com Copy Vendedora

**Arquivo modificado:** `client/src/pages/Home.tsx`

**Mudanças principais:**

1. **Hero atualizado:**
   - Título focado em "marmitas saudáveis" e "poucos minutos"
   - Subtítulo menciona objetivos (emagrecer, ganhar massa, organizar)
   - CTA único e forte: "Gerar meu primeiro plano grátis"
   - Microcopy tranquilizador: "Sem cartão, sem login"

2. **Bullets de valor:**
   - Aproveita o que tem em casa (reduz desperdício)
   - Mostra calorias (saúde)
   - Lista de compras pronta (praticidade)

3. **Tracking de fonte:**
   - Links com `?src=home`, `?src=header`, `?src=pricing`, `?src=cta-final`
   - Integração com funil de aquisição (PATCH 8.1.0)

---

### 5. Locks no Planner

**Arquivo modificado:** `client/src/pages/Planner.tsx`

#### 5.1. Locks de Modos

```tsx
{(Object.entries(MODE_LABELS) as [PlannerMode, string][]).map(([modeKey, label]) => {
  const isLocked = !isAuthenticated && !ANONYMOUS_LIMITS.allowedModes.includes(modeKey);
  
  return (
    <button
      onClick={() => {
        if (isLocked) {
          setAuthMode("register");
          setAuthModalOpen(true);
        } else {
          setObjective(modeKey);
        }
      }}
      className={`... ${isLocked ? "opacity-60 cursor-not-allowed" : ""}`}
    >
      <div className="flex items-center gap-2">
        <span className="font-semibold">{label}</span>
        {isLocked && <Lock className="w-4 h-4 text-muted-foreground" />}
      </div>
      <div className="text-sm text-muted-foreground">
        {MODE_DESCRIPTIONS[modeKey]}
      </div>
      {isLocked && (
        <div className="mt-2 text-xs text-primary font-medium">
          Crie sua conta para desbloquear este modo
        </div>
      )}
    </button>
  );
})}
```

**Resultado:**
- Modos "Aproveitamento", "Low Cal" e "High Protein" aparecem com lock
- Ao clicar, abre modal de cadastro
- Visual: opacidade reduzida + ícone de cadeado

#### 5.2. Limites de Sliders

```tsx
<Slider
  id="servings"
  min={6}
  max={!isAuthenticated ? ANONYMOUS_LIMITS.maxServings : 20}
  step={1}
  value={servings}
  onValueChange={setServings}
/>
{!isAuthenticated && (
  <p className="text-xs text-muted-foreground mt-2">
    No plano de teste, você pode gerar até {ANONYMOUS_LIMITS.maxServings} porções.
    Crie sua conta para ter mais flexibilidade.
  </p>
)}
```

**Resultado:**
- Slider de porções limitado a 10 (vs 20)
- Slider de variedades limitado a 3 (vs 6)
- Microcopy explicativa abaixo de cada slider

#### 5.3. Lock de Sofisticação

```tsx
<button
  onClick={() => {
    if (!isAuthenticated && !ANONYMOUS_LIMITS.allowAdvancedSophistication) {
      setAuthMode("register");
      setAuthModalOpen(true);
    } else {
      setSophistication("gourmet");
    }
  }}
  className={`... ${
    !isAuthenticated && !ANONYMOUS_LIMITS.allowAdvancedSophistication
      ? "opacity-60 cursor-not-allowed"
      : ""
  }`}
>
  <div className="flex items-center gap-2 mb-1">
    <span className="font-semibold">👨‍🍳 Gourmet</span>
    {!isAuthenticated && !ANONYMOUS_LIMITS.allowAdvancedSophistication && (
      <Lock className="w-4 h-4 text-muted-foreground" />
    )}
  </div>
  {!isAuthenticated && !ANONYMOUS_LIMITS.allowAdvancedSophistication && (
    <div className="mt-2 text-xs text-primary font-medium">
      Disponível após criar conta
    </div>
  )}
</button>
```

**Resultado:**
- Botão "Gourmet" bloqueado para anônimos
- Ao clicar, abre modal de cadastro

---

### 6. Banner no PlanView

**Arquivo modificado:** `client/src/pages/PlanView.tsx`

```tsx
{(() => {
  // PATCH 8.7.0: Verificar se é plano anônimo (isAnonymous flag ou sessionId === 0)
  const isAnonymous = activePlan?.isAnonymous || activePlan?.sessionId === 0;
  if (!isAnonymous) return null;
  
  return (
    <Alert className="border-amber-300 bg-amber-50 text-amber-900">
      <AlertCircle className="h-4 w-4" />
      <AlertDescription>
        <div className="font-semibold mb-1">🍳 Plano de teste</div>
        <div className="text-sm mb-3">
          Este é um plano básico e gratuito para você experimentar o Planna.
          <br />
          <span className="font-medium">Limitações:</span> Apenas modo Normal, até 10 porções, até 3 pratos, nível Simples.
        </div>
        <div className="text-sm mb-3">
          🔓 <span className="font-medium">Crie sua conta grátis</span> para desbloquear:
          <ul className="list-disc list-inside ml-4 mt-1 text-xs">
            <li>Modos avançados (Aproveitamento, Low Cal, High Protein)</li>
            <li>Até 20 porções e 6 pratos diferentes</li>
            <li>Nível Gourmet</li>
            <li>Salvar e editar planos</li>
            <li>Regenerar pratos e listas</li>
          </ul>
        </div>
        <Button size="sm" onClick={() => setSignupModalOpen(true)} className="mt-2">
          Criar conta agora (grátis)
        </Button>
      </AlertDescription>
    </Alert>
  );
})()}
```

**Resultado:**
- Banner amarelo no topo do plano
- Lista clara de limitações
- Lista de benefícios ao criar conta
- CTA forte: "Criar conta agora (grátis)"

---

## 🧪 Testes Automatizados

**Arquivo criado:** `server/anonymous-limits.test.ts`

**Cobertura:** 18 testes (100% passando)

```bash
✓ server/anonymous-limits.test.ts (18 tests) 9ms
  ✓ 1. Configuração de limites (4 tests)
  ✓ 2. Clamp de servings (3 tests)
  ✓ 3. Clamp de varieties (3 tests)
  ✓ 4. Enforcement de mode (5 tests)
  ✓ 5. Enforcement de sophistication (2 tests)
  ✓ 6. Payload completo clamped (1 test)
```

**Cenários testados:**
1. Configuração correta de limites
2. Clamp de servings (abaixo, igual, acima do limite)
3. Clamp de varieties (abaixo, igual, acima do limite)
4. Bloqueio de modos avançados
5. Fallback para modo "normal"
6. Bloqueio de sofisticação "gourmet"
7. Payload completo com todos os campos clamped

---

## 📊 Impacto no Funil de Conversão

### Antes (PATCH 8.6.0)
- Home → 1º plano grátis (sem limitações) → Cadastro
- Usuário não via valor em criar conta (plano grátis já era completo)

### Depois (PATCH 8.7.0)
- Home (copy vendedora) → 1º plano grátis (limitado) → Cadastro
- Usuário experimenta versão básica
- Vê locks visuais de recursos avançados
- Entende valor de criar conta (desbloquear features)

**Expectativa:**
- ↑ Taxa de conversão de anônimo → cadastrado
- ↑ Percepção de valor da conta gratuita
- ↑ Clareza sobre diferencial do produto

---

## 🎨 Exemplos Visuais

### Home Hero (Nova Copy)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ✨ Planejamento automático com IA

  Planeje suas marmitas saudáveis da semana
  em poucos minutos, com IA

  Diga o que tem em casa, escolha seu objetivo
  (emagrecer, ganhar massa ou só organizar a semana)
  e receba um plano completo com receitas, calorias
  por porção e lista de compras pronta.

  [Gerar meu primeiro plano grátis]

  Sem cartão de crédito, sem login. Você testa
  com 1 plano completo e depois decide se continua.

  ✓ Aproveita melhor o que você já tem em casa
  ✓ Mostra calorias por porção e por prato
  ✓ Entrega lista de compras pronta para a semana
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Planner (Locks Visuais)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Qual seu objetivo principal?

┌─────────────────┐  ┌─────────────────┐
│ 🍳 Modo Normal  │  │ ♻️ Aproveitamen │
│ Receitas        │  │ to Total   🔒   │
│ tradicionais    │  │ Reduz desperdí- │
│                 │  │ cio             │
│ [SELECIONADO]   │  │ Crie sua conta  │
│                 │  │ para desbloquear│
└─────────────────┘  └─────────────────┘

┌─────────────────┐  ┌─────────────────┐
│ 🔥 Low Cal  🔒  │  │ 💪 High Protein │
│ Menos calorias  │  │ 🔒              │
│ por porção      │  │ Mais proteína   │
│ Crie sua conta  │  │ Crie sua conta  │
│ para desbloquear│  │ para desbloquear│
└─────────────────┘  └─────────────────┘
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### PlanView (Banner de Teste)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️  🍳 Plano de teste

Este é um plano básico e gratuito para você
experimentar o Planna.

Limitações: Apenas modo Normal, até 10 porções,
até 3 pratos, nível Simples.

🔓 Crie sua conta grátis para desbloquear:
  • Modos avançados (Aproveitamento, Low Cal, High Protein)
  • Até 20 porções e 6 pratos diferentes
  • Nível Gourmet
  • Salvar e editar planos
  • Regenerar pratos e listas

[Criar conta agora (grátis)]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## ✅ Checklist de Implementação

### Backend
- [x] Criar `shared/free-trial.ts` com ANONYMOUS_LIMITS
- [x] Atualizar `generateAnonymousPlan` com clamp de servings
- [x] Atualizar `generateAnonymousPlan` com clamp de varieties
- [x] Atualizar `generateAnonymousPlan` com enforcement de mode
- [x] Atualizar `generateAnonymousPlan` com enforcement de sophistication
- [x] Retornar flag `isAnonymous: true` no plano

### Frontend - Home
- [x] Criar `client/src/config/marketing.ts` com HOME_COPY
- [x] Atualizar hero com heroTitle, heroSubtitle, heroCta
- [x] Adicionar heroMicrocopy abaixo do CTA
- [x] Renderizar heroBullets
- [x] Atualizar meta tags (seoTitle, seoDescription)
- [x] Adicionar tracking de fonte (?src=)

### Frontend - Planner
- [x] Importar ANONYMOUS_LIMITS
- [x] Adicionar locks visuais em modos avançados
- [x] Adicionar ícone Lock (lucide-react)
- [x] Limitar max de slider de servings (10 para anônimos)
- [x] Limitar max de slider de varieties (3 para anônimos)
- [x] Adicionar microcopy explicativa abaixo dos sliders
- [x] Bloquear botão "Gourmet" para anônimos
- [x] Abrir AuthModal ao clicar em recursos bloqueados

### Frontend - PlanView
- [x] Detectar plano anônimo (isAnonymous flag ou sessionId === 0)
- [x] Atualizar banner com nova copy
- [x] Listar limitações do plano de teste
- [x] Listar benefícios de criar conta
- [x] CTA "Criar conta agora (grátis)"

### Testes
- [x] Criar `server/anonymous-limits.test.ts`
- [x] 18 testes cobrindo todos os cenários
- [x] 100% de taxa de sucesso

---

## 🚀 Próximos Passos Sugeridos

1. **A/B Testing:**
   - Testar variações de copy no hero
   - Testar posicionamento do microcopy
   - Testar cores do banner de teste

2. **Analytics:**
   - Medir taxa de conversão anônimo → cadastrado
   - Medir cliques em recursos bloqueados
   - Medir tempo até cadastro após ver locks

3. **Melhorias de UX:**
   - Adicionar tooltip hover nos locks
   - Adicionar animação ao clicar em recurso bloqueado
   - Adicionar preview de recursos avançados

---

## 📝 Notas Técnicas

### Compatibilidade
- ✅ Compatível com PATCH 7.9.0 (planos anônimos)
- ✅ Compatível com PATCH 8.1.0 (funil de aquisição)
- ✅ Compatível com PATCH 8.4.1 (rate limiting)
- ✅ Compatível com PATCH 8.5.0 (mensagens de erro)
- ✅ Compatível com PATCH 8.6.0 (regeneração de lista)

### Segurança
- ✅ Enforcement no backend (frontend não é confiável)
- ✅ Rate limiting mantido (2 gerações/minuto)
- ✅ Limite de 1 plano por anonymousId mantido

### Performance
- ✅ Sem impacto na geração de planos
- ✅ Sem queries adicionais ao banco
- ✅ Locks renderizados apenas no cliente

---

## 🎯 Métricas de Sucesso

**Antes do PATCH:**
- Taxa de conversão anônimo → cadastrado: ~X%
- Tempo médio até cadastro: ~Y minutos

**Após o PATCH (expectativa):**
- Taxa de conversão anônimo → cadastrado: ↑ 20-30%
- Tempo médio até cadastro: ↓ 15-20%
- Cliques em recursos bloqueados: > 50% dos anônimos

---

## ✅ Status Final

- ✅ **Implementação:** 100% completa
- ✅ **Testes:** 18/18 passando
- ✅ **TypeScript:** 0 erros de compilação
- ✅ **Build:** Sucesso sem warnings
- ✅ **Documentação:** Completa e atualizada

---

**Versão do Relatório:** 1.0  
**Data de Geração:** 06/12/2025  
**Implementado por:** Manus AI
