/**
 * PATCH 8.9.0 - Testes do UpgradeModal
 * 
 * Valida mensagens contextuais por reason e lógica de navegação.
 */

import { describe, it, expect } from "vitest";

describe("UpgradeModal - Context Messages", () => {
  it("deve ter mensagem específica para limit_plans", () => {
    const getContextMessage = (reason?: string) => {
      switch (reason) {
        case "limit_plans":
          return "Você já está usando o Planna de verdade, agora falta só liberar mais planos. Faça upgrade e continue planejando suas marmitas sem limites!";
        case "feature_locked_regen_dish":
          return "Você está esbarrando nas features avançadas que fazem você economizar tempo. Regenerar pratos é exclusivo dos planos Pro e Premium!";
        case "feature_locked_regen_list":
          return "Você está esbarrando nas features avançadas que fazem você economizar tempo. Regenerar lista de compras é exclusivo dos planos Pro e Premium!";
        default:
          return "Desbloqueie todos os recursos do Planna com um plano pago!";
      }
    };

    const message = getContextMessage("limit_plans");
    expect(message).toContain("já está usando o Planna de verdade");
    expect(message).toContain("liberar mais planos");
  });

  it("deve ter mensagem específica para feature_locked_regen_dish", () => {
    const getContextMessage = (reason?: string) => {
      switch (reason) {
        case "limit_plans":
          return "Você já está usando o Planna de verdade, agora falta só liberar mais planos. Faça upgrade e continue planejando suas marmitas sem limites!";
        case "feature_locked_regen_dish":
          return "Você está esbarrando nas features avançadas que fazem você economizar tempo. Regenerar pratos é exclusivo dos planos Pro e Premium!";
        case "feature_locked_regen_list":
          return "Você está esbarrando nas features avançadas que fazem você economizar tempo. Regenerar lista de compras é exclusivo dos planos Pro e Premium!";
        default:
          return "Desbloqueie todos os recursos do Planna com um plano pago!";
      }
    };

    const message = getContextMessage("feature_locked_regen_dish");
    expect(message).toContain("esbarrando nas features avançadas");
    expect(message).toContain("economizar tempo");
    expect(message).toContain("Regenerar pratos");
  });

  it("deve ter mensagem específica para feature_locked_regen_list", () => {
    const getContextMessage = (reason?: string) => {
      switch (reason) {
        case "limit_plans":
          return "Você já está usando o Planna de verdade, agora falta só liberar mais planos. Faça upgrade e continue planejando suas marmitas sem limites!";
        case "feature_locked_regen_dish":
          return "Você está esbarrando nas features avançadas que fazem você economizar tempo. Regenerar pratos é exclusivo dos planos Pro e Premium!";
        case "feature_locked_regen_list":
          return "Você está esbarrando nas features avançadas que fazem você economizar tempo. Regenerar lista de compras é exclusivo dos planos Pro e Premium!";
        default:
          return "Desbloqueie todos os recursos do Planna com um plano pago!";
      }
    };

    const message = getContextMessage("feature_locked_regen_list");
    expect(message).toContain("esbarrando nas features avançadas");
    expect(message).toContain("economizar tempo");
    expect(message).toContain("Regenerar lista de compras");
  });

  it("deve ter mensagem genérica para reason desconhecido", () => {
    const getContextMessage = (reason?: string) => {
      switch (reason) {
        case "limit_plans":
          return "Você já está usando o Planna de verdade, agora falta só liberar mais planos. Faça upgrade e continue planejando suas marmitas sem limites!";
        case "feature_locked_regen_dish":
          return "Você está esbarrando nas features avançadas que fazem você economizar tempo. Regenerar pratos é exclusivo dos planos Pro e Premium!";
        case "feature_locked_regen_list":
          return "Você está esbarrando nas features avançadas que fazem você economizar tempo. Regenerar lista de compras é exclusivo dos planos Pro e Premium!";
        default:
          return "Desbloqueie todos os recursos do Planna com um plano pago!";
      }
    };

    const message = getContextMessage("unknown");
    expect(message).toBe("Desbloqueie todos os recursos do Planna com um plano pago!");
  });

  it("deve ter mensagem genérica quando reason é undefined", () => {
    const getContextMessage = (reason?: string) => {
      switch (reason) {
        case "limit_plans":
          return "Você já está usando o Planna de verdade, agora falta só liberar mais planos. Faça upgrade e continue planejando suas marmitas sem limites!";
        case "feature_locked_regen_dish":
          return "Você está esbarrando nas features avançadas que fazem você economizar tempo. Regenerar pratos é exclusivo dos planos Pro e Premium!";
        case "feature_locked_regen_list":
          return "Você está esbarrando nas features avançadas que fazem você economizar tempo. Regenerar lista de compras é exclusivo dos planos Pro e Premium!";
        default:
          return "Desbloqueie todos os recursos do Planna com um plano pago!";
      }
    };

    const message = getContextMessage();
    expect(message).toBe("Desbloqueie todos os recursos do Planna com um plano pago!");
  });
});

describe("UpgradeModal - Navigation Logic", () => {
  it("deve construir URL correta para /planos com query params", () => {
    const buildPricingUrl = (reason?: string) => {
      return `/planos?from=upgrade_modal&reason=${reason || 'general'}`;
    };

    expect(buildPricingUrl("limit_plans")).toBe("/planos?from=upgrade_modal&reason=limit_plans");
    expect(buildPricingUrl("feature_locked_regen_dish")).toBe("/planos?from=upgrade_modal&reason=feature_locked_regen_dish");
    expect(buildPricingUrl()).toBe("/planos?from=upgrade_modal&reason=general");
  });

  it("deve ter price IDs corretos do Stripe", () => {
    const STRIPE_PRICE_IDS = {
      pro: "price_1SUPvOKHYuEw9LKlDGmXKmjD",
      premium: "price_1SVInaKHYuEw9LKlKEAg3pps",
    };

    expect(STRIPE_PRICE_IDS.pro).toBe("price_1SUPvOKHYuEw9LKlDGmXKmjD");
    expect(STRIPE_PRICE_IDS.premium).toBe("price_1SVInaKHYuEw9LKlKEAg3pps");
  });
});

describe("UpgradeModal - Pricing Display", () => {
  it("deve exibir preços corretos na tabela comparativa", () => {
    const PRICING = {
      pro: "R$ 9,90/mês",
      premium: "R$ 14,99/mês",
    };

    expect(PRICING.pro).toBe("R$ 9,90/mês");
    expect(PRICING.premium).toBe("R$ 14,99/mês");
  });

  it("deve ter badge 'Mais Popular' no plano Pro", () => {
    const mostPopularTier = "pro";
    expect(mostPopularTier).toBe("pro");
  });
});
