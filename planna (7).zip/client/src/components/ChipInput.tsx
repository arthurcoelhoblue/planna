/**
 * PATCH 7.7.0 - ChipInput Component
 * 
 * Componente compartilhado para gerenciar listas de strings com chips.
 * Suporta adição via Enter, vírgula e quebra de linha.
 * Suporta remoção individual via botão ×.
 * Suporta variants (red, green, default) para diferentes contextos.
 */

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

type ChipVariant = "red" | "green" | "default";

interface ChipInputProps {
  label: string;
  description?: string;
  placeholder?: string;
  items: string[];
  onChange: (items: string[]) => void;
  emptyHint?: string;
  variant?: ChipVariant;
}

export function ChipInput({
  label,
  description,
  placeholder = "Digite e aperte Enter ou vírgula",
  items,
  onChange,
  emptyHint = "Nenhum item adicionado.",
  variant = "default",
}: ChipInputProps) {
  const [input, setInput] = useState("");

  const baseChipClasses =
    "inline-flex items-center rounded-full px-2 py-0.5 text-xs";
  const variantClasses: Record<ChipVariant, string> = {
    red: "bg-red-100 text-red-800",
    green: "bg-emerald-100 text-emerald-800",
    default: "bg-muted text-foreground",
  };

  function addFromInput() {
    const parts = input
      .split(/[,\n]/)
      .map((s) => s.trim())
      .filter(Boolean);

    if (!parts.length) return;
    const normalized = Array.from(
      new Set([...items, ...parts].map((s) => s.trim()).filter(Boolean))
    );
    onChange(normalized);
    setInput("");
  }

  function removeItem(item: string) {
    onChange(items.filter((x) => x !== item));
  }

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium">{label}</label>
      {description && (
        <p className="text-xs text-muted-foreground">{description}</p>
      )}

      <div className="flex flex-wrap gap-2 mb-2">
        {items.map((item) => (
          <span
            key={item}
            className={`${baseChipClasses} ${variantClasses[variant]}`}
          >
            {item}
            <button
              type="button"
              className="ml-1 text-[10px]"
              onClick={() => removeItem(item)}
            >
              ×
            </button>
          </span>
        ))}
        {items.length === 0 && (
          <span className="text-xs text-muted-foreground">{emptyHint}</span>
        )}
      </div>

      <div className="flex gap-2">
        <Input
          placeholder={placeholder}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              addFromInput();
            }
          }}
        />
        <Button type="button" variant="outline" onClick={addFromInput}>
          Adicionar
        </Button>
      </div>
    </div>
  );
}
