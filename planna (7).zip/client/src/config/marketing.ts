// PATCH 8.7.0: Fonte de verdade dos textos da Home
export const HOME_COPY = {
  heroTitle: "Planeje suas marmitas saudáveis da semana em poucos minutos, com IA",
  heroSubtitle:
    "Diga o que tem em casa, escolha seu objetivo (emagrecer, ganhar massa ou só organizar a semana) e receba um plano completo com receitas, calorias por porção e lista de compras pronta.",
  heroSubtitleShort:
    "Emagrecer, ganhar massa ou só organizar a semana sem perder tempo pensando no que cozinhar.",
  heroCta: "Gerar meu primeiro plano grátis",
  heroMicrocopy: "Sem cartão de crédito. Você testa com 1 plano básico grátis.",

  // Bullets de valor abaixo do hero
  heroBullets: [
    "Aproveita melhor o que você já tem em casa",
    "Mostra calorias por porção e por prato",
    "Entrega uma lista de compras pronta para imprimir ou salvar",
  ],

  seoTitle: "Planna – Planejador de Marmitas Saudáveis com IA",
  seoDescription:
    "Planeje suas marmitas saudáveis da semana em poucos minutos. Use IA para montar planos de marmitas para emagrecer, ganhar massa e evitar desperdício, com calorias e lista de compras prontas.",
};
