/**
 * PATCH 9.0.0 - Testes de Impressão no SharedPlan
 * 
 * Valida que window.print() está disponível e funcional
 * na página de plano compartilhado.
 * 
 * @vitest-environment jsdom
 */

import { describe, expect, it, vi, beforeEach } from "vitest";

describe("SharedPlan - Print Functionality", () => {
  beforeEach(() => {
    // Mock window.print
    if (typeof window !== "undefined") {
      window.print = vi.fn();
    } else {
      (global as any).window = { print: vi.fn() };
    }
  });

  it("deve ter window.print disponível", () => {
    expect(window.print).toBeDefined();
  });

  it("deve chamar window.print() quando invocado", () => {
    window.print();
    expect(window.print).toHaveBeenCalledTimes(1);
  });
});
