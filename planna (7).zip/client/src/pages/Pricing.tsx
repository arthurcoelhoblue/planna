import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { TIER_DESCRIPTIONS, TIER_LABELS, TIER_LIMITS, type SubscriptionTier, type TierLimits } from "@shared/tier-limits";
import { Check, X } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

/**
 * PATCH 8.9.0 - Página de Planos & Preços
 * 
 * Página dedicada com tabela comparativa de tiers usando TIER_LIMITS como fonte única.
 * Integração com Stripe para checkout de Pro/Premium.
 */

const PRICING = {
  free: { price: "R$ 0", period: "sempre" },
  pro: { price: "R$ 9,90", period: "/mês" },
  premium: { price: "R$ 14,99", period: "/mês" },
} as const;

const MICROCOPY = {
  free: "Pra testar o Planna e usar em semanas pontuais.",
  pro: "Pra quem cozinha toda semana pra si ou pro casal.",
  premium: "Pra famílias, atletas ou quem vive de marmita todo dia.",
} as const;

const FEATURES: Array<{
  key: string;
  label: string;
  format: (v: any) => string | boolean;
}> = [
  { key: "maxPlansPerMonth", label: "Planos por mês", format: (v: number) => v === Infinity ? "Ilimitado" : String(v) },
  { key: "maxServings", label: "Porções por plano", format: (v: number) => String(v) },
  { key: "maxVarieties", label: "Variedades (misturas)", format: (v: number) => String(v) },
  { key: "allowAdvancedModes", label: "Modos avançados", format: (v: boolean) => v },
  { key: "allowRegenerateDish", label: "Regenerar pratos", format: (v: boolean) => v },
  { key: "allowRegenerateList", label: "Regenerar lista", format: (v: boolean) => v },
  { key: "allowVersionHistory", label: "Histórico/rollback", format: (v: boolean) => v },
  { key: "maxIngredientDetectionsPerMonth", label: "Detecção por foto/mês", format: (v: number) => v === Infinity ? "Ilimitado" : String(v) },
];

export default function Pricing() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [loadingTier, setLoadingTier] = useState<SubscriptionTier | null>(null);

  const createCheckout = trpc.subscription.createCheckout.useMutation({
    onSuccess: (data) => {
      if (data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
      } else {
        toast.error("Erro ao processar pagamento. Tente novamente.");
      }
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao criar checkout");
      setLoadingTier(null);
    },
  });

  const handleSubscribe = (tier: "pro" | "premium") => {
    if (!isAuthenticated) {
      toast.info("Crie uma conta gratuita primeiro para assinar");
      setLocation("/");
      return;
    }

    setLoadingTier(tier);
    
    // Mapear tier para priceId (mesma lógica do Home.tsx)
    const priceId = tier === "pro" 
      ? "price_1SUPvOKHYuEw9LKlDGmXKmjD" 
      : "price_1SVInaKHYuEw9LKlKEAg3pps";

    createCheckout.mutate({ priceId });
  };

  const currentTier = (user?.subscriptionTier || "free") as SubscriptionTier;
  
  // PATCH 9.6.0: Hierarquia de tiers para bloquear downgrade
  const tierHierarchy: Record<SubscriptionTier, number> = {
    free: 0,
    pro: 1,
    premium: 2,
    vip: 3,
  };
  
  const currentLevel = tierHierarchy[currentTier] || 0;

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white py-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Escolha o plano ideal para suas marmitas
          </h1>
          <p className="text-xl text-gray-600">
            Comece grátis e faça upgrade quando o Planna fizer parte da sua rotina.
          </p>
        </div>

        {/* Cards de Planos */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {(["free", "pro", "premium"] as const).map((tier) => {
            const limits = TIER_LIMITS[tier];
            const isCurrent = currentTier === tier;
            const isPro = tier === "pro";
            const isPremium = tier === "premium";
            const isLoading = loadingTier === tier;
            
            // PATCH 9.6.0: Bloquear downgrade
            const targetLevel = tierHierarchy[tier] || 0;
            const isDowngrade = currentLevel > targetLevel;

            return (
              <Card 
                key={tier} 
                className={`relative ${isPro ? "border-green-500 border-2 shadow-lg" : ""}`}
              >
                {isPro && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-green-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                    Mais Popular
                  </div>
                )}
                
                <CardHeader>
                  <CardTitle className="text-2xl">{TIER_LABELS[tier]}</CardTitle>
                  <CardDescription className="min-h-[3rem]">
                    {MICROCOPY[tier]}
                  </CardDescription>
                  <div className="mt-4">
                    <span className="text-4xl font-bold">{PRICING[tier].price}</span>
                    <span className="text-gray-600">{PRICING[tier].period}</span>
                  </div>
                </CardHeader>

                <CardContent>
                  <ul className="space-y-3">
                    {FEATURES.map((feature) => {
                      const value = (limits as any)[feature.key];
                      const formatted = feature.format(value as any);
                      const isBoolean = typeof formatted === "boolean";

                      return (
                        <li key={feature.key} className="flex items-start gap-2">
                          {isBoolean ? (
                            formatted ? (
                              <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                            ) : (
                              <X className="w-5 h-5 text-gray-300 flex-shrink-0 mt-0.5" />
                            )
                          ) : (
                            <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                          )}
                          <span className={isBoolean && !formatted ? "text-gray-400" : ""}>
                            {feature.label}: <strong>{isBoolean ? (formatted ? "Sim" : "Não") : formatted}</strong>
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                </CardContent>

                <CardFooter>
                  {tier === "free" ? (
                    <Button 
                      variant="outline" 
                      className="w-full"
                      disabled={isCurrent}
                      onClick={() => setLocation("/")}
                    >
                      {isCurrent ? "Seu plano atual" : "Continuar no plano Free"}
                    </Button>
                  ) : (
                    <Button 
                      className="w-full"
                      disabled={isCurrent || isLoading || isDowngrade}
                      onClick={() => handleSubscribe(tier)}
                      title={isDowngrade ? "Não é possível fazer downgrade. Use o portal de assinatura para cancelar." : ""}
                    >
                      {isCurrent 
                        ? "Seu plano atual" 
                        : isDowngrade
                        ? "Plano inferior"
                        : isLoading 
                        ? "Processando..." 
                        : `Assinar ${TIER_LABELS[tier]}`}
                    </Button>
                  )}
                </CardFooter>
              </Card>
            );
          })}
        </div>

        {/* Nota de Segurança */}
        <div className="text-center text-sm text-gray-600">
          <p>
            💳 Pagamento seguro via Stripe • Cancele quando quiser • Sem taxas ocultas
          </p>
        </div>
      </div>
    </div>
  );
}
