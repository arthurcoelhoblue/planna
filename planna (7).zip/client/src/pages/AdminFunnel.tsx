import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import DashboardLayout from "@/components/DashboardLayout";

/**
 * PATCH 8.1.0: Admin Funnel Analytics Page
 * Displays acquisition funnel metrics by source
 */
export default function AdminFunnel() {
  const [adminSecret, setAdminSecret] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const { data, isLoading, error, refetch } = trpc.admin.funnelStats.useQuery(
    { adminSecret },
    { enabled: submitted && adminSecret.length > 0 }
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminSecret.trim()) {
      toast.error("Por favor, insira o secret de admin");
      return;
    }
    setSubmitted(true);
    refetch();
  };

  return (
    <DashboardLayout>
      <main className="container py-8 max-w-4xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2">Funil de Aquisição</h1>
          <p className="text-muted-foreground">
            Métricas de conversão por fonte de tráfego
          </p>
        </div>

        {/* Secret Input Form */}
        {!submitted && (
          <Card>
            <CardHeader>
              <CardTitle>Autenticação Admin</CardTitle>
              <CardDescription>
                Insira o secret de admin para visualizar as métricas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="secret">Admin Secret</Label>
                  <Input
                    id="secret"
                    type="password"
                    value={adminSecret}
                    onChange={(e) => setAdminSecret(e.target.value)}
                    placeholder="Digite o secret de admin"
                  />
                </div>
                <Button type="submit">Visualizar Métricas</Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Loading State */}
        {submitted && isLoading && (
          <Card>
            <CardContent className="py-8 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Carregando métricas...</p>
            </CardContent>
          </Card>
        )}

        {/* Error State */}
        {submitted && error && (
          <Card className="border-red-200 bg-red-50">
            <CardContent className="py-6">
              <p className="text-red-800 font-semibold mb-2">Erro ao carregar métricas</p>
              <p className="text-red-600 text-sm">{error.message}</p>
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => {
                  setSubmitted(false);
                  setAdminSecret("");
                }}
              >
                Tentar Novamente
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Data Table */}
        {submitted && data && !isLoading && (
          <Card>
            <CardHeader>
              <CardTitle>Métricas por Fonte</CardTitle>
              <CardDescription>
                Conversão de planos anônimos para cadastros
              </CardDescription>
            </CardHeader>
            <CardContent>
              {data.sources.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  Nenhum dado disponível ainda
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-muted">
                        <th className="p-3 text-left font-semibold">Fonte</th>
                        <th className="p-3 text-right font-semibold">Planos Anônimos</th>
                        <th className="p-3 text-right font-semibold">Cadastros</th>
                        <th className="p-3 text-right font-semibold">Conversão</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.sources.map((row) => (
                        <tr key={row.source} className="border-t hover:bg-muted/50">
                          <td className="p-3">
                            <span className="font-medium">{row.source}</span>
                          </td>
                          <td className="p-3 text-right">{row.anonymousPlans}</td>
                          <td className="p-3 text-right">{row.signups}</td>
                          <td className="p-3 text-right">
                            {row.conversionRate != null ? (
                              <span className="font-semibold text-green-600">
                                {(row.conversionRate * 100).toFixed(1)}%
                              </span>
                            ) : (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              <div className="mt-6 pt-6 border-t">
                <h3 className="font-semibold mb-2">Legenda de Fontes</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li><strong>home:</strong> Usuários que vieram direto da landing page</li>
                  <li><strong>share:</strong> Usuários que vieram de links compartilhados</li>
                  <li><strong>share_whatsapp:</strong> Usuários que vieram de compartilhamento via WhatsApp</li>
                  <li><strong>unknown:</strong> Fonte não identificada</li>
                </ul>
              </div>

              <Button
                variant="outline"
                className="mt-4"
                onClick={() => {
                  setSubmitted(false);
                  setAdminSecret("");
                }}
              >
                Voltar
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </DashboardLayout>
  );
}
