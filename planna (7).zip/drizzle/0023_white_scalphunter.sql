ALTER TABLE `anonymous_plans` ADD `source` varchar(64) DEFAULT 'unknown' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `source` varchar(64) DEFAULT 'unknown' NOT NULL;