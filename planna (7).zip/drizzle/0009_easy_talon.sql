ALTER TABLE `plans` ADD `totalKcal` int;--> statement-breakpoint
ALTER TABLE `plans` ADD `avgKcalPerServing` int;