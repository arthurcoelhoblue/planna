import { boolean, int, json, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  emailVerified: boolean("emailVerified").default(false).notNull(), // Email verification status
  passwordHash: varchar("passwordHash", { length: 255 }), // For local auth (bcrypt hash)
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  // Stripe integration
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }), // Stripe Customer ID
  subscriptionTier: mysqlEnum("subscriptionTier", ["free", "pro", "premium"]).default("free").notNull(),
  source: varchar("source", { length: 64 }).default("unknown").notNull(), // PATCH 8.1.0: Acquisition source (home, share, share_whatsapp, etc.)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * User preferences for meal planning
 */
export const userPreferences = mysqlTable("user_preferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  
  // PATCH 7.0.0: Planner defaults
  mode: varchar("mode", { length: 32 }).notNull().default("normal"), // normal, aproveitamento, lowcal, highprotein
  servings: int("servings").notNull().default(10), // Default number of servings/meals
  varieties: int("varieties").notNull().default(3), // Default number of dish varieties
  time: int("time"), // Typical available prep time (in minutes) - can be null
  allowNewIngredients: boolean("allow_new_ingredients").notNull().default(true), // Allow new ingredients beyond stock
  
  // Existing fields
  exclusions: text("exclusions"), // JSON array of excluded ingredients
  favorites: text("favorites"), // JSON array of favorite ingredients
  skillLevel: mysqlEnum("skillLevel", ["beginner", "intermediate", "advanced"]).default("intermediate"),
  dietType: varchar("dietType", { length: 100 }), // Nome da dieta escolhida
  dietProfile: text("dietProfile"), // JSON do perfil completo da dieta
  maxKcalPerServing: int("maxKcalPerServing"), // Limite de calorias por porção
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserPreference = typeof userPreferences.$inferSelect;
export type InsertUserPreference = typeof userPreferences.$inferInsert;

/**
 * Planning sessions - each time a user generates a meal plan
 */
export const sessions = mysqlTable("sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  inputText: text("inputText").notNull(), // Raw ingredient input from user
  servings: int("servings").notNull(), // Number of meals to plan
  // PATCH 7.3.0: Expandido para incluir lowcal e highprotein
  objective: mysqlEnum("objective", ["normal", "aproveitamento", "lowcal", "highprotein"]).default("normal"),
  exclusions: text("exclusions"), // JSON array of excluded ingredients for this session
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Session = typeof sessions.$inferSelect;
export type InsertSession = typeof sessions.$inferInsert;

/**
 * Generated meal plans
 */
export const plans = mysqlTable("plans", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  dishes: text("dishes").notNull(), // JSON array of dishes with ingredients and steps
  shoppingList: text("shoppingList").notNull(), // JSON array of shopping items by category
  prepSchedule: text("prepSchedule").notNull(), // JSON array of ordered prep steps
  exportUrl: varchar("exportUrl", { length: 512 }), // PDF export URL
  totalKcal: int("totalKcal"), // Total calories of the plan
  avgKcalPerServing: int("avgKcalPerServing"), // Average calories per serving
  dietType: varchar("dietType", { length: 128 }), // Diet type (e.g., "vegetariana", "vegana")
  mode: varchar("mode", { length: 64 }), // Mode: "normal" or "aproveitamento"
  skillLevel: varchar("skillLevel", { length: 64 }), // Skill level: "beginner", "intermediate", "advanced"
  availableTime: int("availableTime"), // Available time in hours (user input)
  totalPlanTime: int("totalPlanTime"), // Total plan time in minutes (calculated)
  timeFits: boolean("timeFits"), // Whether plan fits in available time (with 50% margin)
  allowNewIngredients: boolean("allowNewIngredients").default(true), // Whether to allow new ingredients
  maxKcalPerServing: int("maxKcalPerServing"), // Max calories per serving limit
  shareToken: varchar("shareToken", { length: 64 }), // Unique token for sharing
  shareCount: int("shareCount").default(0), // Number of times shared link was accessed
  requestedVarieties: int("requestedVarieties"), // Number of varieties (misturas) requested by user
  requestedServings: int("requestedServings"), // Number of servings requested by user
  adjustmentReason: text("adjustmentReason"), // Explanation when system couldn't fulfill exact request
  usedStock: text("usedStock"), // JSON object with used stock quantities {"frango": "800g", "arroz": "200g"}
  remainingStock: text("remainingStock"), // JSON object with remaining stock quantities
  substitutions: text("substitutions"), // JSON array of substitutions [{original: "X", replacement: "Y"}]
  deletedAt: timestamp("deletedAt"), // PATCH 8.4.0: Soft delete timestamp
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Plan = typeof plans.$inferSelect;
export type InsertPlan = typeof plans.$inferInsert;

/**
 * User feedback on dishes - for learning and personalization
 */
export const dishFeedback = mysqlTable("dish_feedback", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  planId: int("planId").notNull(),
  dishName: varchar("dishName", { length: 256 }).notNull(),
  rating: mysqlEnum("rating", ["liked", "disliked"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DishFeedback = typeof dishFeedback.$inferSelect;
export type InsertDishFeedback = typeof dishFeedback.$inferInsert;

/**
 * Stripe subscriptions - minimal schema following Stripe best practices
 * Only stores IDs for API reference, fetches live data from Stripe API
 */
export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }), // Customer ID from Stripe
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }).notNull().unique(), // Subscription ID from Stripe
  stripePriceId: varchar("stripePriceId", { length: 255 }).notNull(), // Price ID for this subscription
  status: mysqlEnum("status", ["active", "canceled", "past_due", "trialing"]).notNull(),
  currentPeriodEnd: timestamp("currentPeriodEnd"), // Cache for quick access checks
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

/**
 * Email verification codes for 2FA during registration
 */
export const emailVerificationCodes = mysqlTable("email_verification_codes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  code: varchar("code", { length: 6 }).notNull(), // 6-digit code
  expiresAt: timestamp("expiresAt").notNull(), // Expiration time (e.g., 15 minutes)
  verified: boolean("verified").default(false).notNull(), // Whether code was used
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EmailVerificationCode = typeof emailVerificationCodes.$inferSelect;
export type InsertEmailVerificationCode = typeof emailVerificationCodes.$inferInsert;

/**
 * Password reset tokens for local authentication
 */
export const passwordResetTokens = mysqlTable("password_reset_tokens", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  token: varchar("token", { length: 64 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  used: mysqlEnum("used", ["yes", "no"]).default("no").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PasswordResetToken = typeof passwordResetTokens.$inferSelect;
export type InsertPasswordResetToken = typeof passwordResetTokens.$inferInsert;

/**
 * Plan versions - snapshots of meal plans for versioning and comparison
 * Allows tracking regenerations and comparing different versions of the same plan
 */
export const planVersions = mysqlTable("plan_versions", {
  id: int("id").autoincrement().primaryKey(),

  // ID do plano original (referência ao plans.id)
  planId: int("plan_id").notNull(),

  // Número da versão (começa em 1 e incrementa a cada nova versão)
  version: int("version").notNull(),

  // Momento em que essa versão foi criada
  createdAt: timestamp("created_at").notNull().defaultNow(),

  // Snapshot completo dos mesmos campos usados hoje em plans (tudo em JSON)
  dishes: json("dishes").notNull(),
  shoppingList: json("shopping_list").notNull(),
  prepSchedule: json("prep_schedule"),

  // Campos adicionados nos patches 5.x
  usedStock: json("used_stock"),
  remainingStock: json("remaining_stock"),
  substitutions: json("substitutions"),
});

export type PlanVersion = typeof planVersions.$inferSelect;
export type NewPlanVersion = typeof planVersions.$inferInsert;

/**
 * Anonymous plans - tracks plans generated by visitors without login
 * Allows limiting free plan generation (1 plan per anonymousId)
 */
export const anonymousPlans = mysqlTable("anonymous_plans", {
  id: int("id").autoincrement().primaryKey(),
  anonymousId: varchar("anonymous_id", { length: 64 }).notNull(), // UUID stored in localStorage
  planId: int("plan_id").notNull(), // Reference to plans.id
  source: varchar("source", { length: 64 }).default("unknown").notNull(), // PATCH 8.1.0: Acquisition source (home, share, share_whatsapp, etc.)
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type AnonymousPlan = typeof anonymousPlans.$inferSelect;
export type InsertAnonymousPlan = typeof anonymousPlans.$inferInsert;

/**
 * Mobile subscriptions - tracks IAP (In-App Purchase) subscriptions from Apple and Google
 * PATCH 8.3.0: Unified subscription model supporting Stripe + IAP + VIP
 */
export const mobileSubscriptions = mysqlTable("mobile_subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(), // Reference to users.id
  platform: mysqlEnum("platform", ["apple", "google"]).notNull(), // IAP platform
  productId: varchar("product_id", { length: 128 }).notNull(), // Apple/Google product ID
  tier: mysqlEnum("tier", ["free", "pro", "premium"]).notNull(), // Mapped tier from productId
  status: mysqlEnum("status", ["active", "canceled", "expired"]).notNull(), // Subscription status
  expiresAt: timestamp("expires_at"), // Expiration date (null for non-expiring)
  rawReceipt: text("raw_receipt"), // Raw receipt data for audit/debug
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type MobileSubscription = typeof mobileSubscriptions.$inferSelect;
export type InsertMobileSubscription = typeof mobileSubscriptions.$inferInsert;
