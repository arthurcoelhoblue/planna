ALTER TABLE `plans` ADD `requestedVarieties` int;--> statement-breakpoint
ALTER TABLE `plans` ADD `requestedServings` int;