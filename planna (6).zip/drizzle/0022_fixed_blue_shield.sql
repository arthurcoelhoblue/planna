CREATE TABLE `anonymous_plans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`anonymous_id` varchar(64) NOT NULL,
	`plan_id` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `anonymous_plans_id` PRIMARY KEY(`id`)
);
