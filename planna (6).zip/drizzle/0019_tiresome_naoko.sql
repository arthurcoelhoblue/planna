CREATE TABLE `plan_versions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`plan_id` int NOT NULL,
	`version` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`dishes` json NOT NULL,
	`shopping_list` json NOT NULL,
	`prep_schedule` json,
	`used_stock` json,
	`remaining_stock` json,
	`substitutions` json,
	CONSTRAINT `plan_versions_id` PRIMARY KEY(`id`)
);
