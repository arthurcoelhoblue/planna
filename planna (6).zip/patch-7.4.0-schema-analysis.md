# PATCH 7.4.0 - Análise de Campos Disponíveis

## Tabela `plans` (Schema)

### Campos Relevantes para o Card de Preferências

| Campo | Tipo | Descrição | Disponível? |
|-------|------|-----------|-------------|
| `mode` | varchar(64) | Modo: "normal", "aproveitamento", "lowcal", "highprotein" | ✅ Sim |
| `requestedServings` | int | Número de porções solicitadas | ✅ Sim |
| `requestedVarieties` | int | Número de variedades (misturas) solicitadas | ✅ Sim |
| `availableTime` | int | Tempo disponível em horas (input do usuário) | ✅ Sim |
| `allowNewIngredients` | boolean | Permitir novos ingredientes além do estoque | ✅ Sim (default: true) |
| `dietType` | varchar(128) | Tipo de dieta (ex: "vegetariana", "vegana") | ✅ Sim |
| `maxKcalPerServing` | int | Limite máximo de calorias por porção | ✅ Sim |
| `skillLevel` | varchar(64) | Nível de habilidade: "beginner", "intermediate", "advanced" | ✅ Sim |

### Campos Calculados (Não Relevantes para Preferências)

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `totalPlanTime` | int | Tempo total do plano em minutos (calculado) |
| `timeFits` | boolean | Se o plano cabe no tempo disponível (com margem de 50%) |
| `totalKcal` | int | Calorias totais do plano |
| `avgKcalPerServing` | int | Média de calorias por porção |

## Mapeamento para o Card

### 1. Modo
- **Campo no plano:** `mode` (varchar)
- **Fallback:** `preferences.mode` → "normal"
- **Exibição:** Usar `MODE_LABELS[mode]`

### 2. Porções Planejadas
- **Campo no plano:** `requestedServings` (int)
- **Fallback:** `preferences.servings` → null
- **Exibição:** Número ou "Não definido"

### 3. Variedades de Pratos
- **Campo no plano:** `requestedVarieties` (int)
- **Fallback:** `preferences.varieties` → null
- **Exibição:** Número ou "Não definido"

### 4. Tempo Típico de Preparo
- **Campo no plano:** `availableTime` (int, em horas)
- **Fallback:** `preferences.time` (em minutos) → null
- **Observação:** Converter horas para minutos se necessário
- **Exibição:** "X minutos" ou "Não informado"

### 5. Novos Ingredientes
- **Campo no plano:** `allowNewIngredients` (boolean)
- **Fallback:** `preferences.allowNewIngredients` → true
- **Exibição:** 
  - `true`: "Permitidos além do estoque"
  - `false`: "Usar apenas o que já tem"

### 6. Perfil Nutricional
- **Campos no plano:** `dietType` (varchar) + `maxKcalPerServing` (int)
- **Fallback:** `preferences.dietType` + `preferences.maxKcalPerServing` → null
- **Exibição:**
  - Se ambos: "{dietType} · até {maxKcal} kcal/porção"
  - Se só dietType: "{dietType}"
  - Se só maxKcal: "Até {maxKcal} kcal/porção"
  - Se nenhum: "Sem restrições específicas"

## Prioridade de Fallback

```
1. Valor no plano (activePlan.campo)
2. Valor em preferences (preferences.campo)
3. Default sensato (null, "Não definido", "Sem restrições", etc.)
```

## Observações Importantes

### ⚠️ Inconsistência de Nomenclatura

- **No schema:** O campo é `mode` (varchar)
- **No PATCH 7.3.0:** Usamos `objective` no enum do router
- **Solução:** O PlanView já usa `activePlan.objective`, então precisamos verificar se o campo no banco é `mode` ou `objective`

### ⚠️ Unidade de Tempo

- **No plano:** `availableTime` é em **horas** (int)
- **Em preferences:** `time` é em **minutos** (int)
- **Solução:** Converter `availableTime` (horas) para minutos ao exibir: `availableTime * 60`

### ⚠️ Campo `objective` vs `mode`

Precisamos verificar qual campo está sendo usado no banco de dados real. O schema mostra `mode`, mas o código do PlanView usa `objective`.

**Ação:** Verificar no código do router qual campo está sendo salvo.
