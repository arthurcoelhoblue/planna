/**
 * PATCH 8.5.0 - Testes para getFriendlyErrorMessage
 * 
 * Valida que erros técnicos são transformados em mensagens amigáveis
 */

import { describe, it, expect } from "vitest";
import { getFriendlyErrorMessage } from "./errorMessages";

describe("getFriendlyErrorMessage", () => {
  describe("TOO_MANY_REQUESTS por contexto", () => {
    it("deve retornar mensagem específica para auth", () => {
      const error = {
        data: { code: "TOO_MANY_REQUESTS" },
      };

      const msg = getFriendlyErrorMessage(error, "auth");

      expect(msg).toContain("Muitas tentativas");
      expect(msg).toContain("Aguarde um minuto");
    });

    it("deve retornar mensagem específica para planner-generate", () => {
      const error = {
        data: { code: "TOO_MANY_REQUESTS" },
      };

      const msg = getFriendlyErrorMessage(error, "planner-generate");

      expect(msg).toContain("planos demais");
      expect(msg).toContain("Espere um pouco");
    });

    it("deve retornar mensagem específica para planner-anon", () => {
      const error = {
        data: { code: "TOO_MANY_REQUESTS" },
      };

      const msg = getFriendlyErrorMessage(error, "planner-anon");

      expect(msg).toContain("planos demais");
      expect(msg).toContain("Espere um pouco");
    });

    it("deve retornar mensagem específica para ingredients", () => {
      const error = {
        data: { code: "TOO_MANY_REQUESTS" },
      };

      const msg = getFriendlyErrorMessage(error, "ingredients");

      expect(msg).toContain("detectar ingredientes");
      expect(msg).toContain("alguns minutos");
    });
  });

  describe("NOT_FOUND para shared-plan", () => {
    it("deve retornar mensagem de plano removido", () => {
      const error = {
        data: { code: "NOT_FOUND" },
      };

      const msg = getFriendlyErrorMessage(error, "shared-plan");

      expect(msg).toContain("não está mais disponível");
      expect(msg).toContain("removido");
    });

    it("não deve retornar mensagem de plano removido em outro contexto", () => {
      const error = {
        data: { code: "NOT_FOUND" },
      };

      const msg = getFriendlyErrorMessage(error, "auth");

      expect(msg).not.toContain("removido");
      expect(msg).toContain("Não foi possível entrar");
    });
  });

  describe("Fallbacks genéricos", () => {
    it("deve retornar fallback de auth quando erro não tem code", () => {
      const error = new Error("Generic error");

      const msg = getFriendlyErrorMessage(error, "auth");

      expect(msg).toContain("Não foi possível entrar");
      expect(msg).toContain("Confira os dados");
    });

    it("deve retornar fallback genérico quando contexto é generic", () => {
      const error = new Error("Generic error");

      const msg = getFriendlyErrorMessage(error, "generic");

      expect(msg).toContain("Algo deu errado");
      expect(msg).toContain("Tente novamente");
    });
  });

  describe("Extração de código de erro", () => {
    it("deve extrair code de error.data.code", () => {
      const error = {
        data: { code: "TOO_MANY_REQUESTS" },
      };

      const msg = getFriendlyErrorMessage(error, "auth");

      expect(msg).toContain("Muitas tentativas");
    });

    it("deve extrair code de error.shape.code", () => {
      const error = {
        shape: { code: "TOO_MANY_REQUESTS" },
      };

      const msg = getFriendlyErrorMessage(error, "auth");

      expect(msg).toContain("Muitas tentativas");
    });

    it("deve extrair code de error.code", () => {
      const error = {
        code: "TOO_MANY_REQUESTS",
      };

      const msg = getFriendlyErrorMessage(error, "auth");

      expect(msg).toContain("Muitas tentativas");
    });
  });
});
