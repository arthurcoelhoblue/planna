/**
 * PATCH 8.1.0: Source tracking helper
 * Captures and stores acquisition source from URL parameters
 */

const SOURCE_KEY = "planna:lastSource";

/**
 * Read source parameter from current URL
 * @returns source value or null if not present
 */
export function readSourceFromUrl(): string | null {
  const params = new URLSearchParams(window.location.search);
  const src = params.get("src");
  return src;
}

/**
 * Store source in localStorage for later use
 * @param src - source identifier (e.g., "home", "share", "share_whatsapp")
 */
export function setLastSource(src: string) {
  try {
    localStorage.setItem(SOURCE_KEY, src);
  } catch (error) {
    console.warn("[Source] Failed to store source:", error);
  }
}

/**
 * Retrieve stored source from localStorage
 * @returns stored source or null if not found
 */
export function getLastSource(): string | null {
  try {
    return localStorage.getItem(SOURCE_KEY);
  } catch (error) {
    console.warn("[Source] Failed to read source:", error);
    return null;
  }
}

/**
 * Clear stored source from localStorage
 */
export function clearLastSource() {
  try {
    localStorage.removeItem(SOURCE_KEY);
  } catch (error) {
    console.warn("[Source] Failed to clear source:", error);
  }
}
