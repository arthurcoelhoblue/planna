import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";

interface DishDiffDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  oldDish: any | null;
  newDish: any | null;
}

export function DishDiffDialog({ open, onOpenChange, oldDish, newDish }: DishDiffDialogProps) {
  if (!oldDish || !newDish) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Comparação do prato antes e depois</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <h3 className="font-semibold mb-2">Antes</h3>
            <p className="font-medium">{oldDish.name}</p>
            {oldDish.totalTime && (
              <p className="text-muted-foreground">Tempo: {oldDish.totalTime}</p>
            )}
            {oldDish.servings && (
              <p className="text-muted-foreground">Porções: {oldDish.servings}</p>
            )}
            {Array.isArray(oldDish.ingredients) && (
              <div className="mt-2 space-y-1">
                <p className="font-medium">Ingredientes</p>
                <ul className="list-disc list-inside">
                  {oldDish.ingredients.map((ing: any, i: number) => (
                    <li key={i}>{typeof ing === "string" ? ing : ing.name}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div>
            <h3 className="font-semibold mb-2">Depois</h3>
            <p className="font-medium flex items-center gap-2">
              {newDish.name}
              {newDish.name !== oldDish.name && (
                <Badge variant="outline">Nome alterado</Badge>
              )}
            </p>
            {newDish.totalTime && (
              <p className="text-muted-foreground">Tempo: {newDish.totalTime}</p>
            )}
            {newDish.servings && (
              <p className="text-muted-foreground">Porções: {newDish.servings}</p>
            )}
            {Array.isArray(newDish.ingredients) && (
              <div className="mt-2 space-y-1">
                <p className="font-medium">Ingredientes</p>
                <ul className="list-disc list-inside">
                  {newDish.ingredients.map((ing: any, i: number) => (
                    <li key={i}>{typeof ing === "string" ? ing : ing.name}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
