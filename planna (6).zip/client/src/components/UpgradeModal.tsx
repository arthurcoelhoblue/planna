import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Check, Loader2, Sparkles, X, ExternalLink } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

// Price IDs do Stripe (modo teste)
const STRIPE_PRICE_IDS = {
  pro: "price_1SUPvOKHYuEw9LKlDGmXKmjD", // Planna Pro - R$ 9,90/mês
  premium: "price_1SVInaKHYuEw9LKlKEAg3pps", // Planna Premium - R$ 14,99/mês
};

interface UpgradeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reason?: "limit_plans" | "feature_locked_regen_dish" | "feature_locked_regen_list" | "feature_locked_pdf_export" | "feature_locked_export_csv" | "feature_locked_export_xlsx" | "feature_locked_export" | string;
  currentTier?: "free" | "pro" | "premium" | "vip";
}

export function UpgradeModal({ 
  open, 
  onOpenChange, 
  reason,
  currentTier = "free" 
}: UpgradeModalProps) {
  const [loadingPlan, setLoadingPlan] = useState<"pro" | "premium" | null>(null);
  const [, setLocation] = useLocation();

  const createCheckout = trpc.subscription.createCheckout.useMutation({
    onSuccess: (data) => {
      if (data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
      }
    },
    onError: (error) => {
      alert(error.message);
      setLoadingPlan(null);
    },
  });

  const handleUpgrade = (priceId: string, plan: "pro" | "premium") => {
    setLoadingPlan(plan);
    createCheckout.mutate({ priceId });
  };

  // Mensagens contextuais por reason
  const getContextMessage = () => {
    switch (reason) {
      case "limit_plans":
        return "Você já está usando o Planna de verdade, agora falta só liberar mais planos. Faça upgrade e continue planejando suas marmitas sem limites!";
      case "feature_locked_regen_dish":
        return "Você está esbarrando nas features avançadas que fazem você economizar tempo. Regenerar pratos é exclusivo dos planos Pro e Premium!";
      case "feature_locked_regen_list":
        return "Você está esbarrando nas features avançadas que fazem você economizar tempo. Regenerar lista de compras é exclusivo dos planos Pro e Premium!";
      case "feature_locked_pdf_export":
        return "Quer uma lista de compras bonita e profissional em PDF? Esse recurso premium é exclusivo dos planos Pro e Premium!";
      case "feature_locked_export_csv":
        return "Exportar a lista de compras em CSV é um recurso de planos pagos. Faça upgrade para liberar este recurso!";
      case "feature_locked_export_xlsx":
        return "Exportar em Excel é um recurso dos planos Pro e Premium. Faça upgrade para ter acesso a planilhas profissionais!";
      case "feature_locked_export":
        return "Exportar a lista de compras é um recurso de planos pagos. Faça upgrade para liberar este recurso!";
      default:
        return "Desbloqueie todos os recursos do Planna com um plano pago!";
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <Sparkles className="w-6 h-6 text-primary" />
            Desbloqueie Todo o Potencial do Planna
          </DialogTitle>
          <DialogDescription>
            {getContextMessage()}
          </DialogDescription>
        </DialogHeader>

        {/* Tabela Comparativa */}
        <div className="mt-6">
          <div className="grid grid-cols-4 gap-4 text-sm">
            {/* Header */}
            <div className="font-semibold text-muted-foreground">Recursos</div>
            <div className="text-center">
              <div className="font-bold text-lg">Gratuito</div>
              <div className="text-xs text-muted-foreground">Seu plano atual</div>
            </div>
            <div className="text-center relative">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-2 py-0.5 rounded-full text-xs font-semibold whitespace-nowrap">
                Mais Popular
              </div>
              <div className="font-bold text-lg">Pro</div>
              <div className="text-xs text-primary font-semibold">R$ 9,90/mês</div>
            </div>
            <div className="text-center">
              <div className="font-bold text-lg">Premium</div>
              <div className="text-xs text-primary font-semibold">R$ 14,99/mês</div>
            </div>

            {/* Planos por mês */}
            <div className="py-3 border-t">Planos por mês</div>
            <div className="py-3 border-t text-center">2</div>
            <div className="py-3 border-t text-center font-semibold">10</div>
            <div className="py-3 border-t text-center font-semibold text-primary">Ilimitados</div>

            {/* Porções máximas */}
            <div className="py-3 border-t">Porções por plano</div>
            <div className="py-3 border-t text-center">Até 10</div>
            <div className="py-3 border-t text-center font-semibold">Até 20</div>
            <div className="py-3 border-t text-center font-semibold">Até 20</div>

            {/* Variedades */}
            <div className="py-3 border-t">Variedades (misturas)</div>
            <div className="py-3 border-t text-center">Até 3</div>
            <div className="py-3 border-t text-center font-semibold">Até 6</div>
            <div className="py-3 border-t text-center font-semibold">Até 6</div>

            {/* Modos avançados */}
            <div className="py-3 border-t">Modos avançados</div>
            <div className="py-3 border-t text-center">
              <X className="w-5 h-5 text-muted-foreground mx-auto" />
            </div>
            <div className="py-3 border-t text-center">
              <Check className="w-5 h-5 text-primary mx-auto" />
            </div>
            <div className="py-3 border-t text-center">
              <Check className="w-5 h-5 text-primary mx-auto" />
            </div>

            {/* Regenerar pratos */}
            <div className="py-3 border-t">Regenerar pratos</div>
            <div className="py-3 border-t text-center">
              <X className="w-5 h-5 text-muted-foreground mx-auto" />
            </div>
            <div className="py-3 border-t text-center">
              <Check className="w-5 h-5 text-primary mx-auto" />
            </div>
            <div className="py-3 border-t text-center">
              <Check className="w-5 h-5 text-primary mx-auto" />
            </div>

            {/* Regenerar lista */}
            <div className="py-3 border-t">Regenerar lista de compras</div>
            <div className="py-3 border-t text-center">
              <X className="w-5 h-5 text-muted-foreground mx-auto" />
            </div>
            <div className="py-3 border-t text-center">
              <Check className="w-5 h-5 text-primary mx-auto" />
            </div>
            <div className="py-3 border-t text-center">
              <Check className="w-5 h-5 text-primary mx-auto" />
            </div>

            {/* PATCH 9.2.0: Exportar lista em PDF profissional */}
            <div className="py-3 border-t">Exportar lista em PDF profissional</div>
            <div className="py-3 border-t text-center">
              <X className="w-5 h-5 text-muted-foreground mx-auto" />
            </div>
            <div className="py-3 border-t text-center">
              <Check className="w-5 h-5 text-primary mx-auto" />
            </div>
            <div className="py-3 border-t text-center">
              <Check className="w-5 h-5 text-primary mx-auto" />
            </div>

            {/* Histórico e rollback */}
            <div className="py-3 border-t">Histórico e rollback</div>
            <div className="py-3 border-t text-center">
              <X className="w-5 h-5 text-muted-foreground mx-auto" />
            </div>
            <div className="py-3 border-t text-center">
              <Check className="w-5 h-5 text-primary mx-auto" />
            </div>
            <div className="py-3 border-t text-center">
              <Check className="w-5 h-5 text-primary mx-auto" />
            </div>

            {/* Detecção de ingredientes */}
            <div className="py-3 border-t">Detecção de ingredientes/mês</div>
            <div className="py-3 border-t text-center">3</div>
            <div className="py-3 border-t text-center font-semibold">30</div>
            <div className="py-3 border-t text-center font-semibold text-primary">Ilimitadas</div>

            {/* Botões */}
            <div className="py-4 border-t"></div>
            <div className="py-4 border-t text-center">
              <span className="text-xs text-muted-foreground">Plano atual</span>
            </div>
            <div className="py-4 border-t">
              <Button
                className="w-full"
                size="lg"
                onClick={() => handleUpgrade(STRIPE_PRICE_IDS.pro, "pro")}
                disabled={loadingPlan !== null}
              >
                {loadingPlan === "pro" ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processando...
                  </>
                ) : (
                  "Assinar Pro"
                )}
              </Button>
            </div>
            <div className="py-4 border-t">
              <Button
                className="w-full"
                size="lg"
                variant="outline"
                onClick={() => handleUpgrade(STRIPE_PRICE_IDS.premium, "premium")}
                disabled={loadingPlan !== null}
              >
                {loadingPlan === "premium" ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processando...
                  </>
                ) : (
                  "Assinar Premium"
                )}
              </Button>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-center gap-3 mt-4">
          <Button
            variant="ghost"
            onClick={() => {
              onOpenChange(false);
              setLocation(`/planos?from=upgrade_modal&reason=${reason || 'general'}`);
            }}
            className="text-sm"
          >
            Ver todos os planos
            <ExternalLink className="w-4 h-4 ml-2" />
          </Button>
          <div className="text-center text-sm text-muted-foreground">
            💳 Pagamento seguro via Stripe • Cancele quando quiser • Sem taxas ocultas
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
