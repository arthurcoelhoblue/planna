import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Check, X, Minus } from "lucide-react";

interface ShoppingListDiffDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  oldList: any[];
  newList: any[];
}

/**
 * PATCH 8.6.0: Modal de comparação antes/depois da lista de compras
 * Exibe itens removidos, adicionados e mantidos
 */
export function ShoppingListDiffDialog({
  open,
  onOpenChange,
  oldList,
  newList,
}: ShoppingListDiffDialogProps) {
  if (!oldList || !newList) {
    return null;
  }

  // Normalizar listas para comparação
  const normalizeItem = (item: any) => {
    return `${item.item}-${item.quantity}-${item.unit}`.toLowerCase();
  };

  // Criar sets para comparação
  const oldItems = new Set<string>();
  const oldItemsMap = new Map<string, any>();
  oldList.forEach((cat) => {
    cat.items?.forEach((item: any) => {
      const key = normalizeItem(item);
      oldItems.add(key);
      oldItemsMap.set(key, { ...item, category: cat.category });
    });
  });

  const newItems = new Set<string>();
  const newItemsMap = new Map<string, any>();
  newList.forEach((cat) => {
    cat.items?.forEach((item: any) => {
      const key = normalizeItem(item);
      newItems.add(key);
      newItemsMap.set(key, { ...item, category: cat.category });
    });
  });

  // Calcular diferenças
  const added: any[] = [];
  const removed: any[] = [];
  const kept: any[] = [];

  newItems.forEach((key) => {
    if (!oldItems.has(key)) {
      added.push(newItemsMap.get(key));
    } else {
      kept.push(newItemsMap.get(key));
    }
  });

  oldItems.forEach((key) => {
    if (!newItems.has(key)) {
      removed.push(oldItemsMap.get(key));
    }
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Lista de Compras Atualizada</DialogTitle>
          <DialogDescription>
            Veja o que mudou na sua lista de compras
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Itens adicionados */}
          {added.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Badge variant="default" className="bg-green-500">
                  <Check className="w-3 h-3 mr-1" />
                  {added.length} {added.length === 1 ? "item adicionado" : "itens adicionados"}
                </Badge>
              </div>
              <ul className="space-y-2">
                {added.map((item, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="font-medium">{item.item}</span>
                      <span className="text-muted-foreground ml-2">
                        {item.quantity} {item.unit}
                      </span>
                      <span className="text-xs text-muted-foreground ml-2">
                        ({item.category})
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Itens removidos */}
          {removed.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Badge variant="destructive">
                  <X className="w-3 h-3 mr-1" />
                  {removed.length} {removed.length === 1 ? "item removido" : "itens removidos"}
                </Badge>
              </div>
              <ul className="space-y-2">
                {removed.map((item, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <X className="w-4 h-4 text-destructive mt-0.5 flex-shrink-0" />
                    <div className="line-through text-muted-foreground">
                      <span>{item.item}</span>
                      <span className="ml-2">
                        {item.quantity} {item.unit}
                      </span>
                      <span className="text-xs ml-2">
                        ({item.category})
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Itens mantidos */}
          {kept.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Badge variant="secondary">
                  <Minus className="w-3 h-3 mr-1" />
                  {kept.length} {kept.length === 1 ? "item mantido" : "itens mantidos"}
                </Badge>
              </div>
              <ul className="space-y-2">
                {kept.slice(0, 5).map((item, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <Minus className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <div>
                      <span>{item.item}</span>
                      <span className="ml-2">
                        {item.quantity} {item.unit}
                      </span>
                    </div>
                  </li>
                ))}
                {kept.length > 5 && (
                  <li className="text-xs text-muted-foreground ml-6">
                    ... e mais {kept.length - 5} {kept.length - 5 === 1 ? "item" : "itens"}
                  </li>
                )}
              </ul>
            </div>
          )}

          {/* Resumo */}
          <div className="border-t pt-4 text-sm text-muted-foreground">
            <p>
              Total: {newItems.size} {newItems.size === 1 ? "item" : "itens"} na nova lista
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
