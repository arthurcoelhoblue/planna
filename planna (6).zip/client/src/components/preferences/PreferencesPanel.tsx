import { useState, useEffect, useMemo } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { MODE_LABELS, MODE_DESCRIPTIONS, PlannerMode } from "../../../../shared/modes";

const PLANNER_MODES: PlannerMode[] = ["normal", "aproveitamento", "lowcal", "highprotein"];
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { InfoTooltip } from "@/components/InfoTooltip";
import { ChipInput } from "@/components/ChipInput";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

/**
 * PATCH 7.6.0 - PreferencesPanel
 * Painel completo de preferências do usuário, fonte única de verdade para o Planner
 */
export function PreferencesPanel() {
  const { isAuthenticated } = useAuth();

  // Query e mutation
  const { data: preferences, isLoading, isError } = trpc.preferences.get.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const utils = trpc.useUtils();
  const updatePreferences = trpc.preferences.update.useMutation({
    onSuccess: async () => {
      // PATCH 7.7.0: Invalidate preferences.get para sincronizar Planner/PlanView
      await utils.preferences.get.invalidate();
      toast.success("Preferências salvas", {
        description: "Suas configurações serão usadas como padrão nos próximos planos.",
      });
    },
    onError: () => {
      toast.error("Erro ao salvar", {
        description: "Tente novamente em alguns instantes.",
      });
    },
  });

  // Estados principais
  const [mode, setMode] = useState<PlannerMode>("normal");
  const [servings, setServings] = useState<number>(10);
  const [varieties, setVarieties] = useState<number>(3);
  const [time, setTime] = useState<number | null>(null);
  const [allowNewIngredients, setAllowNewIngredients] = useState<boolean>(true);

  const [dietType, setDietType] = useState<string>("");
  const [maxKcalPerServing, setMaxKcalPerServing] = useState<number | null>(null);
  const [skillLevel, setSkillLevel] = useState<"beginner" | "intermediate" | "advanced">("intermediate");

  const [exclusions, setExclusions] = useState<string[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);

  const [initialized, setInitialized] = useState(false);

  // Hidratação inicial a partir de preferences
  useEffect(() => {
    if (!preferences || initialized) return;

    setMode((preferences.mode as PlannerMode) ?? "normal");

    if (typeof preferences.servings === "number") setServings(preferences.servings);
    if (typeof preferences.varieties === "number") setVarieties(preferences.varieties);
    if (typeof preferences.time === "number" || preferences.time === null) setTime(preferences.time);
    if (typeof preferences.allowNewIngredients === "boolean") setAllowNewIngredients(preferences.allowNewIngredients);

    if (preferences.dietType) setDietType(preferences.dietType);
    if (typeof preferences.maxKcalPerServing === "number") setMaxKcalPerServing(preferences.maxKcalPerServing);
    if (preferences.skillLevel) setSkillLevel(preferences.skillLevel as any);

    // Parse exclusions e favorites (podem vir como array ou JSON string)
    if (preferences.exclusions) {
      if (Array.isArray(preferences.exclusions)) {
        setExclusions(preferences.exclusions as string[]);
      } else {
        try {
          const parsed = JSON.parse(preferences.exclusions as any);
          setExclusions(Array.isArray(parsed) ? parsed : []);
        } catch {
          setExclusions([]);
        }
      }
    }

    if (preferences.favorites) {
      if (Array.isArray(preferences.favorites)) {
        setFavorites(preferences.favorites as string[]);
      } else {
        try {
          const parsed = JSON.parse(preferences.favorites as any);
          setFavorites(Array.isArray(parsed) ? parsed : []);
        } catch {
          setFavorites([]);
        }
      }
    }

    setInitialized(true);
  }, [preferences, initialized]);

  // Detectar se o formulário está "sujo"
  const isDirty = useMemo(() => {
    if (!preferences) return false;
    
    // Parse preferences.exclusions e preferences.favorites para comparação
    const prefsExclusions = (() => {
      if (!preferences.exclusions) return [];
      if (Array.isArray(preferences.exclusions)) return preferences.exclusions as string[];
      try {
        const parsed = JSON.parse(preferences.exclusions as any);
        return Array.isArray(parsed) ? parsed : [];
      } catch {
        return [];
      }
    })();

    const prefsFavorites = (() => {
      if (!preferences.favorites) return [];
      if (Array.isArray(preferences.favorites)) return preferences.favorites as string[];
      try {
        const parsed = JSON.parse(preferences.favorites as any);
        return Array.isArray(parsed) ? parsed : [];
      } catch {
        return [];
      }
    })();

    return (
      mode !== (preferences.mode as PlannerMode) ||
      servings !== preferences.servings ||
      varieties !== preferences.varieties ||
      (time ?? null) !== (preferences.time ?? null) ||
      allowNewIngredients !== preferences.allowNewIngredients ||
      (dietType || "") !== (preferences.dietType || "") ||
      (maxKcalPerServing ?? null) !== (preferences.maxKcalPerServing ?? null) ||
      skillLevel !== (preferences.skillLevel as any) ||
      JSON.stringify(exclusions) !== JSON.stringify(prefsExclusions) ||
      JSON.stringify(favorites) !== JSON.stringify(prefsFavorites)
    );
  }, [preferences, mode, servings, varieties, time, allowNewIngredients, dietType, maxKcalPerServing, skillLevel, exclusions, favorites]);

  // PATCH 7.7.0: Helpers removidos, agora usa ChipInput compartilhado

  // Handler de salvar
  const handleSave = () => {
    updatePreferences.mutate({
      mode,
      servings,
      varieties,
      time, // pode ser null
      allowNewIngredients,
      dietType: dietType || undefined,
      maxKcalPerServing: maxKcalPerServing ?? undefined,
      skillLevel,
      exclusions,
      favorites,
      _source: "dashboard", // PATCH 7.8.0: Analytics tracking
    });
  };

  // Estados de loading/erro
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
        <p className="ml-3 text-muted-foreground">Carregando suas preferências...</p>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="text-center py-12">
        <p className="text-destructive">Não foi possível carregar suas preferências agora.</p>
        <p className="text-sm text-muted-foreground mt-2">Tente recarregar a página.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Bloco 1 - Modo & parâmetros gerais */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Modo e parâmetros do Planner</h2>
          <InfoTooltip
            content="Essas preferências serão usadas como padrão sempre que você abrir o Planner."
            examples={[
              "Modo: foco do planejamento (normal, aproveitamento, low cal, high protein)",
              "Porções e variedades: quantas marmitas e quantos pratos diferentes",
            ]}
          />
        </div>

        {/* Modos */}
        <div className="grid grid-cols-2 gap-3">
          {PLANNER_MODES.map((m: PlannerMode) => (
            <button
              key={m}
              type="button"
              onClick={() => setMode(m)}
              className={`p-3 border-2 rounded-lg text-left text-sm transition-all ${
                mode === m ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
              }`}
            >
              <div className="font-semibold">{MODE_LABELS[m]}</div>
              <div className="text-xs text-muted-foreground">
                {MODE_DESCRIPTIONS[m]}
              </div>
            </button>
          ))}
        </div>

        {/* Porções e variedades */}
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <label className="text-sm font-medium flex items-center justify-between">
              Porções padrão
              <span className="text-xs text-muted-foreground">{servings} porções</span>
            </label>
            <Slider
              min={4}
              max={30}
              step={1}
              value={[servings]}
              onValueChange={([value]) => setServings(value)}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium flex items-center justify-between">
              Variedades de pratos
              <span className="text-xs text-muted-foreground">{varieties} pratos diferentes</span>
            </label>
            <Slider
              min={1}
              max={7}
              step={1}
              value={[varieties]}
              onValueChange={([value]) => setVarieties(value)}
            />
          </div>
        </div>

        {/* Tempo e novos ingredientes */}
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <label className="text-sm font-medium">Tempo médio disponível (minutos)</label>
            <Input
              type="number"
              min={0}
              value={time ?? ""}
              onChange={(e) => {
                const v = e.target.value;
                setTime(v === "" ? null : Math.max(0, Number(v)));
              }}
              placeholder="Ex: 90"
            />
            <p className="text-xs text-muted-foreground">
              Esse valor é usado como referência para sugerir planos compatíveis com sua rotina.
            </p>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium flex items-center gap-2">
              <span>Permitir novos ingredientes</span>
            </label>
            <div className="flex items-center justify-between rounded-md border px-3 py-2">
              <div className="space-y-1">
                <p className="text-sm">
                  {allowNewIngredients ? "Pode sugerir ingredientes novos" : "Usar apenas o que já tem"}
                </p>
                <p className="text-xs text-muted-foreground">
                  Se desligar, o Planner tenta ficar restrito ao que você informar no estoque/lista.
                </p>
              </div>
              <Switch
                checked={allowNewIngredients}
                onCheckedChange={setAllowNewIngredients}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Bloco 2 - Dieta & perfil nutricional */}
      <section className="space-y-4 pt-6 border-t">
        <h2 className="text-lg font-semibold">Dieta e perfil nutricional</h2>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <label className="text-sm font-medium">Tipo de dieta</label>
            <Input
              value={dietType}
              onChange={(e) => setDietType(e.target.value)}
              placeholder="Ex: Mediterrânea, Low carb, Vegetariana..."
            />
            <p className="text-xs text-muted-foreground">
              Campo livre para descrever o estilo de alimentação que você busca.
            </p>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Limite de kcal por porção</label>
            <Input
              type="number"
              min={0}
              value={maxKcalPerServing ?? ""}
              onChange={(e) => {
                const v = e.target.value;
                setMaxKcalPerServing(v === "" ? null : Math.max(0, Number(v)));
              }}
              placeholder="Ex: 450"
            />
            <p className="text-xs text-muted-foreground">
              Opcional. Se preencher, o Planner tenta respeitar esse limite por porção.
            </p>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Seu nível na cozinha</label>
          <div className="flex flex-wrap gap-2">
            {[
              { value: "beginner", label: "Iniciante", desc: "Receitas mais simples, passo a passo detalhado." },
              { value: "intermediate", label: "Intermediário", desc: "Equilíbrio entre praticidade e complexidade." },
              { value: "advanced", label: "Avançado", desc: "Pode usar técnicas mais elaboradas." },
            ].map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setSkillLevel(opt.value as any)}
                className={`px-3 py-2 rounded-md border text-left text-sm flex-1 min-w-[150px] ${
                  skillLevel === opt.value
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-primary/50"
                }`}
              >
                <div className="font-medium">{opt.label}</div>
                <div className="text-xs text-muted-foreground">{opt.desc}</div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* PATCH 7.7.0: Bloco 3 - Ingredientes evitados & favoritos (usando ChipInput) */}
      <section className="space-y-4 pt-6 border-t">
        <h2 className="text-lg font-semibold">Ingredientes evitados e favoritos</h2>

        <ChipInput
          label="Ingredientes que você quer evitar"
          description="Ex: lactose, glúten, pimentão... O Planner vai tentar não usar esses ingredientes."
          items={exclusions}
          onChange={setExclusions}
          variant="red"
          emptyHint="Nenhum ingrediente evitado cadastrado."
        />

        <ChipInput
          label="Ingredientes favoritos"
          description="Ex: frango, brócolis, batata-doce... O Planner tenta priorizar esses itens quando fizer sentido."
          items={favorites}
          onChange={setFavorites}
          variant="green"
          emptyHint="Nenhum favorito cadastrado ainda."
        />
      </section>

      {/* Ação de salvar */}
      <div className="mt-6 flex items-center justify-between border-t pt-4">
        <p className="text-xs text-muted-foreground">
          Essas preferências são usadas como padrão no Planner e nos planos gerados.
        </p>
        <Button
          type="button"
          disabled={!isDirty || updatePreferences.isPending}
          onClick={handleSave}
        >
          {updatePreferences.isPending ? "Salvando..." : "Salvar alterações"}
        </Button>
      </div>
    </div>
  );
}
