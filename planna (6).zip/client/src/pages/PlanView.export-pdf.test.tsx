import { describe, it, expect, vi } from "vitest";

// Mock do trpc
const mockTrpc = {
  auth: {
    me: {
      useQuery: vi.fn(),
    },
  },
  mealPlan: {
    getById: {
      useQuery: vi.fn(),
    },
  },
  shoppingList: {
    exportPremiumPdf: {
      useMutation: vi.fn(),
    },
  },
  subscription: {
    current: {
      useQuery: vi.fn(),
    },
  },
};

vi.mock("@/lib/trpc", () => ({
  trpc: mockTrpc,
}));

vi.mock("wouter", () => ({
  useParams: () => ({ planId: "123" }),
  useLocation: () => ["/plan/123", vi.fn()],
  Link: ({ children, href }: any) => <a href={href}>{children}</a>,
}));

vi.mock("@/_core/hooks/useAuth", () => ({
  useAuth: vi.fn(),
}));

describe("PlanView - Exportar PDF Premium (Unit Tests)", () => {

  it("deve permitir exportação para tier Pro", () => {
    const tier = "pro";
    const canUsePremiumPdf = ["pro", "premium", "vip"].includes(tier);
    expect(canUsePremiumPdf).toBe(true);
  });

  it("deve permitir exportação para tier Premium", () => {
    const tier = "premium";
    const canUsePremiumPdf = ["pro", "premium", "vip"].includes(tier);
    expect(canUsePremiumPdf).toBe(true);
  });

  it("deve permitir exportação para tier VIP", () => {
    const tier = "vip";
    const canUsePremiumPdf = ["pro", "premium", "vip"].includes(tier);
    expect(canUsePremiumPdf).toBe(true);
  });

  it("deve bloquear exportação para tier Free", () => {
    const tier = "free";
    const canUsePremiumPdf = ["pro", "premium", "vip"].includes(tier);
    expect(canUsePremiumPdf).toBe(false);
  });

  it("deve bloquear exportação para usuário anônimo (sem tier)", () => {
    const tier = undefined;
    const canUsePremiumPdf = ["pro", "premium", "vip"].includes(tier ?? "free");
    expect(canUsePremiumPdf).toBe(false);
  });

  it("deve converter base64 para Blob corretamente", () => {
    const base64 = Buffer.from("fake-pdf-content").toString("base64");
    const byteCharacters = atob(base64);
    const byteNumbers = Array.from(byteCharacters, (c) => c.charCodeAt(0));
    const byteArray = new Uint8Array(byteNumbers);
    
    expect(byteArray.length).toBeGreaterThan(0);
    expect(byteArray).toBeInstanceOf(Uint8Array);
  });

  it("deve validar formato do filename retornado", () => {
    const planId = 123;
    const filename = `lista-compras-planna-${planId}.pdf`;
    
    expect(filename).toContain("lista-compras-planna");
    expect(filename).toContain(".pdf");
    expect(filename).toContain(String(planId));
  });
});
