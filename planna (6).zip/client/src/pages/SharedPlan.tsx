import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { APP_LOGO, APP_TITLE } from "@/const";
import { trpc } from "@/lib/trpc";
import { getFriendlyErrorMessage } from "@/lib/errorMessages"; // PATCH 8.5.0
import { ChefHat, Clock, Printer, ShoppingCart, Sparkles, Users } from "lucide-react";
import { useLocation } from "wouter";

export default function SharedPlan() {
  const [location] = useLocation();
  const token = location.split("/shared/")[1];

  const { data, isLoading, error } = trpc.share.getSharedPlan.useQuery(
    { token },
    { enabled: !!token, retry: false } // PATCH 8.5.0: Não retentar em caso de erro
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-green-50 to-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando plano compartilhado...</p>
        </div>
      </div>
    );
  }

  // PATCH 8.5.0: Mensagem amigável para erro
  if (error) {
    const msg = getFriendlyErrorMessage(error, "shared-plan");
    return (
      <div className="min-h-screen bg-gradient-to-b from-green-50 to-white flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Ops...</CardTitle>
            <CardDescription className="text-base">
              {msg}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Que tal criar seu próprio plano personalizado? É grátis e leva menos de 2 minutos!
            </p>
            <Button onClick={() => (window.location.href = "/planner?src=share")} className="w-full">
              Gerar Meu Plano Grátis
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!data) {
    return null;
  }

  // PATCH 8.4.0: Dados sanitizados (sem plan/session wrapper)
  const dishes = JSON.parse(data.dishes);
  const shoppingList = JSON.parse(data.shoppingList);

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src={APP_LOGO} alt="Logo" className="h-8" />
            <span className="font-bold text-lg">{APP_TITLE}</span>
          </div>
          <Button onClick={() => (window.location.href = "/")} variant="default">
            Criar Meu Plano
          </Button>
        </div>
      </header>

      {/* Hero */}
      <section className="py-12 bg-gradient-to-r from-green-600 to-green-700 text-white">
        <div className="container text-center">
          <div className="inline-flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full mb-4">
            <Sparkles className="h-4 w-4" />
            <span className="text-sm font-medium">Plano Compartilhado</span>
          </div>
          <h1 className="text-4xl font-bold mb-4">Plano de Marmitas</h1>
          <p className="text-xl text-green-50 max-w-2xl mx-auto">
            {data.requestedServings || dishes.length} marmitas • {dishes.length} receitas
            {data.mode && ` • Modo ${data.mode === "aproveitamento" ? "Aproveitamento Total" : "Normal"}`}
          </p>
        </div>
      </section>

      <div className="container py-8 space-y-8">
        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Marmitas</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{data.requestedServings || dishes.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Receitas</CardTitle>
              <ChefHat className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{dishes.length}</div>
            </CardContent>
          </Card>

          {data.totalKcal && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Calorias Totais</CardTitle>
                <Sparkles className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{data.totalKcal}</div>
                <p className="text-xs text-muted-foreground">
                  ~{data.avgKcalPerServing} kcal/porção
                </p>
              </CardContent>
            </Card>
          )}

          {data.totalPlanTime && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Tempo Estimado</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{Math.round(data.totalPlanTime / 60)}h{data.totalPlanTime % 60 > 0 ? `${data.totalPlanTime % 60}min` : ''}</div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Recipes */}
        <div>
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <ChefHat className="h-6 w-6" />
            Receitas
          </h2>
          <div className="grid gap-6 md:grid-cols-2">
            {dishes.map((dish: any, idx: number) => (
              <Card key={idx}>
                <CardHeader>
                  <CardTitle>{dish.name}</CardTitle>
                  <CardDescription>
                    {dish.servings} porções • {dish.prepTime} min
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">Ingredientes:</h4>
                    <ul className="list-disc list-inside text-sm space-y-1">
                      {dish.ingredients?.map((ing: any, i: number) => (
                        <li key={i}>{ing.item}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Modo de Preparo:</h4>
                    <ol className="list-decimal list-inside text-sm space-y-1">
                      {dish.steps?.map((step: string, i: number) => (
                        <li key={i}>{step}</li>
                      ))}
                    </ol>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Shopping List */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <ShoppingCart className="h-6 w-6" />
              Lista de Compras
            </h2>
            {/* PATCH 9.0.0: Botão de imprimir */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.print()}
              className="gap-2"
            >
              <Printer className="w-4 h-4" />
              Imprimir lista
            </Button>
          </div>
          {/* PATCH 9.0.0: Wrapper para impressão */}
          <div id="shopping-list-print-root">
            <h2 className="text-xl font-semibold mb-4">🛒 Lista de compras do plano de marmitas
            </h2>
            <div className="grid gap-4 md:grid-cols-2">
            {shoppingList.map((category: any, idx: number) => (
              <Card key={idx}>
                <CardHeader>
                  <CardTitle className="text-lg">{category.category}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {category.items?.map((item: any, i: number) => (
                      <li key={i} className="flex items-center gap-2">
                        <input type="checkbox" className="rounded" />
                        <span className="text-sm">{item.item}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
            </div>
          </div>
        </div>

        {/* PATCH 8.1.0: CTA de conversão reforçado */}
        <section className="mt-8 border-t pt-6">
          <div className="rounded-lg border p-4 bg-muted/40 text-center space-y-3">
            <h2 className="text-lg font-semibold">
              Quer um plano assim com o que você tem na sua geladeira?
            </h2>
            <p className="text-sm text-muted-foreground">
              Diga o que você tem em casa e gere seu primeiro plano completo grátis.
            </p>
            <Button
              onClick={() => (window.location.href = "/planner?src=share")}
              size="lg"
            >
              Gerar meu primeiro plano grátis
            </Button>
          </div>
        </section>
      </div>
    </div>
  );
}

