/**
 * PATCH 8.9.0 - Testes da Página de Planos & Preços
 * 
 * Testes básicos de integração sem dependências de testing-library.
 * Validam a lógica de negócio e estrutura de dados.
 */

import { describe, it, expect } from "vitest";
import { TIER_LIMITS, TIER_LABELS } from "@shared/tier-limits";

describe("Pricing Page - Data Validation", () => {
  it("deve ter limites corretos para os 3 tiers (Free, Pro, Premium)", () => {
    // Free
    expect(TIER_LIMITS.free.maxPlansPerMonth).toBe(2);
    expect(TIER_LIMITS.free.maxServings).toBe(10);
    expect(TIER_LIMITS.free.maxVarieties).toBe(3);
    expect(TIER_LIMITS.free.allowAdvancedModes).toBe(false);
    expect(TIER_LIMITS.free.allowRegenerateDish).toBe(false);
    expect(TIER_LIMITS.free.allowRegenerateList).toBe(false);
    expect(TIER_LIMITS.free.maxIngredientDetectionsPerMonth).toBe(3);
    expect(TIER_LIMITS.free.allowVersionHistory).toBe(false);

    // Pro
    expect(TIER_LIMITS.pro.maxPlansPerMonth).toBe(10);
    expect(TIER_LIMITS.pro.maxServings).toBe(20);
    expect(TIER_LIMITS.pro.maxVarieties).toBe(6);
    expect(TIER_LIMITS.pro.allowAdvancedModes).toBe(true);
    expect(TIER_LIMITS.pro.allowRegenerateDish).toBe(true);
    expect(TIER_LIMITS.pro.allowRegenerateList).toBe(true);
    expect(TIER_LIMITS.pro.maxIngredientDetectionsPerMonth).toBe(30);
    expect(TIER_LIMITS.pro.allowVersionHistory).toBe(true);

    // Premium
    expect(TIER_LIMITS.premium.maxPlansPerMonth).toBe(Infinity);
    expect(TIER_LIMITS.premium.maxServings).toBe(20);
    expect(TIER_LIMITS.premium.maxVarieties).toBe(6);
    expect(TIER_LIMITS.premium.allowAdvancedModes).toBe(true);
    expect(TIER_LIMITS.premium.allowRegenerateDish).toBe(true);
    expect(TIER_LIMITS.premium.allowRegenerateList).toBe(true);
    expect(TIER_LIMITS.premium.maxIngredientDetectionsPerMonth).toBe(Infinity);
    expect(TIER_LIMITS.premium.allowVersionHistory).toBe(true);
  });

  it("deve ter labels corretos para exibição", () => {
    expect(TIER_LABELS.free).toBe("Gratuito");
    expect(TIER_LABELS.pro).toBe("Pro");
    expect(TIER_LABELS.premium).toBe("Premium");
  });

  it("deve ter price IDs corretos do Stripe", () => {
    const STRIPE_PRICE_IDS = {
      pro: "price_1SUPvOKHYuEw9LKlDGmXKmjD",
      premium: "price_1SVInaKHYuEw9LKlKEAg3pps",
    };

    expect(STRIPE_PRICE_IDS.pro).toBe("price_1SUPvOKHYuEw9LKlDGmXKmjD");
    expect(STRIPE_PRICE_IDS.premium).toBe("price_1SVInaKHYuEw9LKlKEAg3pps");
  });

  it("deve ter diferenças claras entre Free e Pro", () => {
    expect(TIER_LIMITS.pro.maxPlansPerMonth).toBeGreaterThan(TIER_LIMITS.free.maxPlansPerMonth);
    expect(TIER_LIMITS.pro.maxServings).toBeGreaterThan(TIER_LIMITS.free.maxServings);
    expect(TIER_LIMITS.pro.maxVarieties).toBeGreaterThan(TIER_LIMITS.free.maxVarieties);
    expect(TIER_LIMITS.pro.allowAdvancedModes).toBe(true);
    expect(TIER_LIMITS.free.allowAdvancedModes).toBe(false);
  });

  it("deve ter Premium com planos ilimitados", () => {
    expect(TIER_LIMITS.premium.maxPlansPerMonth).toBe(Infinity);
    expect(TIER_LIMITS.premium.maxIngredientDetectionsPerMonth).toBe(Infinity);
  });

  it("deve ter Pro e Premium com mesmos limites de porções e variedades", () => {
    expect(TIER_LIMITS.pro.maxServings).toBe(TIER_LIMITS.premium.maxServings);
    expect(TIER_LIMITS.pro.maxVarieties).toBe(TIER_LIMITS.premium.maxVarieties);
  });

  it("deve ter todos os tiers com features booleanas consistentes", () => {
    // Pro e Premium devem ter todas as features avançadas
    const advancedFeatures = [
      "allowAdvancedModes",
      "allowRegenerateDish",
      "allowRegenerateList",
      "allowVersionHistory",
    ] as const;

    advancedFeatures.forEach((feature) => {
      expect(TIER_LIMITS.pro[feature]).toBe(true);
      expect(TIER_LIMITS.premium[feature]).toBe(true);
      expect(TIER_LIMITS.free[feature]).toBe(false);
    });
  });
});

describe("Pricing Page - Microcopy Validation", () => {
  it("deve ter microcopy orientado a uso real", () => {
    const MICROCOPY = {
      free: "Pra testar o Planna e usar em semanas pontuais.",
      pro: "Pra quem cozinha toda semana pra si ou pro casal.",
      premium: "Pra famílias, atletas ou quem vive de marmita todo dia.",
    };

    expect(MICROCOPY.free).toContain("testar");
    expect(MICROCOPY.pro).toContain("toda semana");
    expect(MICROCOPY.premium).toContain("famílias");
  });

  it("deve ter preços em formato brasileiro", () => {
    const PRICING = {
      free: { price: "R$ 0", period: "sempre" },
      pro: { price: "R$ 9,90", period: "/mês" },
      premium: { price: "R$ 14,99", period: "/mês" },
    };

    expect(PRICING.free.price).toBe("R$ 0");
    expect(PRICING.pro.price).toBe("R$ 9,90");
    expect(PRICING.premium.price).toBe("R$ 14,99");
  });
});
