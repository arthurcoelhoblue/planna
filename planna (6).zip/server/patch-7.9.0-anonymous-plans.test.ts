/**
 * PATCH 7.9.0 - Testes para planos anônimos (1 plano grátis sem login)
 * 
 * Testa:
 * - Tabela anonymous_plans criada corretamente
 * - Lógica de limite (1 plano por anonymousId)
 * - Validação de anonymousId
 */

import { describe, it, expect, beforeAll } from "vitest";
import { getDb } from "./db";
import { anonymousPlans } from "../drizzle/schema";
import { eq, count } from "drizzle-orm";

describe("PATCH 7.9.0 - Planos Anônimos", () => {
  beforeAll(async () => {
    // Limpar tabela de planos anônimos antes dos testes
    const db = await getDb();
    if (db) {
      await db.delete(anonymousPlans);
    }
  });

  describe("Tabela anonymous_plans", () => {
    it("deve existir tabela anonymous_plans", async () => {
      const db = await getDb();
      expect(db).toBeDefined();
    });

    it("deve permitir inserir registro em anonymous_plans", async () => {
      const db = await getDb();
      if (!db) return;

      const testAnonymousId = `test-insert-${Date.now()}`;
      
      await db.insert(anonymousPlans).values({
        anonymousId: testAnonymousId,
        planId: 1, // ID fictício
      });

      const [row] = await db
        .select({ total: count() })
        .from(anonymousPlans)
        .where(eq(anonymousPlans.anonymousId, testAnonymousId))
        .limit(1);

      expect(row?.total ?? 0).toBe(1);
    });
  });

  describe("Lógica de Limite", () => {
    const testAnonymousId = `test-limit-${Date.now()}`;

    it("deve retornar 0 planos para novo anonymousId", async () => {
      const db = await getDb();
      if (!db) return;

      const [row] = await db
        .select({ total: count() })
        .from(anonymousPlans)
        .where(eq(anonymousPlans.anonymousId, testAnonymousId))
        .limit(1);

      expect(row?.total ?? 0).toBe(0);
    });

    it("deve permitir criar 1º plano anônimo", async () => {
      const db = await getDb();
      if (!db) return;

      // Inserir 1º plano
      await db.insert(anonymousPlans).values({
        anonymousId: testAnonymousId,
        planId: 100, // ID fictício
      });

      // Verificar contagem
      const [row] = await db
        .select({ total: count() })
        .from(anonymousPlans)
        .where(eq(anonymousPlans.anonymousId, testAnonymousId))
        .limit(1);

      expect(row?.total ?? 0).toBe(1);
    });

    it("deve detectar limite atingido (>= 1 plano)", async () => {
      const db = await getDb();
      if (!db) return;

      // Verificar que já existe 1 plano
      const [row] = await db
        .select({ total: count() })
        .from(anonymousPlans)
        .where(eq(anonymousPlans.anonymousId, testAnonymousId))
        .limit(1);

      const total = row?.total ?? 0;
      
      // Simular lógica do endpoint: bloquear se >= 1
      const shouldBlock = total >= 1;
      expect(shouldBlock).toBe(true);
    });
  });

  describe("Validação de anonymousId", () => {
    it("deve aceitar UUID válido", () => {
      const validUUID = "550e8400-e29b-41d4-a716-446655440000";
      expect(validUUID).toMatch(
        /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
      );
    });

    it("deve aceitar string não-vazia", () => {
      const anonymousId = "test-anon-123";
      expect(anonymousId.length).toBeGreaterThan(0);
    });

    it("deve gerar UUID único para cada visitante", () => {
      const uuid1 = crypto.randomUUID();
      const uuid2 = crypto.randomUUID();
      
      expect(uuid1).not.toBe(uuid2);
      expect(uuid1).toMatch(/^[0-9a-f-]{36}$/i);
      expect(uuid2).toMatch(/^[0-9a-f-]{36}$/i);
    });
  });

  describe("Múltiplos anonymousIds", () => {
    it("deve permitir 1 plano para cada anonymousId diferente", async () => {
      const db = await getDb();
      if (!db) return;

      const anon1 = `test-multi-1-${Date.now()}`;
      const anon2 = `test-multi-2-${Date.now()}`;

      // Inserir plano para anon1
      await db.insert(anonymousPlans).values({
        anonymousId: anon1,
        planId: 200,
      });

      // Inserir plano para anon2
      await db.insert(anonymousPlans).values({
        anonymousId: anon2,
        planId: 201,
      });

      // Verificar contagem para anon1
      const [row1] = await db
        .select({ total: count() })
        .from(anonymousPlans)
        .where(eq(anonymousPlans.anonymousId, anon1))
        .limit(1);

      // Verificar contagem para anon2
      const [row2] = await db
        .select({ total: count() })
        .from(anonymousPlans)
        .where(eq(anonymousPlans.anonymousId, anon2))
        .limit(1);

      expect(row1?.total ?? 0).toBe(1);
      expect(row2?.total ?? 0).toBe(1);
    });
  });

  describe("Persistência de anonymousId", () => {
    it("deve simular localStorage persistente", () => {
      // Simular comportamento do helper getAnonymousId
      const ANON_KEY = "planna_anonymous_id";
      const mockStorage: Record<string, string> = {};

      // 1ª chamada: gera novo ID
      let id = mockStorage[ANON_KEY];
      if (!id) {
        id = crypto.randomUUID();
        mockStorage[ANON_KEY] = id;
      }

      const firstId = id;

      // 2ª chamada: reutiliza ID existente
      id = mockStorage[ANON_KEY];
      const secondId = id;

      expect(firstId).toBe(secondId);
    });
  });
});
