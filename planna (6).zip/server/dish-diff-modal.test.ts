import { describe, it, expect } from "vitest";

/**
 * PATCH 6.3.0 - Testes do Modal de Comparação de Pratos
 * 
 * Valida que o modal de diff:
 * 1. Exibe corretamente informações de pratos antigos e novos
 * 2. Detecta mudanças de nome
 * 3. Lista ingredientes corretamente
 * 4. Suporta diferentes formatos de ingredientes (string ou objeto)
 */

describe("Modal de Comparação de Pratos (DishDiffDialog)", () => {
  it("deve validar estrutura básica de diff", () => {
    const oldDish = {
      name: "Frango Grelhado",
      totalTime: "30 minutos",
      servings: 4,
      ingredients: [
        { name: "Frango", quantity: 500, unit: "g" },
        { name: "Sal", quantity: 5, unit: "g" },
      ],
    };

    const newDish = {
      name: "Frango Grelhado Temperado",
      totalTime: "35 minutos",
      servings: 4,
      ingredients: [
        { name: "Frango", quantity: 500, unit: "g" },
        { name: "Sal", quantity: 5, unit: "g" },
        { name: "Alho", quantity: 10, unit: "g" },
      ],
    };

    // Validar que pratos têm estrutura correta
    expect(oldDish.name).toBe("Frango Grelhado");
    expect(newDish.name).toBe("Frango Grelhado Temperado");
    expect(newDish.name).not.toBe(oldDish.name); // Nome mudou
    expect(Array.isArray(oldDish.ingredients)).toBe(true);
    expect(Array.isArray(newDish.ingredients)).toBe(true);
    expect(newDish.ingredients.length).toBeGreaterThan(oldDish.ingredients.length); // Ingrediente adicionado
  });

  it("deve detectar mudança de nome do prato", () => {
    const oldDish = { name: "Arroz Simples" };
    const newDish = { name: "Arroz Integral com Legumes" };

    const nameChanged = newDish.name !== oldDish.name;
    expect(nameChanged).toBe(true);
  });

  it("deve detectar quando nome não mudou", () => {
    const oldDish = { name: "Feijão Preto" };
    const newDish = { name: "Feijão Preto" };

    const nameChanged = newDish.name !== oldDish.name;
    expect(nameChanged).toBe(false);
  });

  it("deve suportar ingredientes como strings", () => {
    const dish = {
      name: "Salada",
      ingredients: ["Alface", "Tomate", "Cebola"],
    };

    expect(Array.isArray(dish.ingredients)).toBe(true);
    expect(dish.ingredients.length).toBe(3);
    expect(typeof dish.ingredients[0]).toBe("string");
  });

  it("deve suportar ingredientes como objetos", () => {
    const dish = {
      name: "Frango",
      ingredients: [
        { name: "Frango", quantity: 500, unit: "g" },
        { name: "Sal", quantity: 5, unit: "g" },
      ],
    };

    expect(Array.isArray(dish.ingredients)).toBe(true);
    expect(dish.ingredients.length).toBe(2);
    expect(typeof dish.ingredients[0]).toBe("object");
    expect(dish.ingredients[0].name).toBe("Frango");
  });

  it("deve validar campos opcionais (totalTime, servings)", () => {
    const dishWithAllFields = {
      name: "Prato Completo",
      totalTime: "45 minutos",
      servings: 6,
      ingredients: [],
    };

    const dishWithoutOptional = {
      name: "Prato Simples",
      ingredients: [],
    };

    expect(dishWithAllFields.totalTime).toBeDefined();
    expect(dishWithAllFields.servings).toBeDefined();
    expect(dishWithoutOptional.totalTime).toBeUndefined();
    expect(dishWithoutOptional.servings).toBeUndefined();
  });

  it("deve comparar listas de ingredientes", () => {
    const oldIngredients = ["Arroz", "Feijão"];
    const newIngredients = ["Arroz", "Feijão", "Carne"];

    const addedIngredients = newIngredients.filter(
      (ing) => !oldIngredients.includes(ing)
    );
    const removedIngredients = oldIngredients.filter(
      (ing) => !newIngredients.includes(ing)
    );

    expect(addedIngredients).toEqual(["Carne"]);
    expect(removedIngredients).toEqual([]);
  });

  it("deve validar estrutura de diff retornada pelo backend", () => {
    const diff = {
      oldDish: {
        name: "Prato Antigo",
        ingredients: ["A", "B"],
      },
      newDish: {
        name: "Prato Novo",
        ingredients: ["A", "B", "C"],
      },
    };

    expect(diff.oldDish).toBeDefined();
    expect(diff.newDish).toBeDefined();
    expect(diff.oldDish.name).toBe("Prato Antigo");
    expect(diff.newDish.name).toBe("Prato Novo");
  });
});

describe("Integração do Modal no PlanView", () => {
  it("deve validar estados necessários para o modal", () => {
    // Simular estados do PlanView
    const diffDialogOpen = false;
    const diffDishIndex = 0;
    const lastDiff = {
      oldDish: { name: "Prato A" },
      newDish: { name: "Prato B" },
    };

    expect(typeof diffDialogOpen).toBe("boolean");
    expect(typeof diffDishIndex).toBe("number");
    expect(lastDiff.oldDish).toBeDefined();
    expect(lastDiff.newDish).toBeDefined();
  });

  it("deve validar que dishIndex vem de regenerateDish.variables", () => {
    // Simular resposta do mutation
    const regenerateDishData = {
      ok: true,
      newPlan: { dishes: [] },
      diff: {
        oldDish: { name: "A" },
        newDish: { name: "B" },
      },
    };

    const regenerateDishVariables = {
      planId: 123,
      dishIndex: 2,
    };

    // dishIndex deve vir de variables, não de diff
    expect(regenerateDishData.diff.oldDish).toBeDefined();
    expect(regenerateDishData.diff.newDish).toBeDefined();
    expect(regenerateDishVariables.dishIndex).toBe(2);
  });

  it("deve validar lógica de abertura automática do modal", () => {
    // Simular condição de abertura
    const hasData = true;
    const hasDiff = true;
    const hasVariables = true;

    const shouldOpenModal = hasData && hasDiff && hasVariables;
    expect(shouldOpenModal).toBe(true);
  });

  it("deve validar que botão Ver mudanças aparece apenas no prato correto", () => {
    const currentDishIndex = 1;
    const diffDishIndex = 1;
    const lastDiff = { oldDish: {}, newDish: {} };

    const shouldShowButton = lastDiff && diffDishIndex === currentDishIndex;
    expect(shouldShowButton).toBe(true);
  });

  it("deve validar que botão Ver mudanças NÃO aparece em outros pratos", () => {
    const currentDishIndex = 0;
    const diffDishIndex = 1; // Diff é do prato 1, não do 0
    const lastDiff = { oldDish: {}, newDish: {} };

    const shouldShowButton = lastDiff && diffDishIndex === currentDishIndex;
    expect(shouldShowButton).toBe(false);
  });
});
