/**
 * PATCH 8.4.1: Testes de delete de plano (soft delete)
 * 
 * Cenários testados:
 * 1. Deletar plano do próprio usuário
 * 2. Não permitir deletar plano de outro usuário
 * 3. Plano deletado não aparece no histórico
 * 4. Plano deletado não pode ser aberto
 * 5. Deletar duas vezes dá NOT_FOUND
 * 6. Soft delete mantém linha no banco
 */

import { describe, it, expect, beforeAll } from "vitest";
import { getDb } from "./db";
import { users, sessions, plans } from "../drizzle/schema";
import { eq, isNull } from "drizzle-orm";

describe("PATCH 8.4.1 - Delete de plano (soft delete)", () => {
  let testUserId1: number;
  let testUserId2: number;
  let testSessionId1: number;
  let testSessionId2: number;
  let testPlanId1: number;
  let testPlanId2: number;

  beforeAll(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Criar usuário 1
    const [user1] = await db.insert(users).values({
      openId: `test_delete_${Date.now()}_user1`,
      name: "Test User 1",
      email: `test1_${Date.now()}@test.com`,
      loginMethod: "local",
    }).$returningId();
    testUserId1 = user1.id;

    // Criar usuário 2
    const [user2] = await db.insert(users).values({
      openId: `test_delete_${Date.now()}_user2`,
      name: "Test User 2",
      email: `test2_${Date.now()}@test.com`,
      loginMethod: "local",
    }).$returningId();
    testUserId2 = user2.id;

    // Criar sessão 1
    const [session1] = await db.insert(sessions).values({
      userId: testUserId1,
      inputText: "Test ingredients 1",
      servings: 10,
      objective: "normal",
    }).$returningId();
    testSessionId1 = session1.id;

    // Criar sessão 2
    const [session2] = await db.insert(sessions).values({
      userId: testUserId2,
      inputText: "Test ingredients 2",
      servings: 10,
      objective: "normal",
    }).$returningId();
    testSessionId2 = session2.id;

    // Criar plano 1 (usuário 1)
    const [plan1] = await db.insert(plans).values({
      sessionId: testSessionId1,
      dishes: JSON.stringify([{ name: "Test Dish 1" }]),
      shoppingList: JSON.stringify([]),
      prepSchedule: JSON.stringify([]),
    }).$returningId();
    testPlanId1 = plan1.id;

    // Criar plano 2 (usuário 1)
    const [plan2] = await db.insert(plans).values({
      sessionId: testSessionId1,
      dishes: JSON.stringify([{ name: "Test Dish 2" }]),
      shoppingList: JSON.stringify([]),
      prepSchedule: JSON.stringify([]),
    }).$returningId();
    testPlanId2 = plan2.id;
  });

  it("1. Deletar plano do próprio usuário", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Soft delete do plano 1
    const result = await db
      .update(plans)
      .set({ deletedAt: new Date() })
      .where(eq(plans.id, testPlanId1));

    expect(result).toBeDefined();

    // Verificar que deletedAt foi preenchido
    const [plan] = await db
      .select()
      .from(plans)
      .where(eq(plans.id, testPlanId1))
      .limit(1);

    expect(plan).toBeDefined();
    expect(plan.deletedAt).not.toBeNull();
  });

  it("2. Não permitir deletar plano de outro usuário", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Tentar buscar plano do usuário 1 como se fosse do usuário 2
    const [plan] = await db
      .select({ id: plans.id, sessionId: plans.sessionId })
      .from(plans)
      .where(eq(plans.id, testPlanId2))
      .limit(1);

    expect(plan).toBeDefined();

    // Verificar ownership
    const [session] = await db
      .select({ userId: sessions.userId })
      .from(sessions)
      .where(eq(sessions.id, plan.sessionId))
      .limit(1);

    expect(session).toBeDefined();
    expect(session.userId).not.toBe(testUserId2); // Não é do usuário 2
    expect(session.userId).toBe(testUserId1); // É do usuário 1
  });

  it("3. Plano deletado não aparece no histórico", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const { and } = await import("drizzle-orm");

    // Buscar planos não deletados do usuário 1
    const userPlans = await db
      .select()
      .from(plans)
      .innerJoin(sessions, eq(plans.sessionId, sessions.id))
      .where(
        and(
          eq(sessions.userId, testUserId1),
          isNull(plans.deletedAt)
        )
      );

    // Plano 1 foi deletado, então só deve aparecer plano 2
    expect(userPlans.length).toBe(1);
    expect(userPlans[0].plans.id).toBe(testPlanId2);
  });

  it("4. Plano deletado não pode ser aberto", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const { and } = await import("drizzle-orm");

    // Tentar buscar plano deletado
    const [plan] = await db
      .select()
      .from(plans)
      .where(
        and(
          eq(plans.id, testPlanId1),
          isNull(plans.deletedAt)
        )
      )
      .limit(1);

    expect(plan).toBeUndefined(); // Não deve retornar
  });

  it("5. Deletar duas vezes dá NOT_FOUND", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const { and } = await import("drizzle-orm");

    // Tentar deletar novamente o plano 1 (já deletado)
    const [plan] = await db
      .select()
      .from(plans)
      .where(
        and(
          eq(plans.id, testPlanId1),
          isNull(plans.deletedAt)
        )
      )
      .limit(1);

    expect(plan).toBeUndefined(); // Não encontrado (já deletado)
  });

  it("6. Soft delete mantém linha no banco", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Buscar plano deletado SEM filtro de deletedAt
    const [plan] = await db
      .select()
      .from(plans)
      .where(eq(plans.id, testPlanId1))
      .limit(1);

    expect(plan).toBeDefined(); // Linha ainda existe
    expect(plan.deletedAt).not.toBeNull(); // Mas está marcada como deletada
  });
});
