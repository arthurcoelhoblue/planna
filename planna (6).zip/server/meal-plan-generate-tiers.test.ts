/**
 * PATCH 8.8.0 - Meal Plan Generate Tier Enforcement Tests
 * 
 * Testes para validar que mealPlan.generate respeita limites por tier
 */

import { describe, it, expect, beforeEach, vi } from "vitest";
import { TIER_LIMITS, type SubscriptionTier } from "../shared/tier-limits";

// Mock functions
const mockGetUserTier = vi.fn();
const mockCountUserPlansThisMonth = vi.fn();

// Mock modules
vi.mock("./_core/subscription-tier", () => ({
  getUserTier: mockGetUserTier,
}));

vi.mock("./db", () => ({
  countUserPlansThisMonth: mockCountUserPlansThisMonth,
  getUserPreference: vi.fn().mockResolvedValue(null),
  getUserDishFeedback: vi.fn().mockResolvedValue([]),
}));

vi.mock("./_core/meal-plan", () => ({
  createAndStorePlan: vi.fn().mockResolvedValue({
    id: 1,
    sessionId: 1,
  }),
}));

vi.mock("./_core/rateLimit", () => ({
  assertRateLimit: vi.fn().mockResolvedValue(undefined),
}));

describe("mealPlan.generate - Tier Enforcement", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Limite de planos por mês", () => {
    it("free deve bloquear após 2 planos", async () => {
      mockGetUserTier.mockResolvedValue("free");
      mockCountUserPlansThisMonth.mockResolvedValue(2);

      const { getTierLimits, hasReachedLimit } = await import("../shared/tier-limits");
      const tier: SubscriptionTier = "free";
      const limits = getTierLimits(tier);
      const usedThisMonth = 2;

      expect(hasReachedLimit(tier, "maxPlansPerMonth", usedThisMonth)).toBe(true);
      expect(limits.maxPlansPerMonth).toBe(2);
    });

    it("free não deve bloquear antes de 2 planos", async () => {
      mockGetUserTier.mockResolvedValue("free");
      mockCountUserPlansThisMonth.mockResolvedValue(1);

      const { getTierLimits, hasReachedLimit } = await import("../shared/tier-limits");
      const tier: SubscriptionTier = "free";
      const usedThisMonth = 1;

      expect(hasReachedLimit(tier, "maxPlansPerMonth", usedThisMonth)).toBe(false);
    });

    it("pro deve bloquear após 10 planos", async () => {
      mockGetUserTier.mockResolvedValue("pro");
      mockCountUserPlansThisMonth.mockResolvedValue(10);

      const { getTierLimits, hasReachedLimit } = await import("../shared/tier-limits");
      const tier: SubscriptionTier = "pro";
      const limits = getTierLimits(tier);
      const usedThisMonth = 10;

      expect(hasReachedLimit(tier, "maxPlansPerMonth", usedThisMonth)).toBe(true);
      expect(limits.maxPlansPerMonth).toBe(10);
    });

    it("pro não deve bloquear antes de 10 planos", async () => {
      mockGetUserTier.mockResolvedValue("pro");
      mockCountUserPlansThisMonth.mockResolvedValue(9);

      const { hasReachedLimit } = await import("../shared/tier-limits");
      const tier: SubscriptionTier = "pro";
      const usedThisMonth = 9;

      expect(hasReachedLimit(tier, "maxPlansPerMonth", usedThisMonth)).toBe(false);
    });

    it("premium nunca deve bloquear", async () => {
      mockGetUserTier.mockResolvedValue("premium");
      mockCountUserPlansThisMonth.mockResolvedValue(100);

      const { hasReachedLimit } = await import("../shared/tier-limits");
      const tier: SubscriptionTier = "premium";
      const usedThisMonth = 100;

      expect(hasReachedLimit(tier, "maxPlansPerMonth", usedThisMonth)).toBe(false);
    });

    it("vip nunca deve bloquear", async () => {
      mockGetUserTier.mockResolvedValue("vip");
      mockCountUserPlansThisMonth.mockResolvedValue(1000);

      const { hasReachedLimit } = await import("../shared/tier-limits");
      const tier: SubscriptionTier = "vip";
      const usedThisMonth = 1000;

      expect(hasReachedLimit(tier, "maxPlansPerMonth", usedThisMonth)).toBe(false);
    });
  });

  describe("Clamp de servings por tier", () => {
    it("free deve clampar servings para 10", () => {
      const { getTierLimits } = TIER_LIMITS;
      const limits = TIER_LIMITS.free;
      
      const requestedServings = 20;
      const clampedServings = Math.min(requestedServings, limits.maxServings);
      
      expect(clampedServings).toBe(10);
    });

    it("pro deve clampar servings para 20", () => {
      const limits = TIER_LIMITS.pro;
      
      const requestedServings = 30;
      const clampedServings = Math.min(requestedServings, limits.maxServings);
      
      expect(clampedServings).toBe(20);
    });

    it("premium deve clampar servings para 20", () => {
      const limits = TIER_LIMITS.premium;
      
      const requestedServings = 30;
      const clampedServings = Math.min(requestedServings, limits.maxServings);
      
      expect(clampedServings).toBe(20);
    });
  });

  describe("Clamp de varieties por tier", () => {
    it("free deve clampar varieties para 3", () => {
      const limits = TIER_LIMITS.free;
      
      const requestedVarieties = 6;
      const clampedVarieties = Math.min(requestedVarieties, limits.maxVarieties);
      
      expect(clampedVarieties).toBe(3);
    });

    it("pro deve clampar varieties para 6", () => {
      const limits = TIER_LIMITS.pro;
      
      const requestedVarieties = 10;
      const clampedVarieties = Math.min(requestedVarieties, limits.maxVarieties);
      
      expect(clampedVarieties).toBe(6);
    });

    it("premium deve clampar varieties para 6", () => {
      const limits = TIER_LIMITS.premium;
      
      const requestedVarieties = 10;
      const clampedVarieties = Math.min(requestedVarieties, limits.maxVarieties);
      
      expect(clampedVarieties).toBe(6);
    });
  });

  describe("Enforcement de modos avançados", () => {
    it("free deve forçar modo normal", () => {
      const limits = TIER_LIMITS.free;
      
      const requestedMode = "lowcal";
      const allowedMode = limits.allowAdvancedModes ? requestedMode : "normal";
      
      expect(allowedMode).toBe("normal");
      expect(limits.allowAdvancedModes).toBe(false);
    });

    it("pro deve permitir modos avançados", () => {
      const limits = TIER_LIMITS.pro;
      
      const requestedMode = "lowcal";
      const allowedMode = limits.allowAdvancedModes ? requestedMode : "normal";
      
      expect(allowedMode).toBe("lowcal");
      expect(limits.allowAdvancedModes).toBe(true);
    });

    it("premium deve permitir modos avançados", () => {
      const limits = TIER_LIMITS.premium;
      
      const requestedMode = "highprotein";
      const allowedMode = limits.allowAdvancedModes ? requestedMode : "normal";
      
      expect(allowedMode).toBe("highprotein");
      expect(limits.allowAdvancedModes).toBe(true);
    });

    it("vip deve permitir modos avançados", () => {
      const limits = TIER_LIMITS.vip;
      
      const requestedMode = "aproveitamento";
      const allowedMode = limits.allowAdvancedModes ? requestedMode : "normal";
      
      expect(allowedMode).toBe("aproveitamento");
      expect(limits.allowAdvancedModes).toBe(true);
    });
  });

  describe("Enforcement de sophistication", () => {
    it("free deve permitir apenas 'simples'", () => {
      const limits = TIER_LIMITS.free;
      
      const requestedSophistication = "gourmet";
      // Free não tem campo específico para sophistication, mas podemos adicionar se necessário
      // Por enquanto, sophistication não está no TIER_LIMITS
      expect(limits.allowAdvancedModes).toBe(false);
    });
  });

  describe("Input ajustado", () => {
    it("deve criar input ajustado com limites aplicados", () => {
      const limits = TIER_LIMITS.free;
      const input = {
        ingredients: "frango, arroz",
        servings: 20,
        varieties: 6,
        objective: "lowcal" as const,
      };

      const adjustedInput = {
        ...input,
        servings: Math.min(input.servings, limits.maxServings),
        varieties: Math.min(input.varieties, limits.maxVarieties),
        objective: limits.allowAdvancedModes ? input.objective : "normal" as const,
      };

      expect(adjustedInput.servings).toBe(10);
      expect(adjustedInput.varieties).toBe(3);
      expect(adjustedInput.objective).toBe("normal");
    });

    it("pro não deve alterar input dentro dos limites", () => {
      const limits = TIER_LIMITS.pro;
      const input = {
        ingredients: "frango, arroz",
        servings: 15,
        varieties: 4,
        objective: "lowcal" as const,
      };

      const adjustedInput = {
        ...input,
        servings: Math.min(input.servings, limits.maxServings),
        varieties: Math.min(input.varieties, limits.maxVarieties),
        objective: limits.allowAdvancedModes ? input.objective : "normal" as const,
      };

      expect(adjustedInput.servings).toBe(15);
      expect(adjustedInput.varieties).toBe(4);
      expect(adjustedInput.objective).toBe("lowcal");
    });
  });
});
