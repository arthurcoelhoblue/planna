import { describe, it, expect } from "vitest";

/**
 * PATCH 7.1.0 - Testes de Integração: Preferences + Planner
 *
 * Valida que:
 * 1. preferences.get sempre retorna objeto completo com defaults
 * 2. Nunca retorna null
 * 3. Valores salvos são refletidos corretamente
 * 4. Planner pode hidratar estados iniciais com esses valores
 */

describe("PATCH 7.1.0 - Integração Preferences + Planner", () => {
  describe("Backend - preferences.get com defaults", () => {
    it("deve sempre retornar objeto completo (nunca null)", () => {
      // Simula resposta do helper getUserPreferences
      const mockPreferences = {
        mode: "normal",
        servings: 10,
        varieties: 3,
        time: null,
        allowNewIngredients: true,
        exclusions: [],
        skillLevel: "intermediate",
        dietType: null,
        dietProfile: null,
        maxKcalPerServing: null,
        favorites: [],
      };

      // Valida que todos os campos obrigatórios estão presentes
      expect(mockPreferences).toBeDefined();
      expect(mockPreferences).not.toBeNull();
      expect(mockPreferences.mode).toBe("normal");
      expect(mockPreferences.servings).toBe(10);
      expect(mockPreferences.varieties).toBe(3);
      expect(mockPreferences.allowNewIngredients).toBe(true);
      expect(Array.isArray(mockPreferences.exclusions)).toBe(true);
    });

    it("deve retornar defaults quando usuário não tem preferências salvas", () => {
      // Simula usuário novo sem registro em user_preferences
      const defaultPreferences = {
        mode: "normal",
        servings: 10,
        varieties: 3,
        time: null,
        allowNewIngredients: true,
        exclusions: [],
        skillLevel: "intermediate",
        dietType: null,
        dietProfile: null,
        maxKcalPerServing: null,
        favorites: [],
      };

      // Valida defaults
      expect(defaultPreferences.mode).toBe("normal");
      expect(defaultPreferences.servings).toBe(10);
      expect(defaultPreferences.varieties).toBe(3);
      expect(defaultPreferences.time).toBeNull();
      expect(defaultPreferences.allowNewIngredients).toBe(true);
    });

    it("deve retornar valores salvos quando usuário tem preferências", () => {
      // Simula usuário com preferências personalizadas
      const customPreferences = {
        mode: "aproveitamento",
        servings: 15,
        varieties: 4,
        time: 120, // 2 horas
        allowNewIngredients: false,
        exclusions: ["gluten", "lactose"],
        skillLevel: "advanced",
        dietType: "low carb",
        dietProfile: null,
        maxKcalPerServing: 500,
        favorites: ["frango", "arroz"],
      };

      // Valida que valores salvos são retornados
      expect(customPreferences.mode).toBe("aproveitamento");
      expect(customPreferences.servings).toBe(15);
      expect(customPreferences.varieties).toBe(4);
      expect(customPreferences.time).toBe(120);
      expect(customPreferences.allowNewIngredients).toBe(false);
      expect(customPreferences.exclusions).toEqual(["gluten", "lactose"]);
      expect(customPreferences.skillLevel).toBe("advanced");
      expect(customPreferences.dietType).toBe("low carb");
      expect(customPreferences.maxKcalPerServing).toBe(500);
    });
  });

  describe("Frontend - Hidratação de Estados do Planner", () => {
    it("deve hidratar mode (objective) a partir de preferences.mode", () => {
      const preferences = { mode: "aproveitamento" };
      const expectedObjective = "aproveitamento";

      // Simula lógica do useEffect
      let objective = "normal"; // default local
      if (preferences.mode) {
        objective = preferences.mode as "normal" | "aproveitamento";
      }

      expect(objective).toBe(expectedObjective);
    });

    it("deve hidratar servings a partir de preferences.servings", () => {
      const preferences = { servings: 15 };
      const expectedServings = [15];

      // Simula lógica do useEffect
      let servings = [10]; // default local
      if (typeof preferences.servings === "number") {
        servings = [preferences.servings];
      }

      expect(servings).toEqual(expectedServings);
    });

    it("deve hidratar varieties a partir de preferences.varieties", () => {
      const preferences = { varieties: 4 };
      const expectedVarieties = [4];

      // Simula lógica do useEffect
      let varieties = [3]; // default local
      if (typeof preferences.varieties === "number") {
        varieties = [preferences.varieties];
      }

      expect(varieties).toEqual(expectedVarieties);
    });

    it("deve hidratar time a partir de preferences.time", () => {
      const preferences = { time: 120 };
      const expectedTime = 120;

      // Simula lógica do useEffect
      let availableTime: number | null = null; // default local
      if (typeof preferences.time === "number" || preferences.time === null) {
        availableTime = preferences.time;
      }

      expect(availableTime).toBe(expectedTime);
    });

    it("deve hidratar allowNewIngredients a partir de preferences.allowNewIngredients", () => {
      const preferences = { allowNewIngredients: false };
      const expectedAllowNewIngredients = false;

      // Simula lógica do useEffect
      let allowNewIngredients = true; // default local
      if (typeof preferences.allowNewIngredients === "boolean") {
        allowNewIngredients = preferences.allowNewIngredients;
      }

      expect(allowNewIngredients).toBe(expectedAllowNewIngredients);
    });

    it("deve hidratar dietType a partir de preferences.dietType", () => {
      const preferences = { dietType: "low carb" };
      const expectedDietType = "low carb";

      // Simula lógica do useEffect
      let dietType = ""; // default local
      if (preferences.dietType) {
        dietType = preferences.dietType;
      }

      expect(dietType).toBe(expectedDietType);
    });

    it("deve hidratar skillLevel a partir de preferences.skillLevel", () => {
      const preferences = { skillLevel: "advanced" };
      const expectedSkillLevel = "advanced";

      // Simula lógica do useEffect
      let skillLevel: "beginner" | "intermediate" | "advanced" = "intermediate"; // default local
      if (preferences.skillLevel) {
        skillLevel = preferences.skillLevel as "beginner" | "intermediate" | "advanced";
      }

      expect(skillLevel).toBe(expectedSkillLevel);
    });

    it("deve hidratar calorieLimit a partir de preferences.maxKcalPerServing", () => {
      const preferences = { maxKcalPerServing: 500 };
      const expectedCalorieLimit = 500;

      // Simula lógica do useEffect
      let calorieLimit: number | null = null; // default local
      if (preferences.maxKcalPerServing) {
        calorieLimit = preferences.maxKcalPerServing;
      }

      expect(calorieLimit).toBe(expectedCalorieLimit);
    });
  });

  describe("Fluxo Completo - Usuário Novo vs Usuário com Preferências", () => {
    it("deve usar defaults locais quando preferences ainda está carregando", () => {
      // Simula estado inicial do Planner (preferences = undefined)
      const preferences = undefined;
      const initializedFromPrefs = false;

      // Lógica do useEffect não roda
      const shouldHydrate = !!(preferences && !initializedFromPrefs);

      expect(shouldHydrate).toBe(false);

      // Estados permanecem com defaults locais
      const objective = "normal";
      const servings = [10];
      const varieties = [3];
      const allowNewIngredients = true;

      expect(objective).toBe("normal");
      expect(servings).toEqual([10]);
      expect(varieties).toEqual([3]);
      expect(allowNewIngredients).toBe(true);
    });

    it("deve hidratar apenas uma vez (initializedFromPrefs = true)", () => {
      // Simula primeira execução do useEffect
      const preferences = { mode: "aproveitamento", servings: 15 };
      let initializedFromPrefs = false;

      // Primeira execução: hidrata
      let objective = "normal";
      if (preferences && !initializedFromPrefs) {
        objective = preferences.mode as "normal" | "aproveitamento";
        initializedFromPrefs = true;
      }

      expect(objective).toBe("aproveitamento");
      expect(initializedFromPrefs).toBe(true);

      // Segunda execução: não hidrata (initializedFromPrefs = true)
      const newPreferences = { mode: "normal", servings: 10 };
      if (newPreferences && !initializedFromPrefs) {
        objective = newPreferences.mode as "normal" | "aproveitamento";
      }

      // objective permanece "aproveitamento" (não foi sobrescrito)
      expect(objective).toBe("aproveitamento");
    });

    it("deve preservar mudanças manuais do usuário após hidratação", () => {
      // Simula hidratação inicial
      const preferences = { servings: 10 };
      let servings = [10];
      let initializedFromPrefs = false;

      if (preferences && !initializedFromPrefs) {
        servings = [preferences.servings];
        initializedFromPrefs = true;
      }

      expect(servings).toEqual([10]);

      // Usuário altera manualmente para 15
      servings = [15];
      expect(servings).toEqual([15]);

      // useEffect não sobrescreve (initializedFromPrefs = true)
      if (preferences && !initializedFromPrefs) {
        servings = [preferences.servings];
      }

      // servings permanece 15 (mudança manual preservada)
      expect(servings).toEqual([15]);
    });
  });

  describe("Validação de Tipos", () => {
    it("deve validar tipo de mode (string)", () => {
      const preferences = { mode: "normal" };
      expect(typeof preferences.mode).toBe("string");
    });

    it("deve validar tipo de servings (number)", () => {
      const preferences = { servings: 10 };
      expect(typeof preferences.servings).toBe("number");
    });

    it("deve validar tipo de varieties (number)", () => {
      const preferences = { varieties: 3 };
      expect(typeof preferences.varieties).toBe("number");
    });

    it("deve validar tipo de time (number ou null)", () => {
      const preferences1 = { time: 120 };
      const preferences2 = { time: null };

      expect(typeof preferences1.time === "number" || preferences1.time === null).toBe(true);
      expect(typeof preferences2.time === "number" || preferences2.time === null).toBe(true);
    });

    it("deve validar tipo de allowNewIngredients (boolean)", () => {
      const preferences = { allowNewIngredients: true };
      expect(typeof preferences.allowNewIngredients).toBe("boolean");
    });

    it("deve validar tipo de exclusions (array)", () => {
      const preferences = { exclusions: ["gluten", "lactose"] };
      expect(Array.isArray(preferences.exclusions)).toBe(true);
    });
  });
});
