/**
 * PATCH 8.6.0: Testes para regeneração de lista de compras
 * Valida endpoint mealPlan.regenerateShoppingList
 */

import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { Context } from "./_core/context";

// Mock context para testes
const createMockContext = (userId: number): Context => {
  return {
    user: {
      id: userId,
      openId: `test_${userId}`,
      email: `user${userId}@test.com`,
      name: `Test User ${userId}`,
      role: "user",
      emailVerified: true,
      subscriptionTier: "free",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {} as any,
    res: {} as any,
    ip: "127.0.0.1",
  };
};

describe("PATCH 8.6.0 - Regeneração de Lista de Compras", () => {
  let testPlanId: number;
  const ctx = createMockContext(1);
  const caller = appRouter.createCaller(ctx);

  beforeAll(async () => {
    // Criar um plano de teste
    const result = await caller.mealPlan.generate({
      ingredients: "frango, arroz, feijão",
      servings: 10,
      varieties: 2,
    });
    testPlanId = result.planId;
  }, 30000); // 30 segundos timeout para geração de plano

  it("deve regenerar lista de compras com sucesso", async () => {
    const result = await caller.mealPlan.regenerateShoppingList({
      planId: testPlanId,
    });

    expect(result.ok).toBe(true);
    expect(result.newPlan).toBeDefined();
    expect(result.newPlan.shoppingList).toBeDefined();
    expect(Array.isArray(result.newPlan.shoppingList)).toBe(true);
    expect(result.newVersion).toBeDefined();
    expect(result.newVersion.version).toBeGreaterThan(0);
    expect(result.diff).toBeDefined();
    expect(result.diff.oldList).toBeDefined();
    expect(result.diff.newList).toBeDefined();
  }, 15000); // 15 segundos timeout para LLM

  it("deve retornar erro para planId inválido", async () => {
    await expect(
      caller.mealPlan.regenerateShoppingList({
        planId: 999999,
      })
    ).rejects.toThrow("Plano não encontrado");
  }, 15000); // 15 segundos timeout

  it("deve criar versão incremental após regeneração", async () => {
    // Regenerar primeira vez
    const firstRegen = await caller.mealPlan.regenerateShoppingList({
      planId: testPlanId,
    });
    const firstVersion = firstRegen.newVersion.version;

    // Regenerar segunda vez
    const secondRegen = await caller.mealPlan.regenerateShoppingList({
      planId: testPlanId,
    });
    const secondVersion = secondRegen.newVersion.version;

    expect(secondVersion).toBeGreaterThan(firstVersion);
  }, 30000); // 30 segundos timeout para 2 regenerações

  it("deve validar estrutura do snapshot de versão", async () => {
    const result = await caller.mealPlan.regenerateShoppingList({
      planId: testPlanId,
    });

    // Buscar versão criada
    const versions = await caller.mealPlan.listVersions({
      planId: testPlanId,
    });

    const latestVersion = versions[versions.length - 1];
    expect(latestVersion).toBeDefined();
    expect(latestVersion.id).toBe(result.newVersion.id);
    expect(latestVersion.version).toBe(result.newVersion.version);
  }, 15000); // 15 segundos timeout

  it("deve preservar estrutura da lista de compras", async () => {
    const result = await caller.mealPlan.regenerateShoppingList({
      planId: testPlanId,
    });

    const shoppingList = result.newPlan.shoppingList;
    expect(Array.isArray(shoppingList)).toBe(true);

    // Validar estrutura de cada categoria
    shoppingList.forEach((category: any) => {
      expect(category).toHaveProperty("category");
      expect(category).toHaveProperty("items");
      expect(Array.isArray(category.items)).toBe(true);

      // Validar estrutura de cada item
      category.items.forEach((item: any) => {
        expect(item).toHaveProperty("item");
        expect(item).toHaveProperty("quantity");
        expect(item).toHaveProperty("unit");
      });
    });
  }, 15000); // 15 segundos timeout
});
