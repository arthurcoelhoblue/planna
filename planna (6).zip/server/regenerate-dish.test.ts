import { describe, it, expect, beforeAll } from "vitest";
import { getDb } from "./db";
import { plans, sessions, users, planVersions } from "../drizzle/schema";
import { eq } from "drizzle-orm";

describe("regenerateDish endpoint", () => {
  let testUserId: number;
  let testSessionId: number;
  let testPlanId: number;

  beforeAll(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Criar usuário de teste
    const [user] = await db
      .insert(users)
      .values({
        openId: `test_regenerate_${Date.now()}`,
        name: "Test User Regenerate",
        email: `test_regenerate_${Date.now()}@test.com`,
        loginMethod: "test",
      })
      .$returningId();

    testUserId = user.id;

    // Criar sessão de teste
    const [session] = await db
      .insert(sessions)
      .values({
        userId: testUserId,
        inputText: "frango, arroz, feijão",
        servings: 5,
        objective: "normal",
        exclusions: "[]",
      })
      .$returningId();

    testSessionId = session.id;

    // Criar plano de teste com prato válido
    const testDishes = [
      {
        name: "Frango Grelhado com Arroz",
        servings: 5,
        ingredients: [
          { name: "frango", quantity: "500g" },
          { name: "arroz", quantity: "300g" },
        ],
        steps: ["Grelhar o frango", "Cozinhar o arroz"],
        kcal: 450,
        prepTime: 30,
      },
      {
        name: "Feijão Tropeiro",
        servings: 5,
        ingredients: [{ name: "feijão", quantity: "400g" }],
        steps: ["Cozinhar o feijão"],
        kcal: 350,
        prepTime: 25,
      },
    ];

    const [plan] = await db
      .insert(plans)
      .values({
        sessionId: testSessionId,
        dishes: JSON.stringify(testDishes),
        shoppingList: JSON.stringify([
          { item: "frango", quantity: "500", unit: "g", category: "Proteínas" },
        ]),
        prepSchedule: JSON.stringify([{ step: "Preparar ingredientes" }]),
      })
      .$returningId();

    testPlanId = plan.id;
  });

  it("deve validar que o plano de teste existe", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const plan = await db
      .select()
      .from(plans)
      .where(eq(plans.id, testPlanId))
      .limit(1);

    expect(plan.length).toBe(1);
    expect(plan[0].id).toBe(testPlanId);

    const dishes = JSON.parse(plan[0].dishes);
    expect(dishes.length).toBeGreaterThan(0);
    expect(dishes[0]).toHaveProperty("name");
    expect(dishes[0]).toHaveProperty("ingredients");
  });

  it("deve retornar erro se planId não existir", async () => {
    const { regenerateDish } = await import("./_core/llm");
    const { getPlanById } = await import("./db");

    const plan = await getPlanById(999999);
    expect(plan).toBeNull();
  });

  it("deve retornar erro se dishIndex for inválido", async () => {
    const { getPlanById } = await import("./db");

    const plan = await getPlanById(testPlanId);
    expect(plan).not.toBeNull();

    const dishes = JSON.parse(plan!.dishes);
    const invalidIndex = dishes.length + 10;

    // Validar que o índice é maior que o array
    expect(invalidIndex).toBeGreaterThan(dishes.length - 1);
  });

  it("deve criar nova versão ao regenerar prato", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const { saveNewPlanVersion } = await import("./_core/planVersion");
    const { getPlanById } = await import("./db");

    const plan = await getPlanById(testPlanId);
    expect(plan).not.toBeNull();

    const dishes = JSON.parse(plan!.dishes);
    const shoppingList = JSON.parse(plan!.shoppingList);

    // Salvar primeira versão
    const version1 = await saveNewPlanVersion(testPlanId, {
      dishes,
      shoppingList,
    });

    expect(version1.version).toBe(1);
    expect(version1.id).toBeTypeOf("number");

    // Salvar segunda versão
    const version2 = await saveNewPlanVersion(testPlanId, {
      dishes,
      shoppingList,
    });

    expect(version2.version).toBe(2);
    expect(version2.id).toBeTypeOf("number");

    // Verificar no banco
    const versions = await db
      .select()
      .from(planVersions)
      .where(eq(planVersions.planId, testPlanId));

    expect(versions.length).toBeGreaterThanOrEqual(2);
    expect(versions.some(v => v.version === 1)).toBe(true);
    expect(versions.some(v => v.version === 2)).toBe(true);
  });

  it("deve validar estrutura do snapshot de versão", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const { saveNewPlanVersion } = await import("./_core/planVersion");

    const snapshot = {
      dishes: [{ name: "Test Dish", servings: 5 }],
      shoppingList: [{ item: "test", quantity: "100", unit: "g" }],
      prepSchedule: [{ step: "Test step" }],
      usedStock: { frango: "500g" },
      remainingStock: { arroz: "200g" },
      substitutions: [{ original: "X", replacement: "Y" }],
    };

    const version = await saveNewPlanVersion(testPlanId, snapshot);
    expect(version.version).toBeGreaterThan(0);

    // Buscar versão criada
    const savedVersion = await db
      .select()
      .from(planVersions)
      .where(eq(planVersions.id, version.id))
      .limit(1);

    expect(savedVersion.length).toBe(1);
    expect(savedVersion[0].dishes).toBeDefined();
    expect(savedVersion[0].shoppingList).toBeDefined();
  });

  it("deve incrementar versão corretamente quando não há versões anteriores", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const { saveNewPlanVersion } = await import("./_core/planVersion");

    // Criar novo plano sem versões
    const [newSession] = await db
      .insert(sessions)
      .values({
        userId: testUserId,
        inputText: "teste",
        servings: 3,
        objective: "normal",
        exclusions: "[]",
      })
      .$returningId();

    const [newPlan] = await db
      .insert(plans)
      .values({
        sessionId: newSession.id,
        dishes: JSON.stringify([{ name: "Test" }]),
        shoppingList: JSON.stringify([]),
        prepSchedule: JSON.stringify([]),
      })
      .$returningId();

    // Primeira versão deve ser 1
    const version = await saveNewPlanVersion(newPlan.id, {
      dishes: [{ name: "Test" }],
      shoppingList: [],
    });

    expect(version.version).toBe(1);
  });
});
