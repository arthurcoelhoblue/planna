export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  stripeSecretKey: process.env.STRIPE_SECRET_KEY ?? "",
  stripePublishableKey: process.env.VITE_STRIPE_PUBLISHABLE_KEY ?? "",
  // Webhook secret do Stripe CLI para testes locais
  // Forçar uso do hardcoded porque o env está truncado em 38 chars
  stripeWebhookSecret: process.env.NODE_ENV === "production" 
    ? process.env.STRIPE_WEBHOOK_SECRET || ""
    : "whsec_0e10fcb25a5b162eefdd89255d6a177928b00b131026168f3d172bfd14bd88a7",
  // PATCH 8.1.0: Admin funnel secret
  adminFunnelSecret: process.env.ADMIN_FUNNEL_SECRET || "dev_funnel_secret_change_in_prod",
};
