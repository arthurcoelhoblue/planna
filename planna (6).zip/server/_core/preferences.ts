import { eq } from "drizzle-orm";
import { userPreferences } from "../../drizzle/schema";

/**
 * PATCH 7.0.0 - User Preferences Helpers
 * PATCH 7.7.0 - Normalização de campos JSON
 * 
 * Manages user preferences for the meal planner, including:
 * - mode: planner mode (normal, aproveitamento, lowcal, highprotein)
 * - servings: default number of servings/meals
 * - varieties: default number of dish varieties
 * - time: typical available prep time (in minutes)
 * - allowNewIngredients: whether to allow new ingredients beyond stock
 * - exclusions: list of ingredients to avoid
 * - favorites: list of preferred ingredients
 */

/**
 * PATCH 7.7.0 - Helper to normalize string array fields
 * 
 * Supports multiple input formats:
 * - Array: ["item1", "item2"] → ["item1", "item2"]
 * - JSON string: '["item1", "item2"]' → ["item1", "item2"]
 * - Comma-separated string: "item1, item2" → ["item1", "item2"]
 * - Newline-separated string: "item1\nitem2" → ["item1", "item2"]
 * - null/undefined → []
 */
function normalizeStringArrayField(raw: unknown): string[] {
  if (!raw) return [];
  
  if (Array.isArray(raw)) {
    return raw.map((x) => String(x).trim()).filter(Boolean);
  }
  
  if (typeof raw === "string") {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.map((x) => String(x).trim()).filter(Boolean);
      }
      // Fallback: string simples separada por vírgula/quebra de linha
      return raw
        .split(/[,\n]/)
        .map((s) => s.trim())
        .filter(Boolean);
    } catch {
      // JSON inválido → tentar quebrar por vírgula/quebra de linha como fallback
      return raw
        .split(/[,\n]/)
        .map((s) => s.trim())
        .filter(Boolean);
    }
  }
  
  return [];
}

const DEFAULT_PREFERENCES = {
  mode: "normal",
  servings: 10,
  varieties: 3,
  time: null,
  allowNewIngredients: true,
  exclusions: [],
  // Existing fields (not part of PATCH 7.0.0 but needed for compatibility)
  skillLevel: "intermediate",
  dietType: null,
  dietProfile: null,
  maxKcalPerServing: null,
  favorites: [],
};

/**
 * Get user preferences, returning defaults if no preferences exist
 */
export async function getUserPreferences(db: any, userId: number) {
  const rows = await db
    .select()
    .from(userPreferences)
    .where(eq(userPreferences.userId, userId));

  const pref = rows[0];
  if (!pref) {
    return {
      ...DEFAULT_PREFERENCES,
    };
  }

  // PATCH 7.7.0: Use helper to normalize array fields
  const exclusionsList = normalizeStringArrayField(pref.exclusions);
  const favoritesList = normalizeStringArrayField(pref.favorites);
  
  // dietProfile is an object, not an array, so keep original parsing
  let dietProfileObj = DEFAULT_PREFERENCES.dietProfile;
  if (pref.dietProfile) {
    try {
      dietProfileObj = typeof pref.dietProfile === 'string' 
        ? JSON.parse(pref.dietProfile) 
        : pref.dietProfile;
    } catch (e) {
      console.warn('[Preferences] Failed to parse dietProfile:', e);
      dietProfileObj = DEFAULT_PREFERENCES.dietProfile;
    }
  }

  return {
    mode: pref.mode ?? DEFAULT_PREFERENCES.mode,
    servings: pref.servings ?? DEFAULT_PREFERENCES.servings,
    varieties: pref.varieties ?? DEFAULT_PREFERENCES.varieties,
    time: pref.time ?? DEFAULT_PREFERENCES.time,
    allowNewIngredients:
      pref.allowNewIngredients ?? DEFAULT_PREFERENCES.allowNewIngredients,
    exclusions: exclusionsList,
    // Existing fields
    skillLevel: pref.skillLevel ?? DEFAULT_PREFERENCES.skillLevel,
    dietType: pref.dietType ?? DEFAULT_PREFERENCES.dietType,
    dietProfile: dietProfileObj,
    maxKcalPerServing: pref.maxKcalPerServing ?? DEFAULT_PREFERENCES.maxKcalPerServing,
    favorites: favoritesList,
  };
}

/**
 * Upsert user preferences (create if not exists, update if exists)
 */
export async function upsertUserPreferences(
  db: any,
  userId: number,
  input: Partial<{
    mode: string;
    servings: number;
    varieties: number;
    time: number | null;
    allowNewIngredients: boolean;
    exclusions: unknown;
  }>
) {
  const rows = await db
    .select()
    .from(userPreferences)
    .where(eq(userPreferences.userId, userId));

  // Serialize exclusions to string if it's an array
  const exclusionsValue = input.exclusions !== undefined
    ? (typeof input.exclusions === 'string' 
        ? input.exclusions 
        : JSON.stringify(input.exclusions))
    : undefined;

  if (!rows[0]) {
    // Insert new preferences
    await db.insert(userPreferences).values({
      userId,
      mode: input.mode ?? DEFAULT_PREFERENCES.mode,
      servings: input.servings ?? DEFAULT_PREFERENCES.servings,
      varieties: input.varieties ?? DEFAULT_PREFERENCES.varieties,
      time: input.time ?? DEFAULT_PREFERENCES.time,
      allowNewIngredients:
        input.allowNewIngredients ?? DEFAULT_PREFERENCES.allowNewIngredients,
      exclusions: exclusionsValue ?? JSON.stringify(DEFAULT_PREFERENCES.exclusions),
    });
  } else {
    // Update existing preferences
    const updateData: any = {};
    
    if (input.mode !== undefined) updateData.mode = input.mode;
    if (input.servings !== undefined) updateData.servings = input.servings;
    if (input.varieties !== undefined) updateData.varieties = input.varieties;
    if (input.time !== undefined) updateData.time = input.time;
    if (input.allowNewIngredients !== undefined) updateData.allowNewIngredients = input.allowNewIngredients;
    if (exclusionsValue !== undefined) updateData.exclusions = exclusionsValue;

    await db
      .update(userPreferences)
      .set(updateData)
      .where(eq(userPreferences.userId, userId));
  }

  return getUserPreferences(db, userId);
}
