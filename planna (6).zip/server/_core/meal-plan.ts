/**
 * PATCH 7.9.0 - Função reutilizável para criar e armazenar planos
 * Usada tanto por usuários logados quanto por visitantes anônimos
 */

import { z } from "zod";

export const GeneratePlanInputSchema = z.object({
  ingredients: z.string(),
  servings: z.number().min(1).max(20),
  exclusions: z.array(z.string()).optional(),
  objective: z.enum(["normal", "aproveitamento", "lowcal", "highprotein"]).optional(),
  varieties: z.number().min(1).max(6).optional(),
  allowNewIngredients: z.boolean().optional(),
  sophistication: z.enum(["simples", "gourmet"]).optional(),
  calorieLimit: z.number().min(200).max(2000).optional(),
  skillLevel: z.enum(["beginner", "intermediate", "advanced"]).optional(),
  availableTime: z.number().min(1).max(24).optional(),
  dietType: z.string().optional(),
});

export type GeneratePlanInput = z.infer<typeof GeneratePlanInputSchema>;

interface CreatePlanParams {
  userId: number | null; // null para planos anônimos
  input: GeneratePlanInput;
  userPreferences?: {
    favorites?: string[];
    exclusions?: string[];
    skillLevel?: "beginner" | "intermediate" | "advanced";
    dietType?: string;
  };
  userDislikes?: string[];
}

export async function createAndStorePlan(params: CreatePlanParams) {
  const { userId, input, userPreferences, userDislikes = [] } = params;

  const { parseIngredients } = await import("../ingredients-dictionary");
  const { generateMealPlan } = await import("../recipe-engine");
  const { createSession, createPlan } = await import("../db");

  // 1) Parse da entrada livre → ingredientes normalizados + estoque
  const parsedIngredients = parseIngredients(input.ingredients);

  // Monta lista com nome canônico + quantidade/unidade quando existir
  const ingredientsWithStock = parsedIngredients
    .filter(i => i.canonical)
    .map(i => ({
      name: i.canonical!,
      ...(i.quantity ? { quantity: i.quantity } : {}),
      ...(i.inputUnit || i.unit ? { unit: (i.inputUnit || i.unit)! } : {}),
    }));

  // Se por algum motivo nada foi mapeado, cai no fallback só com nomes
  const availableIngredients =
    ingredientsWithStock.length > 0
      ? ingredientsWithStock
      : parsedIngredients
          .filter(i => i.canonical)
          .map(i => i.canonical!);

  // 2) Exclusions combinadas (input + preferências)
  const allExclusions = [
    ...(input.exclusions || []),
    ...(userPreferences?.exclusions || []),
  ];

  // 3) Normalização dos parâmetros que o motor REALMENTE usa
  const resolvedSkillLevel =
    input.skillLevel || userPreferences?.skillLevel || "intermediate";

  const resolvedDietType =
    input.dietType || userPreferences?.dietType || undefined;

  // 4) Chamada do Recipe Engine com estoque real
  const plan = await generateMealPlan({
    availableIngredients,
    servings: input.servings,
    exclusions: allExclusions,
    objective: input.objective,
    varieties: input.varieties,
    allowNewIngredients: input.allowNewIngredients,
    sophistication: input.sophistication,
    skillLevel: resolvedSkillLevel,
    calorieLimit: input.calorieLimit,
    dietType: resolvedDietType,
    userFavorites: userPreferences?.favorites || [],
    userDislikes,
    availableTime: input.availableTime,
  });

  // 5) Salva sessão (entrada original)
  // Para planos anônimos, userId será null
  const sessionId = await createSession({
    userId: userId || 0, // 0 será usado como placeholder para anônimos
    inputText: input.ingredients,
    servings: input.servings,
    objective: input.objective || "normal",
    exclusions: JSON.stringify(input.exclusions || []),
  });

  // 6) Salva plano com TODOS os metadados que o PlanView espera
  const planId = await createPlan({
    sessionId,
    dishes: JSON.stringify(plan.dishes),
    shoppingList: JSON.stringify(plan.shoppingList),
    prepSchedule: JSON.stringify(plan.prepSchedule),

    // Nutrição
    totalKcal: plan.totalKcal ? Math.round(plan.totalKcal) : undefined,
    avgKcalPerServing: plan.avgKcalPerServing
      ? Math.round(plan.avgKcalPerServing)
      : undefined,

    // Configuração do usuário / preferências
    dietType: resolvedDietType,
    mode: input.objective || "normal",
    skillLevel: resolvedSkillLevel,
    allowNewIngredients: input.allowNewIngredients ?? true,
    maxKcalPerServing: input.calorieLimit ?? undefined,

    // Tempo
    availableTime: plan.availableTime ?? input.availableTime ?? undefined,
    totalPlanTime: plan.totalPlanTime,
    timeFits: plan.timeFits,

    // Variedades / porções
    requestedVarieties: input.varieties,
    requestedServings: input.servings,

    // Ajustes do motor (inclui "Ajustes por estoque: ...")
    adjustmentReason: plan.adjustmentReason,
  });

  return {
    id: planId,
    sessionId,
    ...plan,
  };
}
