/**
 * Plan sharing service
 * Handles generation and access of shared meal plans
 */

import { eq } from "drizzle-orm";
import { getDb } from "./db";
import { plans, sessions } from "../drizzle/schema";
import { randomBytes } from "crypto";

/**
 * Generate a unique share token for a plan
 */
export function generateShareToken(): string {
  return randomBytes(32).toString("hex");
}

/**
 * Generate a share link for a plan
 * Returns the share token
 */
export async function generateShareLink(planId: number, userId: number): Promise<string> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Verify plan belongs to user
  const [plan] = await db
    .select({ id: plans.id, sessionId: plans.sessionId, shareToken: plans.shareToken })
    .from(plans)
    .where(eq(plans.id, planId))
    .limit(1);

  if (!plan) {
    throw new Error("Plano não encontrado");
  }

  // Verify ownership
  const [session] = await db
    .select({ userId: sessions.userId })
    .from(sessions)
    .where(eq(sessions.id, plan.sessionId))
    .limit(1);

  if (!session || session.userId !== userId) {
    throw new Error("Você não tem permissão para compartilhar este plano");
  }

  // If already has a share token, return it
  if (plan.shareToken) {
    return plan.shareToken;
  }

  // Generate new token
  const token = generateShareToken();

  // Update plan with token
  await db.update(plans).set({ shareToken: token }).where(eq(plans.id, planId));

  return token;
}

/**
 * Get a shared plan by token (public access)
 * Increments share count
 */
export async function getSharedPlan(token: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // PATCH 8.4.1: Importar helpers do drizzle
  const { and, isNull } = await import("drizzle-orm");

  // Find plan by token (PATCH 8.4.1: excluir planos deletados)
  const [plan] = await db
    .select()
    .from(plans)
    .where(
      and(
        eq(plans.shareToken, token),
        isNull(plans.deletedAt) // PATCH 8.4.1: Não retornar planos deletados
      )
    )
    .limit(1);

  // PATCH 8.5.0: Retornar null em vez de throw Error (deixa router decidir o erro)
  if (!plan) {
    return null;
  }

  // Increment share count
  await db
    .update(plans)
    .set({ shareCount: (plan.shareCount || 0) + 1 })
    .where(eq(plans.id, plan.id));

  // PATCH 8.4.0: Retornar apenas o necessário para renderizar (sem PII)
  return {
    id: plan.id,
    dishes: plan.dishes,
    shoppingList: plan.shoppingList,
    prepSchedule: plan.prepSchedule,
    totalKcal: plan.totalKcal,
    avgKcalPerServing: plan.avgKcalPerServing,
    dietType: plan.dietType,
    mode: plan.mode,
    skillLevel: plan.skillLevel,
    totalPlanTime: plan.totalPlanTime,
    requestedVarieties: plan.requestedVarieties,
    requestedServings: plan.requestedServings,
    // Não expor: sessionId, userId, email, subscriptionTier, shareToken, etc.
  };
}

/**
 * Revoke share link (delete token)
 */
export async function revokeShareLink(planId: number, userId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Verify ownership
  const [plan] = await db
    .select({ sessionId: plans.sessionId })
    .from(plans)
    .where(eq(plans.id, planId))
    .limit(1);

  if (!plan) {
    throw new Error("Plano não encontrado");
  }

  const [session] = await db
    .select({ userId: sessions.userId })
    .from(sessions)
    .where(eq(sessions.id, plan.sessionId))
    .limit(1);

  if (!session || session.userId !== userId) {
    throw new Error("Você não tem permissão para revogar este link");
  }

  // Remove token
  await db.update(plans).set({ shareToken: null, shareCount: 0 }).where(eq(plans.id, planId));
}

