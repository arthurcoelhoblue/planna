/**
 * PATCH 9.3.0 - Shopping List Export
 * 
 * Helper para exportar lista de compras em CSV ou XLSX.
 * Usado pelo endpoint tRPC shoppingListExport.export.
 */

import * as XLSX from "xlsx";

export type ShoppingListItem = {
  name: string;
  quantity: number | null;
  unit: string | null;
  category?: string | null;
};

export type ShoppingListExportFormat = "csv" | "xlsx";

type ExportResult = {
  fileName: string;
  mimeType: string;
  buffer: Buffer;
};

/**
 * Gera slug simples para nomes de arquivo
 */
function slugify(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // Remove acentos
    .replace(/[^a-z0-9]+/g, "-") // Substitui não-alfanuméricos por hífen
    .replace(/^-+|-+$/g, ""); // Remove hífens no início/fim
}

/**
 * Escapa caracteres especiais para CSV (;, ", \n)
 */
function escapeCsv(value: string | number): string {
  const str = String(value);
  
  // Se contém ponto-e-vírgula, aspas ou quebra de linha, envolve em aspas
  if (str.includes(";") || str.includes('"') || str.includes("\n")) {
    // Escapa aspas duplicando-as
    return `"${str.replace(/"/g, '""')}"`;
  }
  
  return str;
}

/**
 * Exporta lista de compras em CSV ou XLSX
 */
export function exportShoppingList(
  items: ShoppingListItem[],
  format: ShoppingListExportFormat,
  opts: { planId: number; createdAt?: Date; dietType?: string | null }
): ExportResult {
  const { planId, createdAt, dietType } = opts;

  const safeItems = items ?? [];

  // Gera nome base do arquivo
  const baseFileName = (() => {
    const datePart = createdAt
      ? createdAt.toISOString().slice(0, 10)
      : "plano";
    const dietPart = dietType ? `-${slugify(dietType)}` : "";
    return `planna-lista-compras-${datePart}-p${planId}${dietPart}`;
  })();

  // Converte items para formato de tabela
  const rows = safeItems.map((item) => ({
    Ingrediente: item.name,
    Quantidade: item.quantity ?? "",
    Unidade: item.unit ?? "",
    Categoria: item.category ?? "",
  }));

  if (format === "csv") {
    // Gera CSV com separador ponto-e-vírgula (padrão brasileiro)
    const header = "Ingrediente;Quantidade;Unidade;Categoria";
    const lines = rows.map(
      (r) =>
        `${escapeCsv(r.Ingrediente)};${escapeCsv(r.Quantidade)};${escapeCsv(
          r.Unidade
        )};${escapeCsv(r.Categoria)}`
    );
    const csv = [header, ...lines].join("\n");
    
    return {
      fileName: `${baseFileName}.csv`,
      mimeType: "text/csv",
      buffer: Buffer.from(csv, "utf-8"),
    };
  }

  // XLSX – usando lib 'xlsx'
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Lista de compras");
  const xlsxBuffer: Buffer = XLSX.write(workbook, {
    type: "buffer",
    bookType: "xlsx",
  });

  return {
    fileName: `${baseFileName}.xlsx`,
    mimeType:
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    buffer: xlsxBuffer,
  };
}
