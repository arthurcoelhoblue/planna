/**
 * PATCH 9.3.0 - Shopping List Export Tests
 * 
 * Testes unitários para o helper de exportação CSV/XLSX.
 */

import { describe, it, expect } from "vitest";
import { exportShoppingList, type ShoppingListItem } from "./shoppingList-export";
import * as XLSX from "xlsx";

describe("exportShoppingList", () => {
  const sampleItems: ShoppingListItem[] = [
    { name: "Frango", quantity: 1, unit: "kg", category: "Carnes" },
    { name: "Arroz", quantity: 500, unit: "g", category: "Grãos" },
    { name: "Tomate", quantity: 3, unit: "unidades", category: "Hortifruti" },
  ];

  const opts = {
    planId: 123,
    createdAt: new Date("2025-01-15T10:00:00Z"),
    dietType: "Low Carb",
  };

  describe("CSV Export", () => {
    it("deve gerar CSV com cabeçalho correto", () => {
      const result = exportShoppingList(sampleItems, "csv", opts);

      expect(result.mimeType).toBe("text/csv");
      expect(result.fileName).toMatch(/planna-lista-compras-2025-01-15-p123-low-carb\.csv/);

      const csv = result.buffer.toString("utf-8");
      expect(csv).toContain("Ingrediente;Quantidade;Unidade;Categoria");
    });

    it("deve escapar caracteres especiais (ponto-e-vírgula, aspas, quebras de linha)", () => {
      const itemsWithSpecialChars: ShoppingListItem[] = [
        { name: 'Queijo "Minas"', quantity: 200, unit: "g", category: "Laticínios" },
        { name: "Molho; especial", quantity: 1, unit: "unidade", category: "Condimentos" },
        { name: "Item\ncom quebra", quantity: 1, unit: "unidade", category: "Outros" },
      ];

      const result = exportShoppingList(itemsWithSpecialChars, "csv", opts);
      const csv = result.buffer.toString("utf-8");

      // Aspas devem ser duplicadas e o campo envolto em aspas
      expect(csv).toContain('"Queijo ""Minas"""');
      // Ponto-e-vírgula deve envolver em aspas
      expect(csv).toContain('"Molho; especial"');
      // Quebra de linha deve envolver em aspas
      expect(csv).toContain('"Item\ncom quebra"');
    });

    it("deve gerar CSV válido com múltiplas linhas", () => {
      const result = exportShoppingList(sampleItems, "csv", opts);
      const csv = result.buffer.toString("utf-8");
      const lines = csv.split("\n");

      // Header + 3 items
      expect(lines.length).toBe(4);
      expect(lines[0]).toBe("Ingrediente;Quantidade;Unidade;Categoria");
      expect(lines[1]).toBe("Frango;1;kg;Carnes");
      expect(lines[2]).toBe("Arroz;500;g;Grãos");
      expect(lines[3]).toBe("Tomate;3;unidades;Hortifruti");
    });

    it("deve gerar CSV vazio (só header) quando lista está vazia", () => {
      const result = exportShoppingList([], "csv", opts);
      const csv = result.buffer.toString("utf-8");

      expect(csv).toBe("Ingrediente;Quantidade;Unidade;Categoria");
    });
  });

  describe("XLSX Export", () => {
    it("deve gerar XLSX com aba 'Lista de compras' e colunas corretas", () => {
      const result = exportShoppingList(sampleItems, "xlsx", opts);

      expect(result.mimeType).toBe(
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      );
      expect(result.fileName).toMatch(/planna-lista-compras-2025-01-15-p123-low-carb\.xlsx/);

      // Parse XLSX
      const workbook = XLSX.read(result.buffer, { type: "buffer" });
      expect(workbook.SheetNames).toContain("Lista de compras");

      const worksheet = workbook.Sheets["Lista de compras"];
      const data = XLSX.utils.sheet_to_json(worksheet);

      expect(data).toHaveLength(3);
      expect(data[0]).toMatchObject({
        Ingrediente: "Frango",
        Quantidade: 1,
        Unidade: "kg",
        Categoria: "Carnes",
      });
    });

    it("deve gerar XLSX válido com múltiplas linhas", () => {
      const result = exportShoppingList(sampleItems, "xlsx", opts);
      const workbook = XLSX.read(result.buffer, { type: "buffer" });
      const worksheet = workbook.Sheets["Lista de compras"];
      const data = XLSX.utils.sheet_to_json(worksheet);

      expect(data).toHaveLength(3);
    });

    it("deve gerar XLSX vazio quando lista está vazia", () => {
      const result = exportShoppingList([], "xlsx", opts);
      const workbook = XLSX.read(result.buffer, { type: "buffer" });
      const worksheet = workbook.Sheets["Lista de compras"];
      const data = XLSX.utils.sheet_to_json(worksheet);

      expect(data).toHaveLength(0);
    });
  });

  describe("Filename Generation", () => {
    it("deve incluir data, planId e dietType no nome do arquivo", () => {
      const result = exportShoppingList(sampleItems, "csv", opts);

      expect(result.fileName).toMatch(/planna-lista-compras-2025-01-15-p123-low-carb\.csv/);
    });

    it("deve gerar nome sem dietType quando não fornecido", () => {
      const result = exportShoppingList(sampleItems, "csv", {
        planId: 456,
        createdAt: new Date("2025-02-20T10:00:00Z"),
        dietType: null,
      });

      expect(result.fileName).toBe("planna-lista-compras-2025-02-20-p456.csv");
    });

    it("deve gerar nome com 'plano' quando createdAt não fornecido", () => {
      const result = exportShoppingList(sampleItems, "csv", {
        planId: 789,
        createdAt: undefined,
        dietType: null,
      });

      expect(result.fileName).toBe("planna-lista-compras-plano-p789.csv");
    });
  });

  describe("Edge Cases", () => {
    it("deve lidar com valores null/undefined em quantity, unit, category", () => {
      const itemsWithNulls: ShoppingListItem[] = [
        { name: "Item 1", quantity: null, unit: null, category: null },
        { name: "Item 2", quantity: 100, unit: "g", category: undefined },
      ];

      const result = exportShoppingList(itemsWithNulls, "csv", opts);
      const csv = result.buffer.toString("utf-8");

      // Valores null/undefined devem ser substituídos por string vazia
      expect(csv).toContain("Item 1;;;");
      expect(csv).toContain("Item 2;100;g;");
    });

    it("deve lidar com lista muito grande (stress test)", () => {
      const largeList: ShoppingListItem[] = Array.from({ length: 1000 }, (_, i) => ({
        name: `Item ${i}`,
        quantity: i,
        unit: "kg",
        category: `Categoria ${i % 10}`,
      }));

      const result = exportShoppingList(largeList, "xlsx", opts);

      expect(result.buffer.length).toBeGreaterThan(0);

      const workbook = XLSX.read(result.buffer, { type: "buffer" });
      const worksheet = workbook.Sheets["Lista de compras"];
      const data = XLSX.utils.sheet_to_json(worksheet);

      expect(data).toHaveLength(1000);
    });
  });
});
