/**
 * PATCH 8.8.0 - Regeneration Gates Tests
 * 
 * Testes para validar gates de regeneração por tier
 */

import { describe, it, expect } from "vitest";
import { canAccessFeature, type SubscriptionTier } from "../shared/tier-limits";

describe("Regeneration Gates", () => {
  describe("regenerateDish", () => {
    it("free não pode regenerar pratos", () => {
      const tier: SubscriptionTier = "free";
      const canRegenerate = canAccessFeature(tier, "allowRegenerateDish");
      
      expect(canRegenerate).toBe(false);
    });

    it("pro pode regenerar pratos", () => {
      const tier: SubscriptionTier = "pro";
      const canRegenerate = canAccessFeature(tier, "allowRegenerateDish");
      
      expect(canRegenerate).toBe(true);
    });

    it("premium pode regenerar pratos", () => {
      const tier: SubscriptionTier = "premium";
      const canRegenerate = canAccessFeature(tier, "allowRegenerateDish");
      
      expect(canRegenerate).toBe(true);
    });

    it("vip pode regenerar pratos", () => {
      const tier: SubscriptionTier = "vip";
      const canRegenerate = canAccessFeature(tier, "allowRegenerateDish");
      
      expect(canRegenerate).toBe(true);
    });
  });

  describe("regenerateShoppingList", () => {
    it("free não pode regenerar lista de compras", () => {
      const tier: SubscriptionTier = "free";
      const canRegenerate = canAccessFeature(tier, "allowRegenerateList");
      
      expect(canRegenerate).toBe(false);
    });

    it("pro pode regenerar lista de compras", () => {
      const tier: SubscriptionTier = "pro";
      const canRegenerate = canAccessFeature(tier, "allowRegenerateList");
      
      expect(canRegenerate).toBe(true);
    });

    it("premium pode regenerar lista de compras", () => {
      const tier: SubscriptionTier = "premium";
      const canRegenerate = canAccessFeature(tier, "allowRegenerateList");
      
      expect(canRegenerate).toBe(true);
    });

    it("vip pode regenerar lista de compras", () => {
      const tier: SubscriptionTier = "vip";
      const canRegenerate = canAccessFeature(tier, "allowRegenerateList");
      
      expect(canRegenerate).toBe(true);
    });
  });

  describe("Mensagens de erro", () => {
    it("deve ter mensagem amigável para regenerateDish bloqueado", () => {
      const tier: SubscriptionTier = "free";
      const canRegenerate = canAccessFeature(tier, "allowRegenerateDish");
      
      if (!canRegenerate) {
        const errorMessage = "Seu plano atual não permite regenerar pratos. Faça upgrade para liberar este recurso.";
        expect(errorMessage).toContain("Faça upgrade");
        expect(errorMessage).toContain("regenerar pratos");
      }
    });

    it("deve ter mensagem amigável para regenerateList bloqueado", () => {
      const tier: SubscriptionTier = "free";
      const canRegenerate = canAccessFeature(tier, "allowRegenerateList");
      
      if (!canRegenerate) {
        const errorMessage = "Seu plano atual não permite regenerar a lista de compras. Faça upgrade para liberar este recurso.";
        expect(errorMessage).toContain("Faça upgrade");
        expect(errorMessage).toContain("lista de compras");
      }
    });
  });

  describe("Logging de upgrade opportunities", () => {
    it("deve logar quando free tenta regenerar prato", () => {
      const tier: SubscriptionTier = "free";
      const userId = 123;
      const canRegenerate = canAccessFeature(tier, "allowRegenerateDish");
      
      if (!canRegenerate) {
        const logMessage = `[upgrade-opportunity] user=${userId} reason=feature_locked_regen_dish tier=${tier}`;
        expect(logMessage).toContain("upgrade-opportunity");
        expect(logMessage).toContain("feature_locked_regen_dish");
        expect(logMessage).toContain("tier=free");
      }
    });

    it("deve logar quando free tenta regenerar lista", () => {
      const tier: SubscriptionTier = "free";
      const userId = 123;
      const canRegenerate = canAccessFeature(tier, "allowRegenerateList");
      
      if (!canRegenerate) {
        const logMessage = `[upgrade-opportunity] user=${userId} reason=feature_locked_regen_list tier=${tier}`;
        expect(logMessage).toContain("upgrade-opportunity");
        expect(logMessage).toContain("feature_locked_regen_list");
        expect(logMessage).toContain("tier=free");
      }
    });
  });

  describe("Version History Gate", () => {
    it("free não pode acessar histórico de versões", () => {
      const tier: SubscriptionTier = "free";
      const canAccess = canAccessFeature(tier, "allowVersionHistory");
      
      expect(canAccess).toBe(false);
    });

    it("pro pode acessar histórico de versões", () => {
      const tier: SubscriptionTier = "pro";
      const canAccess = canAccessFeature(tier, "allowVersionHistory");
      
      expect(canAccess).toBe(true);
    });

    it("premium pode acessar histórico de versões", () => {
      const tier: SubscriptionTier = "premium";
      const canAccess = canAccessFeature(tier, "allowVersionHistory");
      
      expect(canAccess).toBe(true);
    });

    it("vip pode acessar histórico de versões", () => {
      const tier: SubscriptionTier = "vip";
      const canAccess = canAccessFeature(tier, "allowVersionHistory");
      
      expect(canAccess).toBe(true);
    });
  });

  describe("Combinação de features", () => {
    it("free não pode acessar nenhuma feature avançada", () => {
      const tier: SubscriptionTier = "free";
      
      expect(canAccessFeature(tier, "allowAdvancedModes")).toBe(false);
      expect(canAccessFeature(tier, "allowRegenerateDish")).toBe(false);
      expect(canAccessFeature(tier, "allowRegenerateList")).toBe(false);
      expect(canAccessFeature(tier, "allowVersionHistory")).toBe(false);
    });

    it("pro pode acessar todas as features avançadas", () => {
      const tier: SubscriptionTier = "pro";
      
      expect(canAccessFeature(tier, "allowAdvancedModes")).toBe(true);
      expect(canAccessFeature(tier, "allowRegenerateDish")).toBe(true);
      expect(canAccessFeature(tier, "allowRegenerateList")).toBe(true);
      expect(canAccessFeature(tier, "allowVersionHistory")).toBe(true);
    });

    it("premium pode acessar todas as features avançadas", () => {
      const tier: SubscriptionTier = "premium";
      
      expect(canAccessFeature(tier, "allowAdvancedModes")).toBe(true);
      expect(canAccessFeature(tier, "allowRegenerateDish")).toBe(true);
      expect(canAccessFeature(tier, "allowRegenerateList")).toBe(true);
      expect(canAccessFeature(tier, "allowVersionHistory")).toBe(true);
    });

    it("vip pode acessar todas as features avançadas", () => {
      const tier: SubscriptionTier = "vip";
      
      expect(canAccessFeature(tier, "allowAdvancedModes")).toBe(true);
      expect(canAccessFeature(tier, "allowRegenerateDish")).toBe(true);
      expect(canAccessFeature(tier, "allowRegenerateList")).toBe(true);
      expect(canAccessFeature(tier, "allowVersionHistory")).toBe(true);
    });
  });
});
