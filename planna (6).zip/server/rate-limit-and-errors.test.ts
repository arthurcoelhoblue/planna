/**
 * PATCH 8.4.1: Testes de rate limit e segurança
 * 
 * Cenários testados:
 * 1. assertRateLimit permite até max requisições
 * 2. Excede limite → TOO_MANY_REQUESTS
 * 3. Depois do tempo, reseta
 * 4. auth.verifyEmailCode propaga rate limit
 * 5. mealPlan.generateAnonymousPlan limitado por anonymousId
 * 6. getSharedPlan não retorna PII
 */

import { describe, it, expect, beforeAll } from "vitest";
import { assertRateLimit } from "./_core/rateLimit";
import { getSharedPlan } from "./share-service";
import { getDb } from "./db";
import { users, sessions, plans } from "../drizzle/schema";

describe("PATCH 8.4.1 - Rate limit e segurança", () => {
  it("1. assertRateLimit permite até max requisições", async () => {
    const key = `test_rate_limit_${Date.now()}`;
    
    // Primeira chamada
    await expect(
      assertRateLimit(key, { windowMs: 1000, max: 2 })
    ).resolves.not.toThrow();

    // Segunda chamada
    await expect(
      assertRateLimit(key, { windowMs: 1000, max: 2 })
    ).resolves.not.toThrow();
  });

  it("2. Excede limite → TOO_MANY_REQUESTS", async () => {
    const key = `test_rate_limit_exceed_${Date.now()}`;
    
    // Primeira e segunda chamada (dentro do limite)
    await assertRateLimit(key, { windowMs: 1000, max: 2 });
    await assertRateLimit(key, { windowMs: 1000, max: 2 });

    // Terceira chamada (excede limite)
    await expect(
      assertRateLimit(key, { windowMs: 1000, max: 2 })
    ).rejects.toThrow();
  });

  it("3. Depois do tempo, reseta", async () => {
    const key = `test_rate_limit_reset_${Date.now()}`;
    
    // Duas chamadas
    await assertRateLimit(key, { windowMs: 500, max: 2 });
    await assertRateLimit(key, { windowMs: 500, max: 2 });

    // Aguardar janela expirar
    await new Promise(resolve => setTimeout(resolve, 600));

    // Deve permitir novamente
    await expect(
      assertRateLimit(key, { windowMs: 500, max: 2 })
    ).resolves.not.toThrow();
  });

  it("4. auth.verifyEmailCode propaga rate limit (simulado)", async () => {
    // Este teste verifica que o rate limit está configurado
    // A implementação real está em routers.ts
    const mockIp = "192.168.1.100";
    const key = `auth:verify:${mockIp}`;
    
    // Simular 5 tentativas (limite)
    for (let i = 0; i < 5; i++) {
      await assertRateLimit(key, { windowMs: 60_000, max: 5 });
    }

    // Sexta tentativa deve falhar
    await expect(
      assertRateLimit(key, { windowMs: 60_000, max: 5 })
    ).rejects.toThrow();
  });

  it("5. mealPlan.generateAnonymousPlan limitado por anonymousId (simulado)", async () => {
    const anonymousId = `test_anon_${Date.now()}`;
    const key = `mealPlan:generateAnon:${anonymousId}`;
    
    // Simular 2 tentativas (limite)
    await assertRateLimit(key, { windowMs: 60_000, max: 2 });
    await assertRateLimit(key, { windowMs: 60_000, max: 2 });

    // Terceira tentativa deve falhar
    await expect(
      assertRateLimit(key, { windowMs: 60_000, max: 2 })
    ).rejects.toThrow();
  });

  it("6. getSharedPlan não retorna PII", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Criar usuário de teste
    const [user] = await db.insert(users).values({
      openId: `test_share_pii_${Date.now()}`,
      name: "Test User PII",
      email: `test_pii_${Date.now()}@test.com`,
      loginMethod: "local",
    }).$returningId();

    // Criar sessão
    const [session] = await db.insert(sessions).values({
      userId: user.id,
      inputText: "Test ingredients",
      servings: 10,
      objective: "normal",
    }).$returningId();

    // Criar plano com shareToken
    const shareToken = `test_token_${Date.now()}`;
    const [plan] = await db.insert(plans).values({
      sessionId: session.id,
      dishes: JSON.stringify([{ name: "Test Dish" }]),
      shoppingList: JSON.stringify([]),
      prepSchedule: JSON.stringify([]),
      shareToken,
    }).$returningId();

    // Buscar plano compartilhado
    const sharedPlan = await getSharedPlan(shareToken);

    // Verificar que PII não está presente
    expect(sharedPlan).toBeDefined();
    expect(sharedPlan.id).toBe(plan.id);
    expect(sharedPlan.dishes).toBeDefined();
    
    // Verificar que campos sensíveis NÃO estão presentes
    expect((sharedPlan as any).sessionId).toBeUndefined();
    expect((sharedPlan as any).userId).toBeUndefined();
    expect((sharedPlan as any).email).toBeUndefined();
    expect((sharedPlan as any).subscriptionTier).toBeUndefined();
    expect((sharedPlan as any).shareToken).toBeUndefined();
  });
});
