import { describe, it, expect } from "vitest";

/**
 * PATCH 7.0.0 - Testes de User Preferences
 * 
 * Valida que o sistema de preferências:
 * 1. Retorna defaults quando usuário não tem preferências
 * 2. Cria novas preferências corretamente
 * 3. Atualiza preferências existentes
 * 4. Serializa/deserializa exclusions corretamente
 * 5. Valida tipos de dados
 */

describe("Defaults de Preferências", () => {
  it("deve validar estrutura de defaults", () => {
    const defaults = {
      mode: "normal",
      servings: 10,
      varieties: 3,
      time: null,
      allowNewIngredients: true,
      exclusions: [],
    };

    expect(defaults.mode).toBe("normal");
    expect(defaults.servings).toBe(10);
    expect(defaults.varieties).toBe(3);
    expect(defaults.time).toBeNull();
    expect(defaults.allowNewIngredients).toBe(true);
    expect(defaults.exclusions).toEqual([]);
  });

  it("deve validar tipos de defaults", () => {
    const defaults = {
      mode: "normal",
      servings: 10,
      varieties: 3,
      time: null,
      allowNewIngredients: true,
      exclusions: [],
    };

    expect(typeof defaults.mode).toBe("string");
    expect(typeof defaults.servings).toBe("number");
    expect(typeof defaults.varieties).toBe("number");
    expect(defaults.time).toBeNull();
    expect(typeof defaults.allowNewIngredients).toBe("boolean");
    expect(Array.isArray(defaults.exclusions)).toBe(true);
  });
});

describe("Validação de Input", () => {
  it("deve validar mode válido", () => {
    const validModes = ["normal", "aproveitamento", "lowcal", "highprotein"];

    validModes.forEach((mode) => {
      expect(typeof mode).toBe("string");
      expect(mode.length).toBeGreaterThan(0);
    });
  });

  it("deve validar servings positivo", () => {
    const validServings = [1, 5, 10, 15, 20];

    validServings.forEach((servings) => {
      expect(servings).toBeGreaterThan(0);
      expect(Number.isInteger(servings)).toBe(true);
    });
  });

  it("deve validar varieties positivo", () => {
    const validVarieties = [1, 2, 3, 4, 5];

    validVarieties.forEach((varieties) => {
      expect(varieties).toBeGreaterThan(0);
      expect(Number.isInteger(varieties)).toBe(true);
    });
  });

  it("deve validar time positivo ou null", () => {
    const validTimes = [null, 30, 60, 90, 120];

    validTimes.forEach((time) => {
      if (time !== null) {
        expect(time).toBeGreaterThan(0);
        expect(Number.isInteger(time)).toBe(true);
      } else {
        expect(time).toBeNull();
      }
    });
  });

  it("deve validar allowNewIngredients boolean", () => {
    const validValues = [true, false];

    validValues.forEach((value) => {
      expect(typeof value).toBe("boolean");
    });
  });

  it("deve validar exclusions array", () => {
    const validExclusions = [
      [],
      ["gluten"],
      ["gluten", "lactose"],
      ["gluten", "lactose", "nuts"],
    ];

    validExclusions.forEach((exclusions) => {
      expect(Array.isArray(exclusions)).toBe(true);
    });
  });
});

describe("Serialização de Exclusions", () => {
  it("deve serializar array para string", () => {
    const exclusions = ["gluten", "lactose"];
    const serialized = JSON.stringify(exclusions);

    expect(typeof serialized).toBe("string");
    expect(serialized).toBe('["gluten","lactose"]');
  });

  it("deve deserializar string para array", () => {
    const serialized = '["gluten","lactose"]';
    const deserialized = JSON.parse(serialized);

    expect(Array.isArray(deserialized)).toBe(true);
    expect(deserialized).toEqual(["gluten", "lactose"]);
  });

  it("deve manter string como string", () => {
    const alreadyString = '["gluten","lactose"]';
    const result = typeof alreadyString === "string" ? alreadyString : JSON.stringify(alreadyString);

    expect(typeof result).toBe("string");
    expect(result).toBe('["gluten","lactose"]');
  });

  it("deve converter array para string se necessário", () => {
    const array = ["gluten", "lactose"];
    const result = typeof array === "string" ? array : JSON.stringify(array);

    expect(typeof result).toBe("string");
    expect(result).toBe('["gluten","lactose"]');
  });
});

describe("Upsert de Preferências", () => {
  it("deve validar criação de novas preferências", () => {
    const newPreferences = {
      userId: 1,
      mode: "normal",
      servings: 10,
      varieties: 3,
      time: null,
      allowNewIngredients: true,
      exclusions: JSON.stringify([]),
    };

    expect(newPreferences.userId).toBe(1);
    expect(newPreferences.mode).toBe("normal");
    expect(newPreferences.servings).toBe(10);
    expect(newPreferences.varieties).toBe(3);
    expect(newPreferences.time).toBeNull();
    expect(newPreferences.allowNewIngredients).toBe(true);
    expect(newPreferences.exclusions).toBe("[]");
  });

  it("deve validar atualização parcial de preferências", () => {
    const existingPreferences = {
      mode: "normal",
      servings: 10,
      varieties: 3,
      time: null,
      allowNewIngredients: true,
      exclusions: "[]",
    };

    const updates = {
      mode: "lowcal",
      servings: 15,
    };

    const updated = {
      ...existingPreferences,
      ...updates,
    };

    expect(updated.mode).toBe("lowcal");
    expect(updated.servings).toBe(15);
    expect(updated.varieties).toBe(3); // Não alterado
    expect(updated.time).toBeNull(); // Não alterado
    expect(updated.allowNewIngredients).toBe(true); // Não alterado
  });

  it("deve validar atualização de time para null", () => {
    const existingPreferences = {
      time: 60,
    };

    const updates = {
      time: null,
    };

    const updated = {
      ...existingPreferences,
      ...updates,
    };

    expect(updated.time).toBeNull();
  });

  it("deve validar atualização de exclusions", () => {
    const existingPreferences = {
      exclusions: "[]",
    };

    const newExclusions = ["gluten", "lactose"];
    const updates = {
      exclusions: JSON.stringify(newExclusions),
    };

    const updated = {
      ...existingPreferences,
      ...updates,
    };

    expect(updated.exclusions).toBe('["gluten","lactose"]');
  });
});

describe("Retorno de Preferências", () => {
  it("deve validar estrutura de retorno de getUserPreferences", () => {
    const preferences = {
      mode: "normal",
      servings: 10,
      varieties: 3,
      time: null,
      allowNewIngredients: true,
      exclusions: [],
    };

    expect(preferences).toHaveProperty("mode");
    expect(preferences).toHaveProperty("servings");
    expect(preferences).toHaveProperty("varieties");
    expect(preferences).toHaveProperty("time");
    expect(preferences).toHaveProperty("allowNewIngredients");
    expect(preferences).toHaveProperty("exclusions");
  });

  it("deve validar fallback para defaults quando preferência não existe", () => {
    const defaults = {
      mode: "normal",
      servings: 10,
      varieties: 3,
      time: null,
      allowNewIngredients: true,
      exclusions: [],
    };

    const preferenceFromDb = null;
    const result = preferenceFromDb ?? defaults;

    expect(result).toEqual(defaults);
  });

  it("deve validar merge de preferências com defaults", () => {
    const defaults = {
      mode: "normal",
      servings: 10,
      varieties: 3,
      time: null,
      allowNewIngredients: true,
      exclusions: [],
    };

    const preferenceFromDb = {
      mode: "lowcal",
      servings: 15,
      varieties: null,
      time: null,
      allowNewIngredients: null,
      exclusions: null,
    };

    const result = {
      mode: preferenceFromDb.mode ?? defaults.mode,
      servings: preferenceFromDb.servings ?? defaults.servings,
      varieties: preferenceFromDb.varieties ?? defaults.varieties,
      time: preferenceFromDb.time ?? defaults.time,
      allowNewIngredients: preferenceFromDb.allowNewIngredients ?? defaults.allowNewIngredients,
      exclusions: preferenceFromDb.exclusions ?? defaults.exclusions,
    };

    expect(result.mode).toBe("lowcal");
    expect(result.servings).toBe(15);
    expect(result.varieties).toBe(3); // Fallback para default
    expect(result.time).toBeNull();
    expect(result.allowNewIngredients).toBe(true); // Fallback para default
    expect(result.exclusions).toEqual([]); // Fallback para default
  });
});

describe("Validação de Input TRPC", () => {
  it("deve validar input de update com todos os campos", () => {
    const input = {
      mode: "lowcal",
      servings: 15,
      varieties: 4,
      time: 90,
      allowNewIngredients: false,
      exclusions: ["gluten", "lactose"],
    };

    expect(typeof input.mode).toBe("string");
    expect(typeof input.servings).toBe("number");
    expect(typeof input.varieties).toBe("number");
    expect(typeof input.time).toBe("number");
    expect(typeof input.allowNewIngredients).toBe("boolean");
    expect(Array.isArray(input.exclusions)).toBe(true);
  });

  it("deve validar input de update com campos opcionais", () => {
    const input = {
      mode: "lowcal",
    };

    expect(input).toHaveProperty("mode");
    expect(input).not.toHaveProperty("servings");
    expect(input).not.toHaveProperty("varieties");
  });

  it("deve validar input de update com time null", () => {
    const input = {
      time: null,
    };

    expect(input.time).toBeNull();
  });
});

describe("Fluxo Completo de Preferências", () => {
  it("deve simular fluxo completo de criação e atualização", () => {
    // 1) Usuário novo não tem preferências
    let preferences = null;

    // 2) Retorna defaults
    const defaults = {
      mode: "normal",
      servings: 10,
      varieties: 3,
      time: null,
      allowNewIngredients: true,
      exclusions: [],
    };

    preferences = preferences ?? defaults;
    expect(preferences).toEqual(defaults);

    // 3) Usuário atualiza algumas preferências
    const updates = {
      mode: "lowcal",
      servings: 15,
      exclusions: ["gluten"],
    };

    preferences = {
      ...preferences,
      ...updates,
    };

    expect(preferences.mode).toBe("lowcal");
    expect(preferences.servings).toBe(15);
    expect(preferences.varieties).toBe(3); // Mantém default
    expect(preferences.exclusions).toEqual(["gluten"]);

    // 4) Usuário atualiza mais preferências
    const moreUpdates = {
      time: 90,
      allowNewIngredients: false,
    };

    preferences = {
      ...preferences,
      ...moreUpdates,
    };

    expect(preferences.time).toBe(90);
    expect(preferences.allowNewIngredients).toBe(false);
    expect(preferences.mode).toBe("lowcal"); // Mantém atualização anterior
  });
});
