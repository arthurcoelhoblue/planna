# PATCH 7.6.0 - Relatório de Implementação

**Tela de Preferências como Fonte Única de Verdade**

---

## Sumário Executivo

O PATCH 7.6.0 transforma a tela de Preferências do Dashboard na **fonte única de edição** de todas as configurações usadas pelo Planner e pelo PlanView. Este patch consolida a experiência do usuário, centralizando em um único local a gestão de modos, parâmetros, dieta, ingredientes evitados e favoritos. O Planner e o PlanView continuam **apenas consumindo** essas preferências, sem se tornarem locais de edição profunda.

**Status:** ✅ **Implementado e testado com sucesso**

**Arquivos modificados:** 3 arquivos principais + 1 arquivo de testes

**Testes:** 26 testes unitários, todos passando

---

## Contexto e Motivação

Antes deste patch, a tela de preferências no Dashboard era incompleta, exibindo apenas 3 campos (dietType, skillLevel, maxKcal) e usando uma mutation diferente (`trpc.dashboard.updatePreferences`). O Planner e o PlanView já consumiam preferences via `trpc.preferences.get`, mas não havia um local centralizado para editar **todos** os campos de forma consistente.

### Problemas Identificados

1. **Fragmentação:** Preferências espalhadas entre Dashboard e Planner
2. **Inconsistência:** Dashboard usava mutation diferente do resto do sistema
3. **Incompletude:** Faltavam campos críticos (mode, servings, varieties, time, allowNewIngredients, exclusions, favorites)
4. **Confusão UX:** Usuário não sabia onde editar cada preferência

### Objetivos do PATCH

1. **Centralização:** Um único local (Dashboard) para editar todas as preferências
2. **Consistência:** Usar `trpc.preferences.update` em todo o sistema
3. **Completude:** Incluir **todos** os campos de preferences em um painel unificado
4. **Clareza UX:** Interface intuitiva com 3 blocos bem definidos
5. **Robustez:** Detecção de mudanças (isDirty), hidratação automática, fallbacks seguros

---

## Arquitetura da Solução

### Fluxo de Dados

```
┌─────────────┐
│  Dashboard  │  ← Fonte Única de Verdade (edição)
│ Preferences │
│    Panel    │
└──────┬──────┘
       │
       │ trpc.preferences.update
       ├─────────────────────────┐
       │                         │
       ▼                         ▼
┌─────────────┐           ┌─────────────┐
│   Planner   │           │  PlanView   │
│  (consumo)  │           │  (consumo)  │
└─────────────┘           └─────────────┘
       │                         │
       │ trpc.preferences.get    │
       └─────────────────────────┘
```

**Princípio:** Dashboard **escreve**, Planner e PlanView **leem**.

---

## Implementação

### 1. Componente PreferencesPanel

**Arquivo:** `client/src/components/preferences/PreferencesPanel.tsx`

**Linhas:** 500+ linhas

**Estrutura:** 3 blocos principais + lógica de hidratação + detecção de mudanças

#### 1.1 Estados Principais

```typescript
// Estados de modo e parâmetros
const [mode, setMode] = useState<PlannerMode>("normal");
const [servings, setServings] = useState<number>(10);
const [varieties, setVarieties] = useState<number>(3);
const [time, setTime] = useState<number | null>(null);
const [allowNewIngredients, setAllowNewIngredients] = useState<boolean>(true);

// Estados de dieta e perfil
const [dietType, setDietType] = useState<string>("");
const [maxKcalPerServing, setMaxKcalPerServing] = useState<number | null>(null);
const [skillLevel, setSkillLevel] = useState<"beginner" | "intermediate" | "advanced">("intermediate");

// Estados de ingredientes
const [exclusionsInput, setExclusionsInput] = useState<string>("");
const [favoritesInput, setFavoritesInput] = useState<string>("");
const [exclusions, setExclusions] = useState<string[]>([]);
const [favorites, setFavorites] = useState<string[]>([]);

// Estado de controle
const [initialized, setInitialized] = useState(false);
```

**Total:** 14 estados gerenciados

---

#### 1.2 Hidratação Inicial

**Objetivo:** Carregar preferences do backend e popular todos os campos do formulário.

**Implementação:**

```typescript
useEffect(() => {
  if (!preferences || initialized) return;

  // Hidratar campos simples
  setMode((preferences.mode as PlannerMode) ?? "normal");
  if (typeof preferences.servings === "number") setServings(preferences.servings);
  if (typeof preferences.varieties === "number") setVarieties(preferences.varieties);
  if (typeof preferences.time === "number" || preferences.time === null) setTime(preferences.time);
  if (typeof preferences.allowNewIngredients === "boolean") setAllowNewIngredients(preferences.allowNewIngredients);

  if (preferences.dietType) setDietType(preferences.dietType);
  if (typeof preferences.maxKcalPerServing === "number") setMaxKcalPerServing(preferences.maxKcalPerServing);
  if (preferences.skillLevel) setSkillLevel(preferences.skillLevel as any);

  // Parse exclusions e favorites (podem vir como array ou JSON string)
  if (preferences.exclusions) {
    if (Array.isArray(preferences.exclusions)) {
      setExclusions(preferences.exclusions as string[]);
    } else {
      try {
        const parsed = JSON.parse(preferences.exclusions as any);
        setExclusions(Array.isArray(parsed) ? parsed : []);
      } catch {
        setExclusions([]);
      }
    }
  }

  if (preferences.favorites) {
    if (Array.isArray(preferences.favorites)) {
      setFavorites(preferences.favorites as string[]);
    } else {
      try {
        const parsed = JSON.parse(preferences.favorites as any);
        setFavorites(Array.isArray(parsed) ? parsed : []);
      } catch {
        setFavorites([]);
      }
    }
  }

  setInitialized(true);
}, [preferences, initialized]);
```

**Características:**
- Executa apenas uma vez (flag `initialized`)
- Suporta array direto e JSON string para exclusions/favorites
- Fallback seguro para JSON inválido
- Respeita valores null/undefined

---

#### 1.3 Detecção de Mudanças (isDirty)

**Objetivo:** Habilitar botão "Salvar alterações" apenas quando houver mudanças.

**Implementação:**

```typescript
const isDirty = useMemo(() => {
  if (!preferences) return false;
  
  // Parse preferences.exclusions e preferences.favorites para comparação
  const prefsExclusions = (() => {
    if (!preferences.exclusions) return [];
    if (Array.isArray(preferences.exclusions)) return preferences.exclusions as string[];
    try {
      const parsed = JSON.parse(preferences.exclusions as any);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  })();

  const prefsFavorites = (() => {
    if (!preferences.favorites) return [];
    if (Array.isArray(preferences.favorites)) return preferences.favorites as string[];
    try {
      const parsed = JSON.parse(preferences.favorites as any);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  })();

  return (
    mode !== (preferences.mode as PlannerMode) ||
    servings !== preferences.servings ||
    varieties !== preferences.varieties ||
    (time ?? null) !== (preferences.time ?? null) ||
    allowNewIngredients !== preferences.allowNewIngredients ||
    (dietType || "") !== (preferences.dietType || "") ||
    (maxKcalPerServing ?? null) !== (preferences.maxKcalPerServing ?? null) ||
    skillLevel !== (preferences.skillLevel as any) ||
    JSON.stringify(exclusions) !== JSON.stringify(prefsExclusions) ||
    JSON.stringify(favorites) !== JSON.stringify(prefsFavorites)
  );
}, [preferences, mode, servings, varieties, time, allowNewIngredients, dietType, maxKcalPerServing, skillLevel, exclusions, favorites]);
```

**Características:**
- Usa `useMemo` para evitar recálculo desnecessário
- Compara **todos** os 10 campos de preferences
- Suporta comparação de arrays via `JSON.stringify`
- Normaliza valores null/undefined para comparação consistente

---

### 2. Bloco 1 - Modo e Parâmetros Gerais

**Objetivo:** Permitir seleção de modo de planejamento e ajuste de parâmetros básicos.

#### 2.1 Seleção de Modo

```tsx
<div className="grid grid-cols-2 gap-3">
  {PLANNER_MODES.map((m: PlannerMode) => (
    <button
      key={m}
      type="button"
      onClick={() => setMode(m)}
      className={`p-3 border-2 rounded-lg text-left text-sm transition-all ${
        mode === m ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
      }`}
    >
      <div className="font-semibold">{MODE_LABELS[m]}</div>
      <div className="text-xs text-muted-foreground">
        {MODE_DESCRIPTIONS[m]}
      </div>
    </button>
  ))}
</div>
```

**Modos disponíveis:**
- **Normal:** Plano equilibrado, sem restrições específicas
- **Aproveitamento:** Foca em usar ingredientes que o usuário já tem
- **Low cal:** Foca em reduzir calorias por porção
- **High protein:** Foca em aumentar proteína nas refeições

**UX:** Grid 2x2, botões grandes com label + descrição, estado ativo destacado.

---

#### 2.2 Sliders de Porções e Variedades

```tsx
<div className="grid gap-4 sm:grid-cols-2">
  <div className="space-y-2">
    <label className="text-sm font-medium flex items-center justify-between">
      Porções padrão
      <span className="text-xs text-muted-foreground">{servings} porções</span>
    </label>
    <Slider
      min={4}
      max={30}
      step={1}
      value={[servings]}
      onValueChange={([value]) => setServings(value)}
    />
  </div>

  <div className="space-y-2">
    <label className="text-sm font-medium flex items-center justify-between">
      Variedades de pratos
      <span className="text-xs text-muted-foreground">{varieties} pratos diferentes</span>
    </label>
    <Slider
      min={1}
      max={7}
      step={1}
      value={[varieties]}
      onValueChange={([value]) => setVarieties(value)}
    />
  </div>
</div>
```

**Características:**
- Sliders com feedback visual (valor exibido no label)
- Porções: 4-30 (padrão: 10)
- Variedades: 1-7 (padrão: 3)

---

#### 2.3 Tempo Disponível e Novos Ingredientes

```tsx
<div className="grid gap-4 sm:grid-cols-2">
  <div className="space-y-2">
    <label className="text-sm font-medium">Tempo médio disponível (minutos)</label>
    <Input
      type="number"
      min={0}
      value={time ?? ""}
      onChange={(e) => {
        const v = e.target.value;
        setTime(v === "" ? null : Math.max(0, Number(v)));
      }}
      placeholder="Ex: 90"
    />
    <p className="text-xs text-muted-foreground">
      Esse valor é usado como referência para sugerir planos compatíveis com sua rotina.
    </p>
  </div>

  <div className="space-y-2">
    <label className="text-sm font-medium flex items-center gap-2">
      <span>Permitir novos ingredientes</span>
    </label>
    <div className="flex items-center justify-between rounded-md border px-3 py-2">
      <div className="space-y-1">
        <p className="text-sm">
          {allowNewIngredients ? "Pode sugerir ingredientes novos" : "Usar apenas o que já tem"}
        </p>
        <p className="text-xs text-muted-foreground">
          Se desligar, o Planner tenta ficar restrito ao que você informar no estoque/lista.
        </p>
      </div>
      <Switch
        checked={allowNewIngredients}
        onCheckedChange={setAllowNewIngredients}
      />
    </div>
  </div>
</div>
```

**Características:**
- Tempo: Input numérico, aceita null (vazio)
- Novos ingredientes: Switch com descrição contextual

---

### 3. Bloco 2 - Dieta e Perfil Nutricional

**Objetivo:** Configurar restrições alimentares e nível de habilidade culinária.

#### 3.1 Tipo de Dieta e Limite de Calorias

```tsx
<div className="grid gap-4 sm:grid-cols-2">
  <div className="space-y-2">
    <label className="text-sm font-medium">Tipo de dieta</label>
    <Input
      value={dietType}
      onChange={(e) => setDietType(e.target.value)}
      placeholder="Ex: Mediterrânea, Low carb, Vegetariana..."
    />
    <p className="text-xs text-muted-foreground">
      Campo livre para descrever o estilo de alimentação que você busca.
    </p>
  </div>

  <div className="space-y-2">
    <label className="text-sm font-medium">Limite de kcal por porção</label>
    <Input
      type="number"
      min={0}
      value={maxKcalPerServing ?? ""}
      onChange={(e) => {
        const v = e.target.value;
        setMaxKcalPerServing(v === "" ? null : Math.max(0, Number(v)));
      }}
      placeholder="Ex: 450"
    />
    <p className="text-xs text-muted-foreground">
      Opcional. Se preencher, o Planner tenta respeitar esse limite por porção.
    </p>
  </div>
</div>
```

**Características:**
- Tipo de dieta: Campo livre (string)
- Limite de kcal: Input numérico, aceita null (vazio)

---

#### 3.2 Nível de Habilidade

```tsx
<div className="space-y-2">
  <label className="text-sm font-medium">Seu nível na cozinha</label>
  <div className="flex flex-wrap gap-2">
    {[
      { value: "beginner", label: "Iniciante", desc: "Receitas mais simples, passo a passo detalhado." },
      { value: "intermediate", label: "Intermediário", desc: "Equilíbrio entre praticidade e complexidade." },
      { value: "advanced", label: "Avançado", desc: "Pode usar técnicas mais elaboradas." },
    ].map((opt) => (
      <button
        key={opt.value}
        type="button"
        onClick={() => setSkillLevel(opt.value as any)}
        className={`px-3 py-2 rounded-md border text-left text-sm flex-1 min-w-[150px] ${
          skillLevel === opt.value
            ? "border-primary bg-primary/5"
            : "border-border hover:border-primary/50"
        }`}
      >
        <div className="font-medium">{opt.label}</div>
        <div className="text-xs text-muted-foreground">{opt.desc}</div>
      </button>
    ))}
  </div>
</div>
```

**Níveis:**
- **Iniciante:** Receitas simples, passo a passo detalhado
- **Intermediário:** Equilíbrio entre praticidade e complexidade
- **Avançado:** Técnicas mais elaboradas

**UX:** Botões horizontais com label + descrição, estado ativo destacado.

---

### 4. Bloco 3 - Ingredientes Evitados e Favoritos

**Objetivo:** Gerenciar listas de ingredientes via chip input.

#### 4.1 Helpers de Chip Input

```typescript
function handleAddFromInput(
  input: string,
  list: string[],
  setList: (v: string[]) => void,
  setInput: (v: string) => void
) {
  const parts = input
    .split(/[,\n]/)
    .map((s) => s.trim())
    .filter(Boolean);

  if (!parts.length) return;
  const normalized = Array.from(new Set([...list, ...parts]));
  setList(normalized);
  setInput("");
}

function handleRemoveItem(item: string, list: string[], setList: (v: string[]) => void) {
  setList(list.filter((x) => x !== item));
}
```

**Características:**
- Suporta entrada por **vírgula** e **quebra de linha**
- Remove duplicatas automaticamente (Set)
- Limpa input após adicionar

---

#### 4.2 UI de Ingredientes Evitados

```tsx
<div className="space-y-2">
  <label className="text-sm font-medium">Ingredientes que você quer evitar</label>
  <p className="text-xs text-muted-foreground">
    Ex: lactose, glúten, pimentão... O Planner vai tentar não usar esses ingredientes.
  </p>
  <div className="flex flex-wrap gap-2 mb-2">
    {exclusions.map((item) => (
      <span
        key={item}
        className="inline-flex items-center rounded-full bg-red-100 text-red-800 px-2 py-0.5 text-xs"
      >
        {item}
        <button
          type="button"
          className="ml-1 text-[10px]"
          onClick={() => handleRemoveItem(item, exclusions, setExclusions)}
        >
          ×
        </button>
      </span>
    ))}
    {exclusions.length === 0 && (
      <span className="text-xs text-muted-foreground">
        Nenhum ingrediente evitado cadastrado.
      </span>
    )}
  </div>
  <div className="flex gap-2">
    <Input
      placeholder="Digite e aperte Enter ou vírgula"
      value={exclusionsInput}
      onChange={(e) => setExclusionsInput(e.target.value)}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          handleAddFromInput(exclusionsInput, exclusions, setExclusions, setExclusionsInput);
        }
      }}
    />
    <Button
      type="button"
      variant="outline"
      onClick={() => handleAddFromInput(exclusionsInput, exclusions, setExclusions, setExclusionsInput)}
    >
      Adicionar
    </Button>
  </div>
</div>
```

**Características:**
- Chips vermelhos (`bg-red-100 text-red-800`)
- Botão × para remover
- Input com suporte a Enter
- Botão "Adicionar" alternativo
- Mensagem de fallback quando vazio

---

#### 4.3 UI de Ingredientes Favoritos

```tsx
<div className="space-y-2">
  <label className="text-sm font-medium">Ingredientes favoritos</label>
  <p className="text-xs text-muted-foreground">
    Ex: frango, abacate, grão-de-bico... O Planner tenta priorizar esses ingredientes.
  </p>
  <div className="flex flex-wrap gap-2 mb-2">
    {favorites.map((item) => (
      <span
        key={item}
        className="inline-flex items-center rounded-full bg-amber-100 text-amber-800 px-2 py-0.5 text-xs"
      >
        {item}
        <button
          type="button"
          className="ml-1 text-[10px]"
          onClick={() => handleRemoveItem(item, favorites, setFavorites)}
        >
          ×
        </button>
      </span>
    ))}
    {favorites.length === 0 && (
      <span className="text-xs text-muted-foreground">
        Nenhum favorito cadastrado.
      </span>
    )}
  </div>
  <div className="flex gap-2">
    <Input
      placeholder="Digite e aperte Enter ou vírgula"
      value={favoritesInput}
      onChange={(e) => setFavoritesInput(e.target.value)}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          handleAddFromInput(favoritesInput, favorites, setFavorites, setFavoritesInput);
        }
      }}
    />
    <Button
      type="button"
      variant="outline"
      onClick={() => handleAddFromInput(favoritesInput, favorites, setFavorites, setFavoritesInput)}
    >
      Adicionar
    </Button>
  </div>
</div>
```

**Características:**
- Chips amarelos (`bg-amber-100 text-amber-800`)
- Mesma lógica de exclusions
- Mensagem de fallback quando vazio

---

### 5. Ação de Salvar

**Objetivo:** Persistir mudanças no backend via `trpc.preferences.update`.

#### 5.1 Handler de Salvamento

```typescript
const handleSave = () => {
  updatePreferences.mutate(
    {
      mode,
      servings,
      varieties,
      time, // pode ser null
      allowNewIngredients,
      dietType: dietType || undefined,
      maxKcalPerServing: maxKcalPerServing ?? undefined,
      skillLevel,
      exclusions,
      favorites,
    },
    {
      onSuccess: () => {
        toast.success("Preferências salvas", {
          description: "Suas configurações serão usadas como padrão nos próximos planos.",
        });
      },
      onError: () => {
        toast.error("Erro ao salvar", {
          description: "Tente novamente em alguns instantes.",
        });
      },
    }
  );
};
```

**Características:**
- Envia **todos** os 10 campos
- Converte strings vazias para `undefined`
- Toast de sucesso/erro
- Invalidação automática de cache (tRPC)

---

#### 5.2 Botão de Salvar

```tsx
<div className="mt-6 flex items-center justify-between border-t pt-4">
  <p className="text-xs text-muted-foreground">
    Essas preferências são usadas como padrão no Planner e nos planos gerados.
  </p>
  <Button
    type="button"
    disabled={!isDirty || updatePreferences.isPending}
    onClick={handleSave}
  >
    {updatePreferences.isPending ? "Salvando..." : "Salvar alterações"}
  </Button>
</div>
```

**Características:**
- Desabilitado quando `!isDirty` (sem mudanças)
- Desabilitado quando `isPending` (salvando)
- Texto dinâmico: "Salvando..." vs "Salvar alterações"

---

### 6. Estados de Loading e Erro

**Objetivo:** Feedback visual durante carregamento e em caso de erro.

#### 6.1 Loading State

```tsx
if (isLoading) {
  return (
    <div className="flex items-center justify-center py-12">
      <Loader2 className="w-8 h-8 animate-spin text-primary" />
      <p className="ml-3 text-muted-foreground">Carregando suas preferências...</p>
    </div>
  );
}
```

---

#### 6.2 Error State

```tsx
if (isError) {
  return (
    <div className="text-center py-12">
      <p className="text-destructive">Não foi possível carregar suas preferências agora.</p>
      <p className="text-sm text-muted-foreground mt-2">Tente recarregar a página.</p>
    </div>
  );
}
```

---

### 7. Integração no Dashboard

**Arquivo:** `client/src/pages/Dashboard.tsx`

**Mudanças:**

#### 7.1 Remoção de Código Antigo

**Antes:**
```typescript
// Preferences form
const [dietType, setDietType] = useState("");
const [skillLevel, setSkillLevel] = useState<"beginner" | "intermediate" | "advanced">("intermediate");
const [maxKcal, setMaxKcal] = useState("");

const updatePreferences = trpc.dashboard.updatePreferences.useMutation({
  onSuccess: () => {
    toast.success("Preferências atualizadas com sucesso!");
    utils.dashboard.stats.invalidate();
  },
  onError: (error: any) => {
    toast.error(error.message || "Erro ao atualizar preferências");
  },
});

const handleSavePreferences = () => {
  updatePreferences.mutate({
    dietType: dietType || undefined,
    skillLevel,
    maxKcalPerServing: maxKcal ? parseInt(maxKcal) : undefined,
  });
};
```

**Depois:**
```typescript
// Preferences form - PATCH 7.6.0: Removido, agora usa PreferencesPanel
```

---

#### 7.2 Substituição da Seção de Preferências

**Antes:**
```tsx
<Card>
  <CardHeader>
    <CardTitle>Minhas Preferências</CardTitle>
    <CardDescription>
      Configure suas preferências padrão para facilitar a criação de planos
    </CardDescription>
  </CardHeader>
  <CardContent className="space-y-4">
    <div className="grid gap-4 md:grid-cols-2">
      <div className="space-y-2">
        <Label htmlFor="dietType">Tipo de Dieta</Label>
        <Input
          id="dietType"
          placeholder="Ex: Vegetariana, Vegana, Low Carb"
          value={dietType}
          onChange={(e) => setDietType(e.target.value)}
        />
      </div>
      {/* ... mais 2 campos ... */}
    </div>

    <Button onClick={handleSavePreferences} disabled={updatePreferences.isPending}>
      {updatePreferences.isPending ? "Salvando..." : "Salvar Preferências"}
    </Button>
  </CardContent>
</Card>
```

**Depois:**
```tsx
{/* PATCH 7.6.0: Preferences Section - Fonte Única de Verdade */}
<Card>
  <CardHeader>
    <CardTitle>Minhas preferências no Planner</CardTitle>
    <CardDescription>
      Ajuste como o Planna monta seus planos por padrão.
    </CardDescription>
  </CardHeader>
  <CardContent>
    <PreferencesPanel />
  </CardContent>
</Card>
```

**Resultado:** Código reduzido de ~50 linhas para 10 linhas, toda lógica encapsulada no PreferencesPanel.

---

### 8. Backend - Adição de Campo maxKcalPerServing

**Arquivo:** `server/routers.ts`

**Mudanças:**

#### 8.1 Schema de Input

**Antes:**
```typescript
.input(
  z.object({
    mode: z.string().optional(),
    servings: z.number().int().positive().optional(),
    varieties: z.number().int().positive().optional(),
    time: z.number().int().positive().nullable().optional(),
    allowNewIngredients: z.boolean().optional(),
    exclusions: z.array(z.string()).optional(),
    favorites: z.array(z.string()).optional(),
    skillLevel: z.enum(["beginner", "intermediate", "advanced"]).optional(),
    dietType: z.string().optional(),
  })
)
```

**Depois:**
```typescript
.input(
  z.object({
    mode: z.string().optional(),
    servings: z.number().int().positive().optional(),
    varieties: z.number().int().positive().optional(),
    time: z.number().int().positive().nullable().optional(),
    allowNewIngredients: z.boolean().optional(),
    exclusions: z.array(z.string()).optional(),
    favorites: z.array(z.string()).optional(),
    skillLevel: z.enum(["beginner", "intermediate", "advanced"]).optional(),
    dietType: z.string().optional(),
    maxKcalPerServing: z.number().int().positive().nullable().optional(), // NOVO
  })
)
```

---

#### 8.2 Handling de maxKcalPerServing

**Antes:**
```typescript
if (input.dietType !== undefined) {
  updates.dietType = input.dietType;
}
```

**Depois:**
```typescript
if (input.dietType !== undefined) {
  updates.dietType = input.dietType;
}
if (input.maxKcalPerServing !== undefined) {
  updates.maxKcalPerServing = input.maxKcalPerServing;
}
```

**Resultado:** Campo `maxKcalPerServing` agora é suportado pela mutation `preferences.update`.

---

## Testes de Integração

**Arquivo:** `server/patch-7.6.0-preferences-panel.test.ts`

**Total de testes:** 26 testes unitários

**Resultado:** ✅ **Todos os testes passando**

### Cobertura de Testes

#### 1. Hidratação Inicial (5 testes)

| Teste | Descrição | Status |
|-------|-----------|--------|
| `deve hidratar todos os campos a partir de preferences` | Valida hidratação completa | ✅ |
| `deve hidratar com valores default quando preferences está vazio` | Valida defaults | ✅ |
| `deve parsear exclusions de JSON string para array` | Valida parsing | ✅ |
| `deve parsear favorites de JSON string para array` | Valida parsing | ✅ |
| `deve retornar array vazio quando JSON é inválido` | Valida fallback | ✅ |

---

#### 2. Detecção de Mudanças - isDirty (7 testes)

| Teste | Descrição | Status |
|-------|-----------|--------|
| `deve retornar false quando nenhum campo foi alterado` | Valida estado limpo | ✅ |
| `deve retornar true quando mode foi alterado` | Valida detecção | ✅ |
| `deve retornar true quando servings foi alterado` | Valida detecção | ✅ |
| `deve retornar true quando exclusions foi alterado` | Valida detecção de array | ✅ |
| `deve retornar true quando favorites foi alterado` | Valida detecção de array | ✅ |
| `deve retornar true quando time mudou de null para número` | Valida detecção de null | ✅ |
| `deve retornar true quando maxKcalPerServing mudou de null para número` | Valida detecção de null | ✅ |

---

#### 3. Chip Input - Exclusions e Favorites (7 testes)

| Teste | Descrição | Status |
|-------|-----------|--------|
| `deve adicionar um único item via Enter` | Valida input simples | ✅ |
| `deve adicionar múltiplos itens separados por vírgula` | Valida split por vírgula | ✅ |
| `deve adicionar múltiplos itens separados por quebra de linha` | Valida split por \n | ✅ |
| `deve remover duplicatas ao adicionar` | Valida Set | ✅ |
| `deve remover item ao clicar no botão X` | Valida remoção | ✅ |
| `deve ignorar input vazio` | Valida validação | ✅ |
| `deve ignorar espaços em branco` | Valida trim | ✅ |

---

#### 4. Payload de Salvamento (3 testes)

| Teste | Descrição | Status |
|-------|-----------|--------|
| `deve montar payload completo com todos os campos` | Valida payload | ✅ |
| `deve enviar undefined para campos opcionais vazios` | Valida conversão | ✅ |
| `deve enviar null para time quando vazio` | Valida null | ✅ |

---

#### 5. Fallbacks e Casos Extremos (4 testes)

| Teste | Descrição | Status |
|-------|-----------|--------|
| `deve lidar com preferences null` | Valida fallback | ✅ |
| `deve lidar com exclusions como JSON string vazio` | Valida parsing | ✅ |
| `deve lidar com favorites como array direto` | Valida array nativo | ✅ |
| `deve lidar com skillLevel inválido` | Valida sanitização | ✅ |

---

### Exemplo de Saída de Testes

```
✓ server/patch-7.6.0-preferences-panel.test.ts (26)
  ✓ PATCH 7.6.0 - PreferencesPanel Integration Tests (26)
    ✓ Hidratação Inicial (5)
    ✓ Detecção de Mudanças (isDirty) (7)
    ✓ Chip Input - Exclusions e Favorites (7)
    ✓ Payload de Salvamento (3)
    ✓ Fallbacks e Casos Extremos (4)

Test Files  1 passed (1)
     Tests  26 passed (26)
  Duration  311ms
```

---

## Interação Dashboard ↔ Planner ↔ PlanView

### Fluxo Completo

1. **Usuário acessa Dashboard**
   - PreferencesPanel carrega preferences via `trpc.preferences.get`
   - Hidratação automática de todos os campos
   - Usuário edita campos (mode, servings, exclusions, etc)
   - Botão "Salvar alterações" habilitado (isDirty = true)

2. **Usuário salva preferências**
   - Click em "Salvar alterações"
   - Mutation `trpc.preferences.update` enviada
   - Backend persiste no banco de dados
   - Toast de sucesso exibido
   - Cache do tRPC invalidado

3. **Usuário acessa Planner**
   - Planner carrega preferences via `trpc.preferences.get`
   - Campos pré-preenchidos com valores do Dashboard
   - Seção "Preferências de ingredientes" exibe exclusions/favorites
   - Usuário pode ajustar campos localmente (não salva no Dashboard)
   - Ao gerar plano, usa valores ajustados + preferences

4. **Usuário acessa PlanView**
   - PlanView carrega preferences via `trpc.preferences.get`
   - Card "Parâmetros do Plano" exibe valores aplicados
   - Derivação: plano → preferences → default
   - Exibe exclusions e favorites do usuário

---

### Tabela de Responsabilidades

| Componente | Leitura | Escrita | Ajuste Local | Persistência |
|------------|---------|---------|--------------|--------------|
| **Dashboard** | ✅ | ✅ | ✅ | ✅ |
| **Planner** | ✅ | ❌ | ✅ | ❌ |
| **PlanView** | ✅ | ❌ | ❌ | ❌ |

**Legenda:**
- **Leitura:** Consome preferences via `trpc.preferences.get`
- **Escrita:** Salva preferences via `trpc.preferences.update`
- **Ajuste Local:** Permite edição temporária (não persiste)
- **Persistência:** Salva mudanças no banco de dados

**Princípio:** Dashboard é a **fonte única de verdade** para edição persistente.

---

## Confirmação de Uso do Backend

### Mutation Utilizada

**Antes do PATCH 7.6.0:**
- Dashboard usava `trpc.dashboard.updatePreferences` (mutation customizada, incompleta)

**Depois do PATCH 7.6.0:**
- Dashboard usa `trpc.preferences.update` (mutation padrão, completa)

**Benefícios:**
- **Consistência:** Mesma mutation em todo o sistema
- **Completude:** Suporta **todos** os 10 campos de preferences
- **Manutenibilidade:** Um único ponto de atualização

---

### Campos Suportados

| Campo | Tipo | Antes | Depois |
|-------|------|-------|--------|
| `mode` | string | ❌ | ✅ |
| `servings` | number | ❌ | ✅ |
| `varieties` | number | ❌ | ✅ |
| `time` | number \| null | ❌ | ✅ |
| `allowNewIngredients` | boolean | ❌ | ✅ |
| `dietType` | string | ✅ | ✅ |
| `maxKcalPerServing` | number \| null | ✅ | ✅ |
| `skillLevel` | enum | ✅ | ✅ |
| `exclusions` | string[] | ❌ | ✅ |
| `favorites` | string[] | ❌ | ✅ |

**Resultado:** De 3 campos suportados para **10 campos completos**.

---

## Arquivos Modificados

### 1. `client/src/components/preferences/PreferencesPanel.tsx` (Novo)

**Linhas:** 500+ linhas

**Conteúdo:**
- Componente completo de preferências
- 3 blocos (Modo, Dieta, Ingredientes)
- Lógica de hidratação e isDirty
- Chip input para exclusions/favorites
- Estados de loading/erro

---

### 2. `client/src/pages/Dashboard.tsx`

**Linhas modificadas:** ~60 linhas removidas, ~10 linhas adicionadas

**Mudanças:**
- Removido código antigo de preferências (estados locais + mutation customizada)
- Adicionado import de PreferencesPanel
- Substituída seção de preferências por `<PreferencesPanel />`

---

### 3. `server/routers.ts`

**Linhas modificadas:** 2 linhas adicionadas

**Mudanças:**
- Adicionado campo `maxKcalPerServing` no schema de input
- Adicionado handling de `maxKcalPerServing` na mutation

---

### 4. `server/patch-7.6.0-preferences-panel.test.ts` (Novo)

**Linhas:** 400+ linhas

**Conteúdo:**
- 26 testes unitários
- Cobertura de hidratação, isDirty, chip input, payload, fallbacks

---

## Compatibilidade e Retrocompatibilidade

### Compatibilidade com Dados Existentes

✅ **Totalmente compatível** com preferences existentes:

- Preferences antigas com apenas 3 campos: hidratação com defaults
- Preferences com JSON string: parsing automático
- Preferences com array direto: suportadas nativamente
- Preferences null/undefined: fallback para valores default

---

### Compatibilidade com Patches Anteriores

✅ **Integrado perfeitamente** com patches anteriores:

- **PATCH 7.0.0:** Usa mesma mutation `preferences.update`
- **PATCH 7.1.0:** Usa mesma query `preferences.get`
- **PATCH 7.3.1:** Consome modos via `MODE_LABELS` e `MODE_DESCRIPTIONS`
- **PATCH 7.4.0:** PlanView continua derivando valores de preferences
- **PATCH 7.5.0:** Planner continua exibindo exclusions/favorites

---

## Impacto no Usuário

### Antes do PATCH

**Problemas:**
- Usuário não sabia onde editar mode, servings, varieties, time, allowNewIngredients
- Dashboard tinha apenas 3 campos (dietType, skillLevel, maxKcal)
- Planner exibia preferences mas não permitia edição persistente
- Inconsistência: Dashboard usava mutation diferente

**Experiência:** Confusa e fragmentada

---

### Depois do PATCH

**Benefícios:**
- **Centralização:** Um único local (Dashboard) para editar **todas** as preferências
- **Completude:** 10 campos disponíveis em um painel unificado
- **Clareza:** 3 blocos bem definidos (Modo, Dieta, Ingredientes)
- **Feedback:** Detecção de mudanças (botão desabilitado quando não há mudanças)
- **Consistência:** Mesma mutation em todo o sistema

**Experiência:** Clara, intuitiva e completa

---

## Limitações Conhecidas

### 1. Planner Não Salva Ajustes Locais

**Limitação:** Se o usuário ajustar campos no Planner (ex: mudar servings de 10 para 15), essa mudança **não** é salva nas preferences.

**Justificativa:** Mantém a separação de responsabilidades (Dashboard = edição persistente, Planner = ajuste temporário).

**Mitigação:** Dica no Planner: "Para salvar essas configurações como padrão, edite suas preferências no Dashboard."

---

### 2. PlanView Exibe Preferences Atuais

**Limitação:** Se o usuário alterar suas preferences após criar um plano, o PlanView exibirá as preferences **atuais**, não as que estavam ativas no momento da criação.

**Impacto:** Baixo, pois preferences tendem a ser estáveis.

**Solução futura:** Salvar snapshot de preferences no plano (já implementado parcialmente no PATCH 7.4.0).

---

## Próximos Passos Sugeridos

### 1. Adicionar Tooltips Contextuais

**Objetivo:** Explicar cada campo com mais detalhes.

**Exemplo:**
- Tooltip em "Modo normal": "Plano equilibrado, sem restrições específicas. Ideal para quem quer variedade sem focar em objetivos nutricionais."
- Tooltip em "Porções padrão": "Número de marmitas que você quer preparar por semana. Recomendamos 10-14 porções para uma semana completa."

---

### 2. Adicionar Validação de Campos

**Objetivo:** Prevenir valores inválidos.

**Exemplos:**
- Servings: Mínimo 4, máximo 30
- Varieties: Mínimo 1, máximo 7
- Time: Mínimo 0 (ou null)
- maxKcalPerServing: Mínimo 0 (ou null)

**Implementação:** Adicionar validação no frontend (antes de enviar) e no backend (schema Zod).

---

### 3. Adicionar Histórico de Mudanças

**Objetivo:** Permitir que o usuário veja quando e como suas preferences mudaram.

**Exemplo:**
```
📅 Histórico de mudanças
- 05/12/2024 14:30: Modo alterado de "normal" para "lowcal"
- 05/12/2024 14:32: Limite de kcal alterado de 600 para 450
- 05/12/2024 14:35: Adicionado "glúten" aos ingredientes evitados
```

---

### 4. Adicionar Presets de Preferências

**Objetivo:** Facilitar configuração inicial com templates prontos.

**Exemplos:**
- **Preset "Fitness":** mode=highprotein, maxKcalPerServing=500, skillLevel=intermediate
- **Preset "Vegetariano":** dietType="Vegetariana", exclusions=["carne", "frango", "peixe"]
- **Preset "Low Carb":** dietType="Low carb", maxKcalPerServing=400, mode=lowcal

---

## Conclusão

O PATCH 7.6.0 foi implementado com sucesso, transformando a tela de Preferências do Dashboard na **fonte única de verdade** para todas as configurações do Planner. A implementação seguiu os padrões estabelecidos nos patches anteriores, mantendo consistência técnica e visual.

**Principais conquistas:**
- ✅ Componente PreferencesPanel completo com 3 blocos (500+ linhas)
- ✅ Hidratação automática e detecção de mudanças (isDirty)
- ✅ Chip input robusto para exclusions/favorites (suporta vírgula, Enter, quebra de linha)
- ✅ Integração perfeita no Dashboard (código reduzido de ~50 para 10 linhas)
- ✅ Backend atualizado com suporte a maxKcalPerServing
- ✅ 26 testes unitários, todos passando
- ✅ Compatibilidade total com dados existentes e patches anteriores

**Impacto no usuário:**
- Experiência centralizada e intuitiva
- Todos os 10 campos de preferences em um único local
- Feedback visual claro (isDirty, loading, erro)
- Consistência entre Dashboard, Planner e PlanView
- Redução de confusão sobre onde editar cada preferência

**Fluxo consolidado:**
```
Dashboard (edita) → preferences.update → Banco de Dados
                                              ↓
                                    preferences.get
                                              ↓
                              Planner (lê) + PlanView (lê)
```

---

## Anexos

### A. Tabela de Comparação: Antes vs Depois

| Aspecto | Antes do PATCH | Depois do PATCH |
|---------|----------------|-----------------|
| **Campos editáveis no Dashboard** | 3 campos | 10 campos |
| **Mutation usada** | `dashboard.updatePreferences` | `preferences.update` |
| **Consistência com Planner** | ❌ Mutations diferentes | ✅ Mesma mutation |
| **Suporte a mode** | ❌ | ✅ |
| **Suporte a servings** | ❌ | ✅ |
| **Suporte a varieties** | ❌ | ✅ |
| **Suporte a time** | ❌ | ✅ |
| **Suporte a allowNewIngredients** | ❌ | ✅ |
| **Suporte a exclusions** | ❌ | ✅ |
| **Suporte a favorites** | ❌ | ✅ |
| **Detecção de mudanças (isDirty)** | ❌ | ✅ |
| **Chip input para ingredientes** | ❌ | ✅ |
| **Estados de loading/erro** | ❌ | ✅ |
| **Testes unitários** | 0 | 26 testes |
| **Linhas de código no Dashboard** | ~50 linhas | ~10 linhas |

---

### B. Snippets de Código Completos

#### PreferencesPanel - Hidratação

```typescript
useEffect(() => {
  if (!preferences || initialized) return;

  setMode((preferences.mode as PlannerMode) ?? "normal");
  if (typeof preferences.servings === "number") setServings(preferences.servings);
  if (typeof preferences.varieties === "number") setVarieties(preferences.varieties);
  if (typeof preferences.time === "number" || preferences.time === null) setTime(preferences.time);
  if (typeof preferences.allowNewIngredients === "boolean") setAllowNewIngredients(preferences.allowNewIngredients);

  if (preferences.dietType) setDietType(preferences.dietType);
  if (typeof preferences.maxKcalPerServing === "number") setMaxKcalPerServing(preferences.maxKcalPerServing);
  if (preferences.skillLevel) setSkillLevel(preferences.skillLevel as any);

  // Parse exclusions e favorites
  if (preferences.exclusions) {
    if (Array.isArray(preferences.exclusions)) {
      setExclusions(preferences.exclusions as string[]);
    } else {
      try {
        const parsed = JSON.parse(preferences.exclusions as any);
        setExclusions(Array.isArray(parsed) ? parsed : []);
      } catch {
        setExclusions([]);
      }
    }
  }

  if (preferences.favorites) {
    if (Array.isArray(preferences.favorites)) {
      setFavorites(preferences.favorites as string[]);
    } else {
      try {
        const parsed = JSON.parse(preferences.favorites as any);
        setFavorites(Array.isArray(parsed) ? parsed : []);
      } catch {
        setFavorites([]);
      }
    }
  }

  setInitialized(true);
}, [preferences, initialized]);
```

---

#### PreferencesPanel - isDirty

```typescript
const isDirty = useMemo(() => {
  if (!preferences) return false;
  
  const prefsExclusions = (() => {
    if (!preferences.exclusions) return [];
    if (Array.isArray(preferences.exclusions)) return preferences.exclusions as string[];
    try {
      const parsed = JSON.parse(preferences.exclusions as any);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  })();

  const prefsFavorites = (() => {
    if (!preferences.favorites) return [];
    if (Array.isArray(preferences.favorites)) return preferences.favorites as string[];
    try {
      const parsed = JSON.parse(preferences.favorites as any);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  })();

  return (
    mode !== (preferences.mode as PlannerMode) ||
    servings !== preferences.servings ||
    varieties !== preferences.varieties ||
    (time ?? null) !== (preferences.time ?? null) ||
    allowNewIngredients !== preferences.allowNewIngredients ||
    (dietType || "") !== (preferences.dietType || "") ||
    (maxKcalPerServing ?? null) !== (preferences.maxKcalPerServing ?? null) ||
    skillLevel !== (preferences.skillLevel as any) ||
    JSON.stringify(exclusions) !== JSON.stringify(prefsExclusions) ||
    JSON.stringify(favorites) !== JSON.stringify(prefsFavorites)
  );
}, [preferences, mode, servings, varieties, time, allowNewIngredients, dietType, maxKcalPerServing, skillLevel, exclusions, favorites]);
```

---

#### PreferencesPanel - Chip Input Helpers

```typescript
function handleAddFromInput(
  input: string,
  list: string[],
  setList: (v: string[]) => void,
  setInput: (v: string) => void
) {
  const parts = input
    .split(/[,\n]/)
    .map((s) => s.trim())
    .filter(Boolean);

  if (!parts.length) return;
  const normalized = Array.from(new Set([...list, ...parts]));
  setList(normalized);
  setInput("");
}

function handleRemoveItem(item: string, list: string[], setList: (v: string[]) => void) {
  setList(list.filter((x) => x !== item));
}
```

---

#### Dashboard - Integração

```tsx
import { PreferencesPanel } from "@/components/preferences/PreferencesPanel";

// ...

{/* PATCH 7.6.0: Preferences Section - Fonte Única de Verdade */}
<Card>
  <CardHeader>
    <CardTitle>Minhas preferências no Planner</CardTitle>
    <CardDescription>
      Ajuste como o Planna monta seus planos por padrão.
    </CardDescription>
  </CardHeader>
  <CardContent>
    <PreferencesPanel />
  </CardContent>
</Card>
```

---

**Autor:** Manus AI  
**Data:** 05 de dezembro de 2025  
**Versão:** 1.0  
**Status:** ✅ Implementado e testado
