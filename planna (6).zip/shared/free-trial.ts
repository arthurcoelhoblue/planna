// PATCH 8.7.0: Limites do plano anônimo (sem login)

import type { PlannerMode } from "./modes";

export const ANONYMOUS_LIMITS = {
  maxServings: 10,      // até 10 porções
  maxVarieties: 3,      // até 3 pratos diferentes
  allowedModes: ["normal"] as PlannerMode[], // só modo normal
  allowAdvancedSophistication: false,        // sem "gourmet"
};
