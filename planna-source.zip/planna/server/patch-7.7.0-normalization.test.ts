/**
 * PATCH 7.7.0 - Testes de Normalização de Preferences
 * 
 * Valida o helper normalizeStringArrayField e a integração completa
 * de normalização no backend + ChipInput no frontend.
 */

import { describe, it, expect } from "vitest";

describe("PATCH 7.7.0 - Normalização de Preferences", () => {
  
  /**
   * Helper normalizeStringArrayField (simulado para testes)
   */
  function normalizeStringArrayField(raw: unknown): string[] {
    if (!raw) return [];
    
    if (Array.isArray(raw)) {
      return raw.map((x) => String(x).trim()).filter(Boolean);
    }
    
    if (typeof raw === "string") {
      try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          return parsed.map((x) => String(x).trim()).filter(Boolean);
        }
        // Fallback: string simples separada por vírgula/quebra de linha
        return raw
          .split(/[,\n]/)
          .map((s) => s.trim())
          .filter(Boolean);
      } catch {
        // JSON inválido → tentar quebrar por vírgula/quebra de linha como fallback
        return raw
          .split(/[,\n]/)
          .map((s) => s.trim())
          .filter(Boolean);
      }
    }
    
    return [];
  }

  describe("normalizeStringArrayField - Array Direto", () => {
    it("deve retornar array direto sem modificações", () => {
      const input = ["leite", "glúten", "amendoim"];
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve fazer trim em itens do array", () => {
      const input = ["  leite  ", "  glúten  ", "  amendoim  "];
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve filtrar itens vazios do array", () => {
      const input = ["leite", "", "glúten", "   ", "amendoim"];
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve converter números para strings", () => {
      const input = [1, 2, 3];
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["1", "2", "3"]);
    });
  });

  describe("normalizeStringArrayField - JSON String", () => {
    it("deve parsear JSON string válido", () => {
      const input = '["leite", "glúten", "amendoim"]';
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve parsear JSON string com espaços", () => {
      const input = '["  leite  ", "  glúten  "]';
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["leite", "glúten"]);
    });

    it("deve parsear JSON string vazio", () => {
      const input = '[]';
      const result = normalizeStringArrayField(input);
      expect(result).toEqual([]);
    });

    it("deve parsear JSON string com números", () => {
      const input = '[1, 2, 3]';
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["1", "2", "3"]);
    });
  });

  describe("normalizeStringArrayField - String Separada por Vírgula", () => {
    it("deve quebrar string por vírgula", () => {
      const input = "leite, glúten, amendoim";
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve fazer trim em itens separados por vírgula", () => {
      const input = "  leite  ,  glúten  ,  amendoim  ";
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve filtrar itens vazios separados por vírgula", () => {
      const input = "leite, , glúten, , amendoim";
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve lidar com string sem vírgulas", () => {
      const input = "leite";
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["leite"]);
    });
  });

  describe("normalizeStringArrayField - String Separada por Quebra de Linha", () => {
    it("deve quebrar string por quebra de linha", () => {
      const input = "leite\nglúten\namendoim";
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve fazer trim em itens separados por quebra de linha", () => {
      const input = "  leite  \n  glúten  \n  amendoim  ";
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve filtrar linhas vazias", () => {
      const input = "leite\n\nglúten\n\namendoim";
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });
  });

  describe("normalizeStringArrayField - Fallbacks", () => {
    it("deve retornar array vazio para null", () => {
      const input = null;
      const result = normalizeStringArrayField(input);
      expect(result).toEqual([]);
    });

    it("deve retornar array vazio para undefined", () => {
      const input = undefined;
      const result = normalizeStringArrayField(input);
      expect(result).toEqual([]);
    });

    it("deve retornar array vazio para string vazia", () => {
      const input = "";
      const result = normalizeStringArrayField(input);
      expect(result).toEqual([]);
    });

    it("deve retornar array vazio para objeto não-array", () => {
      const input = { key: "value" };
      const result = normalizeStringArrayField(input);
      expect(result).toEqual([]);
    });

    it("deve usar fallback de vírgula para JSON inválido", () => {
      const input = "leite, glúten, invalid json";
      const result = normalizeStringArrayField(input);
      expect(result).toEqual(["leite", "glúten", "invalid json"]);
    });
  });

  describe("Integração - getUserPreferences", () => {
    it("deve normalizar exclusions de JSON string", () => {
      const dbPreferences = {
        exclusions: '["leite", "glúten"]',
        favorites: '["frango", "arroz"]',
      };

      const exclusions = normalizeStringArrayField(dbPreferences.exclusions);
      const favorites = normalizeStringArrayField(dbPreferences.favorites);

      expect(exclusions).toEqual(["leite", "glúten"]);
      expect(favorites).toEqual(["frango", "arroz"]);
    });

    it("deve normalizar exclusions de array direto", () => {
      const dbPreferences = {
        exclusions: ["leite", "glúten"],
        favorites: ["frango", "arroz"],
      };

      const exclusions = normalizeStringArrayField(dbPreferences.exclusions);
      const favorites = normalizeStringArrayField(dbPreferences.favorites);

      expect(exclusions).toEqual(["leite", "glúten"]);
      expect(favorites).toEqual(["frango", "arroz"]);
    });

    it("deve normalizar exclusions de string separada por vírgula", () => {
      const dbPreferences = {
        exclusions: "leite, glúten, amendoim",
        favorites: "frango, arroz, brócolis",
      };

      const exclusions = normalizeStringArrayField(dbPreferences.exclusions);
      const favorites = normalizeStringArrayField(dbPreferences.favorites);

      expect(exclusions).toEqual(["leite", "glúten", "amendoim"]);
      expect(favorites).toEqual(["frango", "arroz", "brócolis"]);
    });

    it("deve retornar arrays vazios para preferences null", () => {
      const dbPreferences = {
        exclusions: null,
        favorites: null,
      };

      const exclusions = normalizeStringArrayField(dbPreferences.exclusions);
      const favorites = normalizeStringArrayField(dbPreferences.favorites);

      expect(exclusions).toEqual([]);
      expect(favorites).toEqual([]);
    });
  });

  describe("ChipInput - Lógica de Add/Remove", () => {
    function addFromInput(input: string, list: string[]): string[] {
      const parts = input
        .split(/[,\n]/)
        .map((s) => s.trim())
        .filter(Boolean);

      if (!parts.length) return list;
      return Array.from(new Set([...list, ...parts].map((s) => s.trim()).filter(Boolean)));
    }

    function removeItem(item: string, list: string[]): string[] {
      return list.filter((x) => x !== item);
    }

    it("deve adicionar item via Enter", () => {
      const list = ["leite"];
      const result = addFromInput("glúten", list);
      expect(result).toEqual(["leite", "glúten"]);
    });

    it("deve adicionar múltiplos itens via vírgula", () => {
      const list = ["leite"];
      const result = addFromInput("glúten, amendoim", list);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve adicionar múltiplos itens via quebra de linha", () => {
      const list = ["leite"];
      const result = addFromInput("glúten\namendoim", list);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve remover duplicatas ao adicionar", () => {
      const list = ["leite", "glúten"];
      const result = addFromInput("leite, amendoim", list);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve remover item", () => {
      const list = ["leite", "glúten", "amendoim"];
      const result = removeItem("glúten", list);
      expect(result).toEqual(["leite", "amendoim"]);
    });

    it("deve ignorar input vazio", () => {
      const list = ["leite"];
      const result = addFromInput("", list);
      expect(result).toEqual(["leite"]);
    });

    it("deve fazer trim em itens adicionados", () => {
      const list = ["leite"];
      const result = addFromInput("  glúten  ,  amendoim  ", list);
      expect(result).toEqual(["leite", "glúten", "amendoim"]);
    });
  });

  describe("Sincronização - Invalidate Queries", () => {
    it("deve invalidar preferences.get após salvar no Dashboard", async () => {
      let invalidateCalled = false;

      const mockUtils = {
        preferences: {
          get: {
            invalidate: async () => {
              invalidateCalled = true;
            },
          },
        },
      };

      // Simular onSuccess da mutation
      await mockUtils.preferences.get.invalidate();

      expect(invalidateCalled).toBe(true);
    });

    it("deve invalidar preferences.get após salvar no Planner", async () => {
      let invalidateCalled = false;

      const mockUtils = {
        preferences: {
          get: {
            invalidate: async () => {
              invalidateCalled = true;
            },
          },
        },
      };

      // Simular onSuccess da mutation
      await mockUtils.preferences.get.invalidate();

      expect(invalidateCalled).toBe(true);
    });
  });

  describe("Compatibilidade com Dados Existentes", () => {
    it("deve lidar com preferences antigas (JSON string)", () => {
      const oldPreferences = {
        exclusions: '["leite", "glúten"]',
        favorites: '["frango"]',
      };

      const exclusions = normalizeStringArrayField(oldPreferences.exclusions);
      const favorites = normalizeStringArrayField(oldPreferences.favorites);

      expect(exclusions).toEqual(["leite", "glúten"]);
      expect(favorites).toEqual(["frango"]);
    });

    it("deve lidar com preferences novas (array direto)", () => {
      const newPreferences = {
        exclusions: ["leite", "glúten"],
        favorites: ["frango"],
      };

      const exclusions = normalizeStringArrayField(newPreferences.exclusions);
      const favorites = normalizeStringArrayField(newPreferences.favorites);

      expect(exclusions).toEqual(["leite", "glúten"]);
      expect(favorites).toEqual(["frango"]);
    });

    it("deve lidar com preferences mistas (JSON + array)", () => {
      const mixedPreferences = {
        exclusions: '["leite", "glúten"]',
        favorites: ["frango", "arroz"],
      };

      const exclusions = normalizeStringArrayField(mixedPreferences.exclusions);
      const favorites = normalizeStringArrayField(mixedPreferences.favorites);

      expect(exclusions).toEqual(["leite", "glúten"]);
      expect(favorites).toEqual(["frango", "arroz"]);
    });

    it("deve lidar com preferences vazias", () => {
      const emptyPreferences = {
        exclusions: null,
        favorites: undefined,
      };

      const exclusions = normalizeStringArrayField(emptyPreferences.exclusions);
      const favorites = normalizeStringArrayField(emptyPreferences.favorites);

      expect(exclusions).toEqual([]);
      expect(favorites).toEqual([]);
    });
  });
});
