/**
 * PATCH 7.6.0 - Testes de Integração do PreferencesPanel
 * 
 * Valida toda a lógica de hidratação, detecção de mudanças (isDirty),
 * chip input de exclusions/favorites e salvamento de preferências.
 */

import { describe, it, expect } from "vitest";

describe("PATCH 7.6.0 - PreferencesPanel Integration Tests", () => {
  
  describe("Hidratação Inicial", () => {
    it("deve hidratar todos os campos a partir de preferences", () => {
      const preferences = {
        mode: "lowcal",
        servings: 15,
        varieties: 5,
        time: 120,
        allowNewIngredients: false,
        dietType: "Vegetariana",
        maxKcalPerServing: 500,
        skillLevel: "advanced",
        exclusions: ["leite", "glúten"],
        favorites: ["frango", "arroz"],
      };

      // Simular hidratação
      const mode = preferences.mode;
      const servings = preferences.servings;
      const varieties = preferences.varieties;
      const time = preferences.time;
      const allowNewIngredients = preferences.allowNewIngredients;
      const dietType = preferences.dietType;
      const maxKcalPerServing = preferences.maxKcalPerServing;
      const skillLevel = preferences.skillLevel;
      const exclusions = preferences.exclusions;
      const favorites = preferences.favorites;

      expect(mode).toBe("lowcal");
      expect(servings).toBe(15);
      expect(varieties).toBe(5);
      expect(time).toBe(120);
      expect(allowNewIngredients).toBe(false);
      expect(dietType).toBe("Vegetariana");
      expect(maxKcalPerServing).toBe(500);
      expect(skillLevel).toBe("advanced");
      expect(exclusions).toEqual(["leite", "glúten"]);
      expect(favorites).toEqual(["frango", "arroz"]);
    });

    it("deve hidratar com valores default quando preferences está vazio", () => {
      const preferences = {
        mode: "normal",
        servings: 10,
        varieties: 3,
        time: null,
        allowNewIngredients: true,
        dietType: "",
        maxKcalPerServing: null,
        skillLevel: "intermediate",
        exclusions: [],
        favorites: [],
      };

      expect(preferences.mode).toBe("normal");
      expect(preferences.servings).toBe(10);
      expect(preferences.varieties).toBe(3);
      expect(preferences.time).toBeNull();
      expect(preferences.allowNewIngredients).toBe(true);
      expect(preferences.dietType).toBe("");
      expect(preferences.maxKcalPerServing).toBeNull();
      expect(preferences.skillLevel).toBe("intermediate");
      expect(preferences.exclusions).toEqual([]);
      expect(preferences.favorites).toEqual([]);
    });

    it("deve parsear exclusions de JSON string para array", () => {
      const preferences = {
        exclusions: '["leite", "glúten", "amendoim"]',
      };

      // Simular parsing
      let exclusions: string[] = [];
      if (typeof preferences.exclusions === "string") {
        try {
          const parsed = JSON.parse(preferences.exclusions);
          exclusions = Array.isArray(parsed) ? parsed : [];
        } catch {
          exclusions = [];
        }
      }

      expect(exclusions).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve parsear favorites de JSON string para array", () => {
      const preferences = {
        favorites: '["frango", "arroz", "brócolis"]',
      };

      // Simular parsing
      let favorites: string[] = [];
      if (typeof preferences.favorites === "string") {
        try {
          const parsed = JSON.parse(preferences.favorites);
          favorites = Array.isArray(parsed) ? parsed : [];
        } catch {
          favorites = [];
        }
      }

      expect(favorites).toEqual(["frango", "arroz", "brócolis"]);
    });

    it("deve retornar array vazio quando JSON é inválido", () => {
      const preferences = {
        exclusions: "invalid json",
      };

      // Simular parsing
      let exclusions: string[] = [];
      if (typeof preferences.exclusions === "string") {
        try {
          const parsed = JSON.parse(preferences.exclusions);
          exclusions = Array.isArray(parsed) ? parsed : [];
        } catch {
          exclusions = [];
        }
      }

      expect(exclusions).toEqual([]);
    });
  });

  describe("Detecção de Mudanças (isDirty)", () => {
    it("deve retornar false quando nenhum campo foi alterado", () => {
      const preferences = {
        mode: "normal",
        servings: 10,
        varieties: 3,
        time: null,
        allowNewIngredients: true,
        dietType: "",
        maxKcalPerServing: null,
        skillLevel: "intermediate",
        exclusions: [],
        favorites: [],
      };

      const current = { ...preferences };

      const isDirty =
        current.mode !== preferences.mode ||
        current.servings !== preferences.servings ||
        current.varieties !== preferences.varieties ||
        (current.time ?? null) !== (preferences.time ?? null) ||
        current.allowNewIngredients !== preferences.allowNewIngredients ||
        (current.dietType || "") !== (preferences.dietType || "") ||
        (current.maxKcalPerServing ?? null) !== (preferences.maxKcalPerServing ?? null) ||
        current.skillLevel !== preferences.skillLevel ||
        JSON.stringify(current.exclusions) !== JSON.stringify(preferences.exclusions) ||
        JSON.stringify(current.favorites) !== JSON.stringify(preferences.favorites);

      expect(isDirty).toBe(false);
    });

    it("deve retornar true quando mode foi alterado", () => {
      const preferences = {
        mode: "normal",
        servings: 10,
        varieties: 3,
        time: null,
        allowNewIngredients: true,
        dietType: "",
        maxKcalPerServing: null,
        skillLevel: "intermediate",
        exclusions: [],
        favorites: [],
      };

      const current = { ...preferences, mode: "lowcal" };

      const isDirty = current.mode !== preferences.mode;

      expect(isDirty).toBe(true);
    });

    it("deve retornar true quando servings foi alterado", () => {
      const preferences = { servings: 10 };
      const current = { servings: 15 };

      const isDirty = current.servings !== preferences.servings;

      expect(isDirty).toBe(true);
    });

    it("deve retornar true quando exclusions foi alterado", () => {
      const preferences = { exclusions: ["leite"] };
      const current = { exclusions: ["leite", "glúten"] };

      const isDirty = JSON.stringify(current.exclusions) !== JSON.stringify(preferences.exclusions);

      expect(isDirty).toBe(true);
    });

    it("deve retornar true quando favorites foi alterado", () => {
      const preferences = { favorites: ["frango"] };
      const current = { favorites: ["frango", "arroz"] };

      const isDirty = JSON.stringify(current.favorites) !== JSON.stringify(preferences.favorites);

      expect(isDirty).toBe(true);
    });

    it("deve retornar true quando time mudou de null para número", () => {
      const preferences = { time: null };
      const current = { time: 90 };

      const isDirty = (current.time ?? null) !== (preferences.time ?? null);

      expect(isDirty).toBe(true);
    });

    it("deve retornar true quando maxKcalPerServing mudou de null para número", () => {
      const preferences = { maxKcalPerServing: null };
      const current = { maxKcalPerServing: 450 };

      const isDirty = (current.maxKcalPerServing ?? null) !== (preferences.maxKcalPerServing ?? null);

      expect(isDirty).toBe(true);
    });
  });

  describe("Chip Input - Exclusions e Favorites", () => {
    function handleAddFromInput(
      input: string,
      list: string[],
      setList: (v: string[]) => void
    ) {
      const parts = input
        .split(/[,\n]/)
        .map((s) => s.trim())
        .filter(Boolean);

      if (!parts.length) return;
      const normalized = Array.from(new Set([...list, ...parts]));
      setList(normalized);
    }

    function handleRemoveItem(item: string, list: string[], setList: (v: string[]) => void) {
      setList(list.filter((x) => x !== item));
    }

    it("deve adicionar um único item via Enter", () => {
      let exclusions: string[] = [];
      const setExclusions = (v: string[]) => {
        exclusions = v;
      };

      handleAddFromInput("leite", exclusions, setExclusions);

      expect(exclusions).toEqual(["leite"]);
    });

    it("deve adicionar múltiplos itens separados por vírgula", () => {
      let exclusions: string[] = [];
      const setExclusions = (v: string[]) => {
        exclusions = v;
      };

      handleAddFromInput("leite, glúten, amendoim", exclusions, setExclusions);

      expect(exclusions).toEqual(["leite", "glúten", "amendoim"]);
    });

    it("deve adicionar múltiplos itens separados por quebra de linha", () => {
      let favorites: string[] = [];
      const setFavorites = (v: string[]) => {
        favorites = v;
      };

      handleAddFromInput("frango\narroz\nbrócolis", favorites, setFavorites);

      expect(favorites).toEqual(["frango", "arroz", "brócolis"]);
    });

    it("deve remover duplicatas ao adicionar", () => {
      let exclusions: string[] = ["leite"];
      const setExclusions = (v: string[]) => {
        exclusions = v;
      };

      handleAddFromInput("leite, glúten", exclusions, setExclusions);

      expect(exclusions).toEqual(["leite", "glúten"]);
    });

    it("deve remover item ao clicar no botão X", () => {
      let exclusions: string[] = ["leite", "glúten", "amendoim"];
      const setExclusions = (v: string[]) => {
        exclusions = v;
      };

      handleRemoveItem("glúten", exclusions, setExclusions);

      expect(exclusions).toEqual(["leite", "amendoim"]);
    });

    it("deve ignorar input vazio", () => {
      let exclusions: string[] = ["leite"];
      const setExclusions = (v: string[]) => {
        exclusions = v;
      };

      handleAddFromInput("", exclusions, setExclusions);

      expect(exclusions).toEqual(["leite"]);
    });

    it("deve ignorar espaços em branco", () => {
      let exclusions: string[] = [];
      const setExclusions = (v: string[]) => {
        exclusions = v;
      };

      handleAddFromInput("  leite  ,  glúten  ", exclusions, setExclusions);

      expect(exclusions).toEqual(["leite", "glúten"]);
    });
  });

  describe("Payload de Salvamento", () => {
    it("deve montar payload completo com todos os campos", () => {
      const payload = {
        mode: "lowcal",
        servings: 15,
        varieties: 5,
        time: 120,
        allowNewIngredients: false,
        dietType: "Vegetariana",
        maxKcalPerServing: 500,
        skillLevel: "advanced",
        exclusions: ["leite", "glúten"],
        favorites: ["frango", "arroz"],
      };

      expect(payload.mode).toBe("lowcal");
      expect(payload.servings).toBe(15);
      expect(payload.varieties).toBe(5);
      expect(payload.time).toBe(120);
      expect(payload.allowNewIngredients).toBe(false);
      expect(payload.dietType).toBe("Vegetariana");
      expect(payload.maxKcalPerServing).toBe(500);
      expect(payload.skillLevel).toBe("advanced");
      expect(payload.exclusions).toEqual(["leite", "glúten"]);
      expect(payload.favorites).toEqual(["frango", "arroz"]);
    });

    it("deve enviar undefined para campos opcionais vazios", () => {
      const dietType = "";
      const maxKcalPerServing = null;

      const payload = {
        dietType: dietType || undefined,
        maxKcalPerServing: maxKcalPerServing ?? undefined,
      };

      expect(payload.dietType).toBeUndefined();
      expect(payload.maxKcalPerServing).toBeUndefined();
    });

    it("deve enviar null para time quando vazio", () => {
      const time = null;

      const payload = {
        time,
      };

      expect(payload.time).toBeNull();
    });
  });

  describe("Fallbacks e Casos Extremos", () => {
    it("deve lidar com preferences null", () => {
      const preferences = null;

      const isDirty = !preferences;

      expect(isDirty).toBe(true);
    });

    it("deve lidar com exclusions como JSON string vazio", () => {
      const preferences = {
        exclusions: "[]",
      };

      let exclusions: string[] = [];
      if (typeof preferences.exclusions === "string") {
        try {
          const parsed = JSON.parse(preferences.exclusions);
          exclusions = Array.isArray(parsed) ? parsed : [];
        } catch {
          exclusions = [];
        }
      }

      expect(exclusions).toEqual([]);
    });

    it("deve lidar com favorites como array direto", () => {
      const preferences = {
        favorites: ["frango", "arroz"],
      };

      const favorites = Array.isArray(preferences.favorites)
        ? preferences.favorites
        : [];

      expect(favorites).toEqual(["frango", "arroz"]);
    });

    it("deve lidar com skillLevel inválido (fallback para intermediate)", () => {
      const preferences = {
        skillLevel: "invalid" as any,
      };

      const skillLevel = ["beginner", "intermediate", "advanced"].includes(preferences.skillLevel)
        ? preferences.skillLevel
        : "intermediate";

      expect(skillLevel).toBe("intermediate");
    });
  });
});
