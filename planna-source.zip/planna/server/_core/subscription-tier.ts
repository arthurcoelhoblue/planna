/**
 * Subscription Tier Unification Service
 * PATCH 8.3.0: Consolidates subscription tiers from multiple sources (Stripe + IAP + VIP)
 */

import { getDb } from "../db";
import { mobileSubscriptions } from "../../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";

export type SubscriptionTier = "free" | "pro" | "premium";

/**
 * Tier hierarchy (higher index = higher tier)
 */
const TIER_ORDER: SubscriptionTier[] = ["free", "pro", "premium"];

/**
 * Return the highest tier from multiple sources
 */
function maxTier(...tiers: SubscriptionTier[]): SubscriptionTier {
  let current: SubscriptionTier = "free";
  for (const t of tiers) {
    if (TIER_ORDER.indexOf(t) > TIER_ORDER.indexOf(current)) {
      current = t;
    }
  }
  return current;
}

/**
 * Get user's Stripe subscription tier
 * Reuses existing subscription-service logic
 */
export async function getStripeTier(userId: number): Promise<SubscriptionTier> {
  try {
    const { getUserActiveSubscription } = await import("../subscription-service");
    const subscription = await getUserActiveSubscription(userId);
    
    if (!subscription) {
      return "free";
    }

    // Map subscription status to tier
    if (subscription.status === "active" || subscription.status === "trialing") {
      // Extract tier from subscription metadata or priceId mapping
      // For now, use the user's subscriptionTier field as source of truth
      const { users } = await import("../../drizzle/schema");
      const db = await getDb();
      if (!db) return "free";

      const [user] = await db
        .select({ subscriptionTier: users.subscriptionTier })
        .from(users)
        .where(eq(users.id, userId))
        .limit(1);

      return user?.subscriptionTier || "free";
    }

    return "free";
  } catch (error) {
    console.error("[SubscriptionTier] Error getting Stripe tier:", error);
    return "free";
  }
}

/**
 * Get user's IAP (Apple/Google) subscription tier
 * Returns the highest active tier from mobile subscriptions
 */
export async function getIapTier(userId: number): Promise<SubscriptionTier> {
  try {
    const db = await getDb();
    if (!db) return "free";

    // Get latest subscriptions per platform
    const subs = await db
      .select()
      .from(mobileSubscriptions)
      .where(eq(mobileSubscriptions.userId, userId))
      .orderBy(desc(mobileSubscriptions.createdAt));

    if (subs.length === 0) {
      return "free";
    }

    // Filter active subscriptions (not expired)
    const now = new Date();
    const activeSubs = subs.filter((sub) => {
      // Status must be active
      if (sub.status !== "active") return false;

      // Check expiration
      if (sub.expiresAt) {
        return sub.expiresAt > now;
      }

      // No expiration = active
      return true;
    });

    if (activeSubs.length === 0) {
      return "free";
    }

    // Return highest tier among active subscriptions
    const tiers = activeSubs.map((sub) => sub.tier);
    return maxTier(...tiers);
  } catch (error) {
    console.error("[SubscriptionTier] Error getting IAP tier:", error);
    return "free";
  }
}

/**
 * Get user's VIP tier (manual override)
 * Checks if user has admin role or is in VIP list
 */
export async function getVipTier(userId: number): Promise<SubscriptionTier> {
  try {
    const { users } = await import("../../drizzle/schema");
    const db = await getDb();
    if (!db) return "free";

    const [user] = await db
      .select({ role: users.role, email: users.email })
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (!user) return "free";

    // Admin users get premium
    if (user.role === "admin") {
      return "premium";
    }

    // Check VIP email list (from env or config)
    const VIP_EMAILS = [
      "arthurcsantos@gmail.com",
      // Add more VIP emails here
    ];

    if (user.email && VIP_EMAILS.includes(user.email.toLowerCase())) {
      return "premium";
    }

    return "free";
  } catch (error) {
    console.error("[SubscriptionTier] Error getting VIP tier:", error);
    return "free";
  }
}

/**
 * Get user's consolidated subscription tier
 * Considers all sources: Stripe + IAP + VIP
 * Returns the highest tier across all sources
 */
export async function getUserTier(userId: number): Promise<SubscriptionTier> {
  try {
    const [stripeTier, iapTier, vipTier] = await Promise.all([
      getStripeTier(userId),
      getIapTier(userId),
      getVipTier(userId),
    ]);

    const finalTier = maxTier(stripeTier, iapTier, vipTier);

    console.log(
      `[SubscriptionTier] userId=${userId} stripe=${stripeTier} iap=${iapTier} vip=${vipTier} final=${finalTier}`
    );

    return finalTier;
  } catch (error) {
    console.error("[SubscriptionTier] Error getting user tier:", error);
    return "free";
  }
}
