import { eq, desc } from "drizzle-orm";
import { planVersions } from "../../drizzle/schema";
import { getDb } from "../db";

/**
 * Salva uma nova versão do plano no histórico
 * Incrementa automaticamente o número da versão
 */
export async function saveNewPlanVersion(
  planId: number,
  snapshot: {
    dishes: any;
    shoppingList: any;
    prepSchedule?: any;
    usedStock?: any;
    remainingStock?: any;
    substitutions?: any;
  }
) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Buscar a última versão deste plano
  const lastVersions = await db
    .select()
    .from(planVersions)
    .where(eq(planVersions.planId, planId))
    .orderBy(desc(planVersions.version))
    .limit(1);

  // Incrementar versão (se não houver versões anteriores, começa em 1)
  const version = (lastVersions[0]?.version ?? 0) + 1;

  // Inserir nova versão
  const result = await db.insert(planVersions).values({
    planId,
    version,
    dishes: snapshot.dishes,
    shoppingList: snapshot.shoppingList,
    prepSchedule: snapshot.prepSchedule ?? null,
    usedStock: snapshot.usedStock ?? null,
    remainingStock: snapshot.remainingStock ?? null,
    substitutions: snapshot.substitutions ?? null,
  });

  return {
    id: result[0].insertId,
    version,
  };
}

/**
 * Lista todas as versões de um plano, ordenadas da mais recente para a mais antiga
 */
export async function getPlanVersions(planId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return db
    .select({
      id: planVersions.id,
      planId: planVersions.planId,
      version: planVersions.version,
      createdAt: planVersions.createdAt,
    })
    .from(planVersions)
    .where(eq(planVersions.planId, planId))
    .orderBy(desc(planVersions.version));
}

/**
 * Busca o snapshot completo de uma versão específica de um plano
 */
export async function getPlanVersionSnapshot(planId: number, version: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const rows = await db
    .select()
    .from(planVersions)
    .where(eq(planVersions.planId, planId));

  const match = rows.find((row) => row.version === version);
  return match ?? null;
}
