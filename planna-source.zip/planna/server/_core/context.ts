import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  ip: string; // PATCH 8.4.1: IP do cliente para rate limiting
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    // Authentication is optional for public procedures.
    user = null;
  }

  // PATCH 8.4.1: Extrair IP do cliente
  const ip = 
    (opts.req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() ||
    opts.req.socket.remoteAddress ||
    "unknown";

  return {
    req: opts.req,
    res: opts.res,
    user,
    ip,
  };
}
