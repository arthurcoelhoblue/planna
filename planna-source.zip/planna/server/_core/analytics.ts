/**
 * PATCH 7.8.0: Analytics simples para rastreamento de uso de preferences
 * 
 * Por enquanto: apenas console.log
 * Futuro: pode evoluir para tabela própria, métricas, etc.
 */

export async function logPreferenceSave(
  source: "dashboard" | "planner",
  userId: number
): Promise<void> {
  const timestamp = new Date().toISOString();
  console.log(`[preferences] user=${userId} source=${source} at=${timestamp}`);
  
  // TODO: Futuro - salvar em tabela de analytics
  // await db.insert(analyticsEvents).values({
  //   eventType: 'preference_save',
  //   userId,
  //   metadata: { source },
  //   timestamp: new Date(),
  // });
}
