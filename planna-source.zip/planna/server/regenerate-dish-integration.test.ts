import { describe, it, expect, beforeAll } from "vitest";
import { getDb } from "./db";
import { plans, sessions, users } from "../drizzle/schema";
import { eq } from "drizzle-orm";

describe("Integração completa de regeneração de prato", () => {
  let testUserId: number;
  let testSessionId: number;
  let testPlanId: number;

  beforeAll(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Criar usuário de teste
    const [user] = await db
      .insert(users)
      .values({
        openId: `test_integration_${Date.now()}`,
        name: "Test Integration User",
        email: `test_integration_${Date.now()}@test.com`,
        loginMethod: "test",
      })
      .$returningId();

    testUserId = user.id;

    // Criar sessão de teste
    const [session] = await db
      .insert(sessions)
      .values({
        userId: testUserId,
        inputText: "frango, arroz, feijão, batata",
        servings: 5,
        objective: "normal",
        exclusions: "[]",
      })
      .$returningId();

    testSessionId = session.id;

    // Criar plano de teste com múltiplos pratos
    const testDishes = [
      {
        name: "Frango Grelhado com Arroz",
        servings: 5,
        ingredients: [
          { name: "frango", quantity: "500g" },
          { name: "arroz", quantity: "300g" },
        ],
        steps: ["Temperar o frango", "Grelhar o frango", "Cozinhar o arroz"],
        kcal: 450,
        prepTime: 30,
      },
      {
        name: "Feijão Tropeiro",
        servings: 5,
        ingredients: [{ name: "feijão", quantity: "400g" }],
        steps: ["Cozinhar o feijão", "Refogar"],
        kcal: 350,
        prepTime: 25,
      },
      {
        name: "Batata Assada",
        servings: 5,
        ingredients: [{ name: "batata", quantity: "600g" }],
        steps: ["Lavar as batatas", "Assar no forno"],
        kcal: 200,
        prepTime: 40,
      },
    ];

    const [plan] = await db
      .insert(plans)
      .values({
        sessionId: testSessionId,
        dishes: JSON.stringify(testDishes),
        shoppingList: JSON.stringify([
          { item: "frango", quantity: "500", unit: "g", category: "Proteínas" },
          { item: "arroz", quantity: "300", unit: "g", category: "Grãos" },
          { item: "feijão", quantity: "400", unit: "g", category: "Grãos" },
          { item: "batata", quantity: "600", unit: "g", category: "Legumes" },
        ]),
        prepSchedule: JSON.stringify([
          { step: "Preparar ingredientes", order: 1 },
          { step: "Cozinhar", order: 2 },
        ]),
      })
      .$returningId();

    testPlanId = plan.id;
  });

  it("deve ter plano com múltiplos pratos criado", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const plan = await db
      .select()
      .from(plans)
      .where(eq(plans.id, testPlanId))
      .limit(1);

    expect(plan.length).toBe(1);
    const dishes = JSON.parse(plan[0].dishes);
    expect(dishes.length).toBe(3);
    expect(dishes[0].name).toBe("Frango Grelhado com Arroz");
    expect(dishes[1].name).toBe("Feijão Tropeiro");
    expect(dishes[2].name).toBe("Batata Assada");
  });

  it("deve validar estrutura de cada prato", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const plan = await db
      .select()
      .from(plans)
      .where(eq(plans.id, testPlanId))
      .limit(1);

    const dishes = JSON.parse(plan[0].dishes);

    dishes.forEach((dish: any) => {
      expect(dish).toHaveProperty("name");
      expect(dish).toHaveProperty("servings");
      expect(dish).toHaveProperty("ingredients");
      expect(dish).toHaveProperty("steps");
      expect(dish).toHaveProperty("kcal");
      expect(dish).toHaveProperty("prepTime");
      expect(Array.isArray(dish.ingredients)).toBe(true);
      expect(Array.isArray(dish.steps)).toBe(true);
    });
  });

  it("deve simular regeneração do primeiro prato (índice 0)", async () => {
    const { getPlanById, updatePlan } = await import("./db");
    const { saveNewPlanVersion } = await import("./_core/planVersion");

    const plan = await getPlanById(testPlanId);
    expect(plan).not.toBeNull();

    const dishes = JSON.parse(plan!.dishes);
    const oldDish = dishes[0];

    // Simular regeneração (sem chamar LLM de verdade)
    const newDish = {
      ...oldDish,
      name: "Frango Grelhado com Arroz - Versão Melhorada",
      steps: [
        "Temperar o frango com alho e limão",
        "Grelhar o frango até dourar",
        "Cozinhar o arroz com cebola",
      ],
    };

    dishes[0] = newDish;

    // Atualizar plano
    await updatePlan(testPlanId, {
      dishes: JSON.stringify(dishes),
    });

    // Criar versão
    const version = await saveNewPlanVersion(testPlanId, {
      dishes,
      shoppingList: JSON.parse(plan!.shoppingList),
    });

    expect(version.version).toBeGreaterThan(0);

    // Validar que o plano foi atualizado
    const updatedPlan = await getPlanById(testPlanId);
    const updatedDishes = JSON.parse(updatedPlan!.dishes);

    expect(updatedDishes[0].name).toBe("Frango Grelhado com Arroz - Versão Melhorada");
    expect(updatedDishes[0].steps.length).toBe(3);
    expect(updatedDishes[1].name).toBe("Feijão Tropeiro"); // Outros pratos não mudaram
    expect(updatedDishes[2].name).toBe("Batata Assada");
  });

  it("deve simular regeneração do segundo prato (índice 1)", async () => {
    const { getPlanById, updatePlan } = await import("./db");
    const { saveNewPlanVersion } = await import("./_core/planVersion");

    const plan = await getPlanById(testPlanId);
    const dishes = JSON.parse(plan!.dishes);
    const oldDish = dishes[1];

    const newDish = {
      ...oldDish,
      name: "Feijão Tropeiro Especial",
      ingredients: [
        { name: "feijão", quantity: "400g" },
        { name: "bacon", quantity: "100g" },
      ],
    };

    dishes[1] = newDish;

    await updatePlan(testPlanId, {
      dishes: JSON.stringify(dishes),
    });

    const version = await saveNewPlanVersion(testPlanId, {
      dishes,
      shoppingList: JSON.parse(plan!.shoppingList),
    });

    expect(version.version).toBeGreaterThan(1); // Deve ser versão 2 ou maior

    const updatedPlan = await getPlanById(testPlanId);
    const updatedDishes = JSON.parse(updatedPlan!.dishes);

    expect(updatedDishes[1].name).toBe("Feijão Tropeiro Especial");
    expect(updatedDishes[1].ingredients.length).toBe(2);
  });

  it("deve validar que versões foram criadas corretamente", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const { planVersions } = await import("../drizzle/schema");

    const versions = await db
      .select()
      .from(planVersions)
      .where(eq(planVersions.planId, testPlanId));

    // Deve ter pelo menos 2 versões (dos testes anteriores)
    expect(versions.length).toBeGreaterThanOrEqual(2);

    // Validar estrutura das versões
    versions.forEach((version) => {
      expect(version.planId).toBe(testPlanId);
      expect(version.version).toBeGreaterThan(0);
      expect(version.dishes).toBeDefined();
      expect(version.shoppingList).toBeDefined();
    });

    // Validar que as versões estão em ordem crescente
    const sortedVersions = versions.sort((a, b) => a.version - b.version);
    for (let i = 1; i < sortedVersions.length; i++) {
      expect(sortedVersions[i].version).toBeGreaterThan(sortedVersions[i - 1].version);
    }
  });
});
