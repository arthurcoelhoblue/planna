import { describe, it, expect } from "vitest";
import { MODE_DESCRIPTIONS, MODE_INSTRUCTIONS, MODE_LABELS, PlannerMode, isValidMode, sanitizeMode } from "../shared/modes";

/**
 * PATCH 7.3.0 - Testes de Consolidação de Modos
 *
 * Valida que:
 * 1. Módulo central de modos está corretamente definido
 * 2. Todos os 4 modos estão presentes (normal, aproveitamento, lowcal, highprotein)
 * 3. Funções de validação e sanitização funcionam corretamente
 * 4. Geração de plano usa modos consolidados
 * 5. Regeneração de prato respeita modo do plano
 */

describe("PATCH 7.3.0 - Consolidação de Modos", () => {
  describe("Módulo Central - Definições", () => {
    it("deve ter MODE_LABELS com 4 modos", () => {
      const modes = Object.keys(MODE_LABELS);
      expect(modes).toHaveLength(4);
      expect(modes).toContain("normal");
      expect(modes).toContain("aproveitamento");
      expect(modes).toContain("lowcal");
      expect(modes).toContain("highprotein");
    });

    it("deve ter MODE_DESCRIPTIONS com 4 modos", () => {
      const modes = Object.keys(MODE_DESCRIPTIONS);
      expect(modes).toHaveLength(4);
      expect(modes).toContain("normal");
      expect(modes).toContain("aproveitamento");
      expect(modes).toContain("lowcal");
      expect(modes).toContain("highprotein");
    });

    it("deve ter MODE_INSTRUCTIONS com 4 modos", () => {
      const modes = Object.keys(MODE_INSTRUCTIONS);
      expect(modes).toHaveLength(4);
      expect(modes).toContain("normal");
      expect(modes).toContain("aproveitamento");
      expect(modes).toContain("lowcal");
      expect(modes).toContain("highprotein");
    });

    it("deve ter labels legíveis", () => {
      expect(MODE_LABELS.normal).toBe("Modo normal");
      expect(MODE_LABELS.aproveitamento).toBe("Aproveitamento de ingredientes");
      expect(MODE_LABELS.lowcal).toBe("Low cal (menos calorias)");
      expect(MODE_LABELS.highprotein).toBe("High protein (mais proteína)");
    });

    it("deve ter descrições detalhadas", () => {
      expect(MODE_DESCRIPTIONS.normal).toContain("equilibrado");
      expect(MODE_DESCRIPTIONS.aproveitamento).toContain("ingredientes que o usuário já tem");
      expect(MODE_DESCRIPTIONS.lowcal).toContain("reduzir calorias");
      expect(MODE_DESCRIPTIONS.highprotein).toContain("aumentar proteína");
    });

    it("deve ter instruções específicas", () => {
      expect(MODE_INSTRUCTIONS.normal).toContain("equilibradas");
      expect(MODE_INSTRUCTIONS.aproveitamento).toContain("Priorize ingredientes");
      expect(MODE_INSTRUCTIONS.lowcal).toContain("Reduza calorias");
      expect(MODE_INSTRUCTIONS.highprotein).toContain("proteína");
    });
  });

  describe("Validação de Modos", () => {
    it("deve validar modos corretos", () => {
      expect(isValidMode("normal")).toBe(true);
      expect(isValidMode("aproveitamento")).toBe(true);
      expect(isValidMode("lowcal")).toBe(true);
      expect(isValidMode("highprotein")).toBe(true);
    });

    it("deve rejeitar modos inválidos", () => {
      expect(isValidMode("invalid")).toBe(false);
      expect(isValidMode("")).toBe(false);
      expect(isValidMode("NORMAL")).toBe(false); // Case sensitive
      expect(isValidMode("low-cal")).toBe(false);
    });

    it("deve sanitizar modos inválidos para 'normal'", () => {
      expect(sanitizeMode("invalid")).toBe("normal");
      expect(sanitizeMode("")).toBe("normal");
      expect(sanitizeMode(undefined)).toBe("normal");
      expect(sanitizeMode(null)).toBe("normal");
    });

    it("deve manter modos válidos", () => {
      expect(sanitizeMode("normal")).toBe("normal");
      expect(sanitizeMode("aproveitamento")).toBe("aproveitamento");
      expect(sanitizeMode("lowcal")).toBe("lowcal");
      expect(sanitizeMode("highprotein")).toBe("highprotein");
    });
  });

  describe("Tipagem PlannerMode", () => {
    it("deve aceitar apenas valores válidos", () => {
      const validModes: PlannerMode[] = ["normal", "aproveitamento", "lowcal", "highprotein"];
      
      validModes.forEach(mode => {
        expect(isValidMode(mode)).toBe(true);
      });
    });

    it("deve ter tipo correto em MODE_LABELS", () => {
      const mode: PlannerMode = "normal";
      const label = MODE_LABELS[mode];
      expect(typeof label).toBe("string");
    });

    it("deve ter tipo correto em MODE_DESCRIPTIONS", () => {
      const mode: PlannerMode = "aproveitamento";
      const description = MODE_DESCRIPTIONS[mode];
      expect(typeof description).toBe("string");
    });

    it("deve ter tipo correto em MODE_INSTRUCTIONS", () => {
      const mode: PlannerMode = "lowcal";
      const instructions = MODE_INSTRUCTIONS[mode];
      expect(typeof instructions).toBe("string");
    });
  });

  describe("Integração com Recipe Engine", () => {
    it("deve importar modos no recipe-engine.ts", async () => {
      // Valida que o import funciona
      const { MODE_DESCRIPTIONS, MODE_INSTRUCTIONS, sanitizeMode } = await import("../shared/modes");
      
      expect(MODE_DESCRIPTIONS).toBeDefined();
      expect(MODE_INSTRUCTIONS).toBeDefined();
      expect(sanitizeMode).toBeDefined();
    });

    it("deve usar sanitizeMode para garantir modo válido", () => {
      // Simula lógica do recipe-engine
      const objective = "invalid_mode";
      const mode = sanitizeMode(objective) as PlannerMode;
      
      expect(mode).toBe("normal");
      expect(isValidMode(mode)).toBe(true);
    });

    it("deve montar prompt com MODE_DESCRIPTIONS", () => {
      const mode: PlannerMode = "aproveitamento";
      const modeDescription = MODE_DESCRIPTIONS[mode];
      const modeInstructions = MODE_INSTRUCTIONS[mode];

      const prompt = `
MODO DE GERAÇÃO ATUAL:
- ${mode}: ${modeDescription}
- INSTRUÇÕES: ${modeInstructions}
      `.trim();

      expect(prompt).toContain("aproveitamento");
      expect(prompt).toContain(modeDescription);
      expect(prompt).toContain(modeInstructions);
    });
  });

  describe("Integração com Regeneração", () => {
    it("deve importar modos no llm.ts", async () => {
      // Valida que o import funciona
      const { MODE_DESCRIPTIONS, MODE_INSTRUCTIONS, sanitizeMode } = await import("../shared/modes");
      
      expect(MODE_DESCRIPTIONS).toBeDefined();
      expect(MODE_INSTRUCTIONS).toBeDefined();
      expect(sanitizeMode).toBeDefined();
    });

    it("deve sanitizar mode antes de usar", () => {
      // Simula lógica do regenerateDish
      const mode = "invalid";
      const planMode = sanitizeMode(mode);
      
      expect(planMode).toBe("normal");
      expect(isValidMode(planMode)).toBe(true);
    });

    it("deve montar prompt de regeneração com modo", () => {
      const mode: PlannerMode = "lowcal";
      const modeDescription = MODE_DESCRIPTIONS[mode];
      const modeInstructions = MODE_INSTRUCTIONS[mode];

      const prompt = `
MODO DE GERAÇÃO ATUAL:
- ${mode}: ${modeDescription}
- INSTRUÇÕES: ${modeInstructions}

IMPORTANTE: Ao regenerar este prato, mantenha o espírito do modo atual (${mode})
      `.trim();

      expect(prompt).toContain("lowcal");
      expect(prompt).toContain(modeDescription);
      expect(prompt).toContain(modeInstructions);
      expect(prompt).toContain("mantenha o espírito do modo atual");
    });
  });

  describe("Cenários de Uso - Geração de Plano", () => {
    it("Cenário 1: Modo Normal", () => {
      const mode: PlannerMode = "normal";
      const description = MODE_DESCRIPTIONS[mode];
      const instructions = MODE_INSTRUCTIONS[mode];

      expect(description).toContain("equilibrado");
      expect(instructions).toContain("equilibradas");
    });

    it("Cenário 2: Modo Aproveitamento", () => {
      const mode: PlannerMode = "aproveitamento";
      const description = MODE_DESCRIPTIONS[mode];
      const instructions = MODE_INSTRUCTIONS[mode];

      expect(description).toContain("ingredientes que o usuário já tem");
      expect(instructions).toContain("Priorize ingredientes");
    });

    it("Cenário 3: Modo Low Cal", () => {
      const mode: PlannerMode = "lowcal";
      const description = MODE_DESCRIPTIONS[mode];
      const instructions = MODE_INSTRUCTIONS[mode];

      expect(description).toContain("reduzir calorias");
      expect(instructions).toContain("Reduza calorias");
    });

    it("Cenário 4: Modo High Protein", () => {
      const mode: PlannerMode = "highprotein";
      const description = MODE_DESCRIPTIONS[mode];
      const instructions = MODE_INSTRUCTIONS[mode];

      expect(description).toContain("aumentar proteína");
      expect(instructions).toContain("proteína");
    });
  });

  describe("Cenários de Uso - Regeneração", () => {
    it("deve respeitar modo do plano na regeneração", () => {
      // Simula regeneração com modo específico
      const planMode = "highprotein";
      const mode = sanitizeMode(planMode) as PlannerMode;
      
      expect(mode).toBe("highprotein");
      expect(MODE_INSTRUCTIONS[mode]).toContain("proteína");
    });

    it("deve usar modo 'normal' se plano não tiver mode", () => {
      // Simula regeneração sem mode
      const planMode = undefined;
      const mode = sanitizeMode(planMode) as PlannerMode;
      
      expect(mode).toBe("normal");
    });

    it("deve sanitizar mode inválido do plano", () => {
      // Simula regeneração com mode corrompido
      const planMode = "corrupted_mode";
      const mode = sanitizeMode(planMode) as PlannerMode;
      
      expect(mode).toBe("normal");
      expect(isValidMode(mode)).toBe(true);
    });
  });

  describe("Consistência de Dados", () => {
    it("deve ter mesmas chaves em LABELS, DESCRIPTIONS e INSTRUCTIONS", () => {
      const labelKeys = Object.keys(MODE_LABELS).sort();
      const descKeys = Object.keys(MODE_DESCRIPTIONS).sort();
      const instKeys = Object.keys(MODE_INSTRUCTIONS).sort();

      expect(labelKeys).toEqual(descKeys);
      expect(descKeys).toEqual(instKeys);
    });

    it("não deve ter valores vazios em LABELS", () => {
      Object.values(MODE_LABELS).forEach(label => {
        expect(label.length).toBeGreaterThan(0);
      });
    });

    it("não deve ter valores vazios em DESCRIPTIONS", () => {
      Object.values(MODE_DESCRIPTIONS).forEach(desc => {
        expect(desc.length).toBeGreaterThan(0);
      });
    });

    it("não deve ter valores vazios em INSTRUCTIONS", () => {
      Object.values(MODE_INSTRUCTIONS).forEach(inst => {
        expect(inst.length).toBeGreaterThan(0);
      });
    });
  });

  describe("Backward Compatibility", () => {
    it("deve manter 'normal' e 'aproveitamento' funcionando", () => {
      // Garante que modos antigos ainda funcionam
      expect(isValidMode("normal")).toBe(true);
      expect(isValidMode("aproveitamento")).toBe(true);
      
      expect(MODE_LABELS.normal).toBeDefined();
      expect(MODE_LABELS.aproveitamento).toBeDefined();
    });

    it("deve adicionar 'lowcal' e 'highprotein' sem quebrar", () => {
      // Garante que novos modos foram adicionados
      expect(isValidMode("lowcal")).toBe(true);
      expect(isValidMode("highprotein")).toBe(true);
      
      expect(MODE_LABELS.lowcal).toBeDefined();
      expect(MODE_LABELS.highprotein).toBeDefined();
    });

    it("deve sanitizar valores antigos corretamente", () => {
      // Testa que valores antigos ainda são válidos
      expect(sanitizeMode("normal")).toBe("normal");
      expect(sanitizeMode("aproveitamento")).toBe("aproveitamento");
    });
  });

  describe("Prompt Generation", () => {
    it("deve gerar prompt completo para modo normal", () => {
      const mode: PlannerMode = "normal";
      const prompt = `
MODO DE GERAÇÃO ATUAL:
- ${mode}: ${MODE_DESCRIPTIONS[mode]}
- INSTRUÇÕES: ${MODE_INSTRUCTIONS[mode]}
      `.trim();

      expect(prompt).toContain("MODO DE GERAÇÃO ATUAL");
      expect(prompt).toContain("normal");
      expect(prompt).toContain("INSTRUÇÕES");
    });

    it("deve gerar prompt completo para modo aproveitamento", () => {
      const mode: PlannerMode = "aproveitamento";
      const prompt = `
MODO DE GERAÇÃO ATUAL:
- ${mode}: ${MODE_DESCRIPTIONS[mode]}
- INSTRUÇÕES: ${MODE_INSTRUCTIONS[mode]}
      `.trim();

      expect(prompt).toContain("aproveitamento");
      expect(prompt).toContain("ingredientes que o usuário já tem");
    });

    it("deve gerar prompt completo para modo lowcal", () => {
      const mode: PlannerMode = "lowcal";
      const prompt = `
MODO DE GERAÇÃO ATUAL:
- ${mode}: ${MODE_DESCRIPTIONS[mode]}
- INSTRUÇÕES: ${MODE_INSTRUCTIONS[mode]}
      `.trim();

      expect(prompt).toContain("lowcal");
      expect(prompt).toContain("reduzir calorias");
    });

    it("deve gerar prompt completo para modo highprotein", () => {
      const mode: PlannerMode = "highprotein";
      const prompt = `
MODO DE GERAÇÃO ATUAL:
- ${mode}: ${MODE_DESCRIPTIONS[mode]}
- INSTRUÇÕES: ${MODE_INSTRUCTIONS[mode]}
      `.trim();

      expect(prompt).toContain("highprotein");
      expect(prompt).toContain("proteína");
    });
  });
});
