ALTER TABLE `plans` ADD `usedStock` text;--> statement-breakpoint
ALTER TABLE `plans` ADD `remainingStock` text;--> statement-breakpoint
ALTER TABLE `plans` ADD `substitutions` text;