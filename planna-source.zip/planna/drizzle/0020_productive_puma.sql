ALTER TABLE `user_preferences` ADD `mode` varchar(32) DEFAULT 'normal' NOT NULL;--> statement-breakpoint
ALTER TABLE `user_preferences` ADD `servings` int DEFAULT 10 NOT NULL;--> statement-breakpoint
ALTER TABLE `user_preferences` ADD `varieties` int DEFAULT 3 NOT NULL;--> statement-breakpoint
ALTER TABLE `user_preferences` ADD `time` int;--> statement-breakpoint
ALTER TABLE `user_preferences` ADD `allow_new_ingredients` boolean DEFAULT true NOT NULL;