ALTER TABLE `plans` ADD `shareToken` varchar(64);--> statement-breakpoint
ALTER TABLE `plans` ADD `shareCount` int DEFAULT 0;