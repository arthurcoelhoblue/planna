CREATE TABLE `mobile_subscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`platform` enum('apple','google') NOT NULL,
	`product_id` varchar(128) NOT NULL,
	`tier` enum('free','pro','premium') NOT NULL,
	`status` enum('active','canceled','expired') NOT NULL,
	`expires_at` timestamp,
	`raw_receipt` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `mobile_subscriptions_id` PRIMARY KEY(`id`)
);
