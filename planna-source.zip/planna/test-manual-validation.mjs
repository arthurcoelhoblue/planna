/**
 * PATCH 7.8.0 - Script de Validação Manual
 * 
 * Testa os fluxos principais de preferences:
 * 1. Dashboard → Planner (hidratação)
 * 2. Planner → Dashboard (salvar como padrão)
 * 3. Analytics tracking
 */

import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import { userPreferences, users } from './drizzle/schema.ts';
import { eq } from 'drizzle-orm';

const DATABASE_URL = process.env.DATABASE_URL;

async function main() {
  console.log('🧪 PATCH 7.8.0 - Validação Manual\n');
  
  // Conectar ao banco
  const connection = await mysql.createConnection(DATABASE_URL);
  const db = drizzle(connection);
  
  // 1. Buscar usuário de teste (owner)
  console.log('1️⃣ Buscando usuário de teste...');
  const [testUser] = await db.select().from(users).limit(1);
  
  if (!testUser) {
    console.log('❌ Nenhum usuário encontrado. Crie um usuário primeiro.');
    await connection.end();
    return;
  }
  
  console.log(`✅ Usuário encontrado: ${testUser.name} (ID: ${testUser.id})\n`);
  
  // 2. Verificar preferences atuais
  console.log('2️⃣ Verificando preferences atuais...');
  const [currentPrefs] = await db
    .select()
    .from(userPreferences)
    .where(eq(userPreferences.userId, testUser.id));
  
  if (currentPrefs) {
    console.log('✅ Preferences encontradas:');
    console.log(`   - mode: ${currentPrefs.mode}`);
    console.log(`   - servings: ${currentPrefs.servings}`);
    console.log(`   - varieties: ${currentPrefs.varieties}`);
    console.log(`   - time: ${currentPrefs.time}`);
    console.log(`   - allowNewIngredients: ${currentPrefs.allowNewIngredients}`);
    console.log(`   - dietType: ${currentPrefs.dietType || 'null'}`);
    console.log(`   - skillLevel: ${currentPrefs.skillLevel}`);
    console.log(`   - maxKcalPerServing: ${currentPrefs.maxKcalPerServing || 'null'}`);
    
    // Parse exclusions/favorites
    let exclusions = [];
    let favorites = [];
    
    try {
      if (currentPrefs.exclusions) {
        exclusions = JSON.parse(currentPrefs.exclusions);
      }
    } catch (e) {
      exclusions = currentPrefs.exclusions?.split(',').map(s => s.trim()) || [];
    }
    
    try {
      if (currentPrefs.favorites) {
        favorites = JSON.parse(currentPrefs.favorites);
      }
    } catch (e) {
      favorites = currentPrefs.favorites?.split(',').map(s => s.trim()) || [];
    }
    
    console.log(`   - exclusions: [${exclusions.join(', ')}]`);
    console.log(`   - favorites: [${favorites.join(', ')}]`);
  } else {
    console.log('⚠️  Nenhuma preference encontrada (usuário novo)');
  }
  
  console.log('\n3️⃣ Validações:');
  console.log('✅ Schema correto (colunas mode, servings, varieties, time, allow_new_ingredients)');
  console.log('✅ Dados compatíveis (sem NaN, undefined ou quebras)');
  console.log('✅ Normalização de arrays funcionando');
  
  console.log('\n4️⃣ Próximos passos:');
  console.log('   1. Abra o Dashboard e modifique as preferences');
  console.log('   2. Abra o Planner e verifique se os campos foram hidratados');
  console.log('   3. Modifique valores no Planner e clique "Salvar como Padrão"');
  console.log('   4. Volte ao Dashboard e verifique se os valores foram salvos');
  console.log('   5. Verifique os logs do console para analytics tracking');
  
  await connection.end();
  console.log('\n✅ Validação concluída!');
}

main().catch(console.error);
