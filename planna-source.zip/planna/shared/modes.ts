/**
 * PATCH 7.3.0 - Módulo Central de Modos de Geração
 *
 * Define os modos disponíveis para geração de planos de marmitas,
 * centralizando tipos, labels e descrições para uso consistente
 * em toda a aplicação (frontend, backend, engine).
 */

/**
 * Tipo dos modos de geração de plano
 */
export type PlannerMode = "normal" | "aproveitamento" | "lowcal" | "highprotein";

/**
 * Labels legíveis para exibição na UI
 */
export const MODE_LABELS: Record<PlannerMode, string> = {
  normal: "Modo normal",
  aproveitamento: "Aproveitamento de ingredientes",
  lowcal: "Low cal (menos calorias)",
  highprotein: "High protein (mais proteína)",
};

/**
 * Descrições detalhadas para uso em prompts de LLM e tooltips
 */
export const MODE_DESCRIPTIONS: Record<PlannerMode, string> = {
  normal: "Plano equilibrado, sem restrições específicas.",
  aproveitamento: "Foca em usar ingredientes que o usuário já tem, reduzindo desperdício.",
  lowcal: "Foca em reduzir calorias por porção, mantendo equilíbrio nutricional.",
  highprotein: "Foca em aumentar proteína nas refeições, sem exagerar nas calorias.",
};

/**
 * Instruções específicas para o LLM por modo
 */
export const MODE_INSTRUCTIONS: Record<PlannerMode, string> = {
  normal: "Crie receitas equilibradas e variadas, sem restrições específicas de calorias ou macronutrientes.",
  aproveitamento: "Priorize ingredientes já presentes no estoque/lista inicial. Minimize desperdício e maximize o uso dos ingredientes disponíveis.",
  lowcal: "Reduza calorias por porção sem sacrificar demais o sabor. Use técnicas de cozimento mais saudáveis (grelhado, assado, cozido) e evite frituras.",
  highprotein: "Dê preferência a fontes de proteína (frango, peixe, ovos, leguminosas) e ajuste acompanhamentos para manter equilíbrio calórico.",
};

/**
 * Valida se uma string é um modo válido
 */
export function isValidMode(mode: string): mode is PlannerMode {
  return ["normal", "aproveitamento", "lowcal", "highprotein"].includes(mode);
}

/**
 * Retorna modo padrão se o valor for inválido
 */
export function sanitizeMode(mode: string | undefined | null): PlannerMode {
  if (!mode) return "normal";
  return isValidMode(mode) ? mode : "normal";
}
