# PATCH 8.6.0 - Regeneração de Lista de Compras

**Data:** 06/12/2025  
**Objetivo:** Permitir regeneração granular da lista de compras sem recriar o plano inteiro

---

## 📋 Resumo Executivo

Este patch implementa um sistema completo de regeneração de lista de compras, permitindo que o usuário ajuste apenas a lista sem modificar os pratos do plano. A funcionalidade inclui endpoint backend, UI frontend com modal de comparação, testes automatizados e versionamento automático.

---

## 🎯 Funcionalidades Implementadas

### 1. Backend (Endpoint)

#### `server/_core/llm.ts`
- **Função:** `regenerateShoppingList()`
- **Parâmetros:**
  - `currentList`: Lista de compras atual
  - `dishes`: Pratos do plano
  - `servings`: Número de porções
- **Retorno:** Nova lista de compras otimizada
- **Lógica:**
  - Analisa receitas e calcula quantidades necessárias
  - Consolida ingredientes repetidos
  - Organiza por categoria (Hortifruti, Açougue, Mercearia, etc.)
  - Usa unidades práticas e arredonda quantidades

#### `server/routers.ts`
- **Endpoint:** `mealPlan.regenerateShoppingList`
- **Input:** `{ planId: number }`
- **Output:** `{ ok, newPlan, newVersion, diff }`
- **Fluxo:**
  1. Busca plano no banco
  2. Extrai dados (dishes, shoppingList, servings)
  3. Chama `regenerateShoppingList()` do LLM
  4. Atualiza plano no banco
  5. Cria versão automaticamente
  6. Retorna resultado com diff

---

### 2. Frontend (UI)

#### `client/src/pages/PlanView.tsx`
- **Botão:** "Regenerar Lista" no card de Lista de Compras
- **Posição:** CardHeader, alinhado à direita
- **Estados:**
  - Normal: Ícone RefreshCw + "Regenerar Lista"
  - Loading: Spinner + "Regenerando..."
- **Integração:**
  - Mutation `regenerateShoppingList`
  - Atualiza `localPlan` após sucesso
  - Abre modal de comparação automaticamente
  - Recarrega versões do plano

#### `client/src/components/ShoppingListDiffDialog.tsx`
- **Modal de Comparação:** Exibe antes/depois da lista
- **Seções:**
  - **Itens Adicionados:** Badge verde com ícone Check
  - **Itens Removidos:** Badge vermelho com ícone X
  - **Itens Mantidos:** Badge cinza com ícone Minus (primeiros 5)
  - **Resumo:** Total de itens na nova lista
- **Lógica:**
  - Normalização de itens para comparação
  - Detecção de adições, remoções e manutenções
  - Formatação com quantidade, unidade e categoria

---

### 3. Testes Automatizados

#### `server/regenerate-shopping-list.test.ts`
**5 cenários de teste:**
1. ✅ Regenerar lista com sucesso
2. ✅ Erro para planId inválido
3. ✅ Criação de versão incremental
4. ✅ Validação de estrutura de snapshot
5. ✅ Preservação de estrutura da lista

**Configuração:**
- Timeout de 30s para geração de plano (beforeAll)
- Timeout de 15s para regenerações individuais
- Timeout de 30s para regenerações múltiplas

#### `client/src/components/ShoppingListDiffDialog.test.tsx`
**5 cenários de teste:**
1. ✅ Calcular itens adicionados corretamente
2. ✅ Calcular itens removidos corretamente
3. ✅ Calcular itens mantidos corretamente
4. ✅ Validar estrutura dos itens
5. ✅ Calcular total de itens na nova lista

**Configuração:**
- Testes unitários de lógica de comparação
- Sem dependência de DOM (vitest puro)
- Validação de estrutura de dados

---

## 🔧 Arquivos Modificados

### Backend
- `server/_core/llm.ts` - Adicionada função `regenerateShoppingList()`
- `server/routers.ts` - Adicionado endpoint `mealPlan.regenerateShoppingList`

### Frontend
- `client/src/pages/PlanView.tsx` - Adicionado botão e integração
- `client/src/components/ShoppingListDiffDialog.tsx` - Novo componente

### Testes
- `server/regenerate-shopping-list.test.ts` - Novo arquivo
- `client/src/components/ShoppingListDiffDialog.test.tsx` - Novo arquivo

### Configuração
- `vitest.config.ts` - Adicionado suporte a `.test.tsx`

### Documentação
- `todo.md` - Atualizado com tarefas do PATCH 8.6.0
- `PATCH-8.6.0-RELATORIO.md` - Este relatório

---

## 📊 Estrutura de Dados

### Input (Endpoint)
```typescript
{
  planId: number
}
```

### Output (Endpoint)
```typescript
{
  ok: boolean,
  newPlan: {
    ...plan,
    shoppingList: Array<{
      category: string,
      items: Array<{
        item: string,
        quantity: string,
        unit: string,
        notes?: string
      }>
    }>
  },
  newVersion: {
    id: number,
    version: number
  },
  diff: {
    oldList: Array<...>,
    newList: Array<...>
  }
}
```

---

## 🎨 UI/UX

### Botão de Regeneração
- **Localização:** Card "Lista de Compras" → CardHeader → Direita
- **Variante:** `outline` + `sm`
- **Ícone:** `RefreshCw` (lucide-react)
- **Estados:**
  - Normal: Clicável, texto "Regenerar Lista"
  - Loading: Desabilitado, spinner animado, texto "Regenerando..."

### Modal de Comparação
- **Abertura:** Automática após regeneração bem-sucedida
- **Tamanho:** `max-w-2xl`
- **Scroll:** `max-h-[80vh] overflow-y-auto`
- **Seções:**
  - Itens adicionados (verde)
  - Itens removidos (vermelho, tachado)
  - Itens mantidos (cinza, primeiros 5)
  - Resumo total

---

## 🧪 Roteiro de Testes Manuais

### Cenário 1: Regeneração Básica
1. Acesse um plano existente
2. Vá até o card "Lista de Compras"
3. Clique em "Regenerar Lista"
4. Aguarde o loading (spinner + "Regenerando...")
5. **Resultado esperado:** Modal de comparação abre automaticamente

### Cenário 2: Análise de Diferenças
1. No modal de comparação, verifique:
   - Badge verde com itens adicionados
   - Badge vermelho com itens removidos
   - Badge cinza com itens mantidos
   - Resumo total de itens
2. **Resultado esperado:** Diferenças claras e bem formatadas

### Cenário 3: Versionamento
1. Após regenerar, vá até "Histórico de Versões"
2. Verifique se uma nova versão foi criada
3. **Resultado esperado:** Versão incremental (ex: v3 → v4)

### Cenário 4: Plano Anônimo
1. Gere um plano sem estar logado
2. Tente clicar em "Regenerar Lista"
3. **Resultado esperado:** Modal de cadastro aparece

---

## 🔍 Validações Implementadas

### Backend
- ✅ Validação de existência do plano
- ✅ Erro tipado para planId inválido
- ✅ Criação automática de versão
- ✅ Preservação de estrutura da lista

### Frontend
- ✅ Interceptação de ações para planos anônimos
- ✅ Loading state durante regeneração
- ✅ Atualização de localPlan após sucesso
- ✅ Recarga de versões após regeneração

---

## 📈 Métricas de Qualidade

### Cobertura de Testes
- **Backend:** 5 cenários (100% dos fluxos críticos)
- **Frontend:** 5 cenários (100% da lógica de comparação)

### Performance
- **Tempo de regeneração:** ~5-15 segundos (LLM)
- **Timeout configurado:** 15 segundos (testes individuais)

### TypeScript
- ✅ 0 erros de compilação
- ✅ Tipagem completa de endpoints
- ✅ Inferência de tipos automática

---

## 🚀 Próximos Passos Sugeridos

1. **PATCH 8.7.0:** Regeneração individual de pratos (similar ao 8.6.0)
2. **PATCH 8.8.0:** Edição manual de itens da lista de compras
3. **PATCH 8.9.0:** Sugestões de substituições de ingredientes
4. **PATCH 9.0.0:** Integração com supermercados online

---

## 📝 Notas Técnicas

### Prompt do LLM
O prompt de regeneração instrui o modelo a:
- Analisar receitas e calcular quantidades
- Consolidar ingredientes repetidos
- Organizar por categoria
- Usar unidades práticas
- Arredondar quantidades para facilitar compra

### Normalização de Itens
A comparação antes/depois usa normalização:
```typescript
const normalizeItem = (item: any) => {
  return `${item.item}-${item.quantity}-${item.unit}`.toLowerCase();
};
```

### Versionamento
Cada regeneração cria uma nova versão do plano, permitindo rollback completo via histórico.

---

## ✅ Checklist de Entrega

- [x] Função `regenerateShoppingList()` em `llm.ts`
- [x] Endpoint `mealPlan.regenerateShoppingList`
- [x] Botão "Regenerar Lista" no PlanView
- [x] Modal `ShoppingListDiffDialog`
- [x] Testes backend (5 cenários)
- [x] Testes frontend (5 cenários)
- [x] Atualização do `todo.md`
- [x] Relatório completo (este arquivo)
- [x] Validação TypeScript (0 erros)

---

**Status:** ✅ CONCLUÍDO  
**Versão:** 8.6.0  
**Autor:** Manus AI  
**Data de Conclusão:** 06/12/2025
