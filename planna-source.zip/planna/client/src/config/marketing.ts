// client/src/config/marketing.ts
// Configuração centralizada de copy de marketing para a Home

export const HOME_COPY = {
  heroTitle: "Faça suas marmitas da semana em 10 minutos",
  heroSubtitle:
    "Diga o que tem em casa e receba um plano completo com porções e tempo de preparo.",
  heroCta: "Gerar meu primeiro plano grátis",
  heroCtaHref: "/planner",
  bullets: [
    "Aproveita o que já tem na geladeira",
    "Tempo estimado para preparar tudo",
    "Lista de compras pronta automaticamente",
  ],
};
