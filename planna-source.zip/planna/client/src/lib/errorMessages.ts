/**
 * PATCH 8.5.0 - Helper central de tratamento de erros
 * 
 * Transforma erros técnicos (TRPCError, rate limit, etc.) em mensagens amigáveis
 * para o usuário, sem stack traces ou jargão técnico.
 */

import { TRPCClientError } from "@trpc/client";

/**
 * Contextos de erro para mensagens específicas
 */
export type ErrorContext =
  | "auth"
  | "planner-generate"
  | "planner-anon"
  | "ingredients"
  | "shared-plan"
  | "generic";

/**
 * Extrai código de erro de um TRPCClientError ou erro genérico
 */
function getErrorCode(error: unknown): string | undefined {
  const err = error as TRPCClientError<any> | any;
  return err?.data?.code ?? err?.shape?.code ?? err?.code;
}

/**
 * Retorna mensagem amigável baseada no erro e contexto
 * 
 * @param error - Erro capturado (TRPCClientError ou Error genérico)
 * @param context - Contexto onde o erro ocorreu
 * @returns Mensagem amigável para exibir ao usuário
 * 
 * @example
 * ```tsx
 * const mutation = trpc.auth.loginStart.useMutation({
 *   onError: (error) => {
 *     const msg = getFriendlyErrorMessage(error, "auth");
 *     toast.error(msg);
 *   },
 * });
 * ```
 */
export function getFriendlyErrorMessage(
  error: unknown,
  context: ErrorContext
): string {
  const code = getErrorCode(error);

  // Rate limit (TOO_MANY_REQUESTS)
  if (code === "TOO_MANY_REQUESTS") {
    switch (context) {
      case "auth":
        return "Muitas tentativas em pouco tempo. Aguarde um minuto e tente novamente.";
      
      case "planner-generate":
      case "planner-anon":
        return "Você pediu planos demais em pouco tempo. Espere um pouco e tente novamente.";
      
      case "ingredients":
        return "Você fez muitas tentativas de detectar ingredientes. Tente novamente daqui a alguns minutos.";
      
      default:
        return "Muitas requisições em pouco tempo. Tente novamente em instantes.";
    }
  }

  // Not found para plano compartilhado
  if (code === "NOT_FOUND" && context === "shared-plan") {
    return "Este plano não está mais disponível. Ele pode ter sido removido.";
  }

  // Auth genérico
  if (context === "auth") {
    return "Não foi possível entrar agora. Confira os dados e tente novamente.";
  }

  // Fallback genérico
  return "Algo deu errado. Tente novamente em instantes.";
}
