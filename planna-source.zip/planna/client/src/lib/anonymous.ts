/**
 * PATCH 7.9.0 - Helper para gerenciar anonymousId
 * Usado para rastrear visitantes não-logados e limitar geração de planos gratuitos
 */

const ANON_KEY = "planna_anonymous_id";

/**
 * Obtém ou cria um anonymousId único para o visitante
 * O ID é armazenado no localStorage e persiste entre reloads
 */
export function getAnonymousId(): string | null {
  if (typeof window === "undefined") return null;

  let id = window.localStorage.getItem(ANON_KEY);
  if (!id) {
    // Gera UUID v4 usando crypto.randomUUID()
    // Fallback para Math.random() se randomUUID não estiver disponível
    id = crypto.randomUUID ? crypto.randomUUID() : generateFallbackUUID();
    window.localStorage.setItem(ANON_KEY, id);
  }
  return id;
}

/**
 * Fallback para gerar UUID quando crypto.randomUUID() não está disponível
 */
function generateFallbackUUID(): string {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * Limpa o anonymousId do localStorage
 * Útil para testes ou quando o usuário faz login
 */
export function clearAnonymousId(): void {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(ANON_KEY);
}
