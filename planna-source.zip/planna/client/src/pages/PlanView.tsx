import { useAuth } from "@/_core/hooks/useAuth";
import { AuthModal } from "@/components/AuthModal";
import { SignupModal } from "@/components/SignupModal";
import ShareModal from "@/components/ShareModal";
import { DishDiffDialog } from "@/components/DishDiffDialog";
import { ShoppingListDiffDialog } from "@/components/ShoppingListDiffDialog"; // PATCH 8.6.0
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import DashboardLayout from "@/components/DashboardLayout";
import { APP_TITLE } from "@/const";
import { trpc } from "@/lib/trpc";
import {
  AlertCircle,
  Check,
  ChefHat,
  ChevronDown,
  Clock,
  Download,
  Lightbulb,
  Loader2,
  Share2,
  ShoppingCart,
  ThumbsDown,
  ThumbsUp,
  RefreshCw,
} from "lucide-react";
import { useState, useEffect } from "react";
import { Link, useParams } from "wouter";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { MODE_LABELS, MODE_DESCRIPTIONS, PlannerMode } from "../../../shared/modes";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export default function PlanView() {
  const { planId } = useParams<{ planId: string }>();
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set());
  const [expandedSteps, setExpandedSteps] = useState<Set<number>>(new Set());
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [signupModalOpen, setSignupModalOpen] = useState(false);
  const [localPlan, setLocalPlan] = useState<any>(null);
  const [diffDialogOpen, setDiffDialogOpen] = useState(false);
  const [diffDishIndex, setDiffDishIndex] = useState<number | null>(null);
  const [lastDiff, setLastDiff] = useState<{ oldDish: any; newDish: any } | null>(null);
  const [shoppingListDiffDialogOpen, setShoppingListDiffDialogOpen] = useState(false); // PATCH 8.6.0
  const [lastShoppingListDiff, setLastShoppingListDiff] = useState<{ oldList: any; newList: any } | null>(null); // PATCH 8.6.0

  const numericPlanId = parseInt(planId || "0");

  const { data: plan, isLoading } = trpc.mealPlan.getById.useQuery(
    { planId: numericPlanId },
    { enabled: !!planId && isAuthenticated }
  );

  const submitFeedback = trpc.feedback.submit.useMutation();
  const exportPDF = trpc.mealPlan.exportPDF.useMutation();
  const regenerateDish = trpc.mealPlan.regenerateDish.useMutation();
  const regenerateShoppingList = trpc.mealPlan.regenerateShoppingList.useMutation(); // PATCH 8.6.0
  const { data: whatsappData } = trpc.mealPlan.getWhatsAppText.useQuery(
    { planId: numericPlanId },
    { enabled: !!planId && isAuthenticated }
  );

    const {data: versions,
    isLoading: isLoadingVersions,
    refetch: refetchVersions,
  } = trpc.mealPlan.listVersions.useQuery(
    { planId: numericPlanId },
    {
      enabled: !!planId && isAuthenticated,
    }
  );

  // PATCH 7.4.0: Carregar preferences para fallback
  const { data: preferences } = trpc.preferences.get.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const rollbackToVersion = trpc.mealPlan.rollbackToVersion.useMutation();

  // Sincronizar plan com localPlan
  useEffect(() => {
    if (plan) {
      setLocalPlan(plan);
    }
  }, [plan]);

  // PATCH 8.6.0: Handler para regenerar lista de compras
  const handleRegenerateShoppingList = () => {
    regenerateShoppingList.mutate(
      { planId: numericPlanId },
      {
        onSuccess: (data) => {
          // Atualizar plano local
          setLocalPlan(data.newPlan);
          // Salvar diff para exibir no modal
          setLastShoppingListDiff(data.diff);
          // Abrir modal de comparação
          setShoppingListDiffDialogOpen(true);
          // Recarregar versões
          refetchVersions();
        },
        onError: (error) => {
          console.error("Erro ao regenerar lista de compras:", error);
          alert("Erro ao regenerar lista de compras. Tente novamente.");
        },
      }
    );
  };

  // Helper para interceptar ações que requerem cadastro
  const requireAuthForAction = (cb: () => void) => {
    const activePlan = localPlan || plan;
    const isAnonymous = activePlan?.sessionId === 0;
    
    if (!isAnonymous) {
      cb();
      return;
    }

    if (isAuthenticated) {
      cb();
      return;
    }

    setSignupModalOpen(true);
  };

  // Atualizar localPlan quando regenerateDish completar
  useEffect(() => {
    if (regenerateDish.data?.newPlan) {
      setLocalPlan(regenerateDish.data.newPlan);
    }

    if (regenerateDish.data?.diff && regenerateDish.variables) {
      setLastDiff({
        oldDish: regenerateDish.data.diff.oldDish,
        newDish: regenerateDish.data.diff.newDish,
      });
      setDiffDishIndex(regenerateDish.variables.dishIndex);
      setDiffDialogOpen(true);
    }
  }, [regenerateDish.data]);

  // Atualizar localPlan quando rollback completar
  useEffect(() => {
    if (rollbackToVersion.data?.plan) {
      setLocalPlan(rollbackToVersion.data.plan);
    }
  }, [rollbackToVersion.data]);

  const handleFeedback = (dishName: string, rating: "liked" | "disliked") => {
    if (!planId) return;
    submitFeedback.mutate({
      planId: parseInt(planId),
      dishName,
      rating,
    });
  };

  const toggleCheck = (item: string) => {
    const newChecked = new Set(checkedItems);
    if (newChecked.has(item)) {
      newChecked.delete(item);
    } else {
      newChecked.add(item);
    }
    setCheckedItems(newChecked);
  };

  const toggleStep = (order: number) => {
    const newExpanded = new Set(expandedSteps);
    if (newExpanded.has(order)) {
      newExpanded.delete(order);
    } else {
      newExpanded.add(order);
    }
    setExpandedSteps(newExpanded);
  };

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <CardTitle>Acesso Restrito</CardTitle>
            <CardDescription>Você precisa estar logado para ver este plano</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              className="w-full"
              onClick={() => {
                setAuthMode("login");
                setAuthModalOpen(true);
              }}
            >
              Fazer Login
            </Button>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                setAuthMode("register");
                setAuthModalOpen(true);
              }}
            >
              Criar Conta
            </Button>
            <Link href="/">
              <Button variant="ghost" className="w-full">
                Voltar para Home
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!plan) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <CardTitle>Plano não encontrado</CardTitle>
            <CardDescription>Este plano não existe ou você não tem acesso a ele</CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/planner">
              <Button className="w-full">Criar Novo Plano</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Usar localPlan se disponível, senão plan
  const activePlan = localPlan || plan;

  // PATCH 7.3.1: Derivar modo do plano com fallback
  // Nota: O campo no banco é 'mode', não 'objective'
  const planMode = (activePlan?.mode ?? "normal") as PlannerMode;
  const planModeLabel = MODE_LABELS[planMode];
  const planModeDescription = MODE_DESCRIPTIONS[planMode];

  // PATCH 7.4.0: Derivar valores aplicados (plano → preferences → default)
  const appliedServings =
    activePlan?.requestedServings ??
    preferences?.servings ??
    null;

  const appliedVarieties =
    activePlan?.requestedVarieties ??
    preferences?.varieties ??
    null;

  // Nota: availableTime no plano é em horas, preferences.time é em minutos
  const appliedTime = (() => {
    if (activePlan?.availableTime) {
      return activePlan.availableTime * 60; // converter horas para minutos
    }
    if (preferences?.time) {
      return preferences.time; // já está em minutos
    }
    return null;
  })();

  const appliedAllowNewIngredients =
    (activePlan?.allowNewIngredients as boolean | undefined) ??
    (preferences?.allowNewIngredients as boolean | undefined) ??
    true;

  const appliedDietSummary = (() => {
    const dietType = activePlan?.dietType ?? preferences?.dietType ?? null;
    const maxKcal =
      activePlan?.maxKcalPerServing ??
      preferences?.maxKcalPerServing ??
      null;

    if (!dietType && !maxKcal) return "Sem restrições específicas";
    if (dietType && maxKcal) return `${dietType} · até ${maxKcal} kcal/porção`;
    if (dietType) return dietType;
    return `Até ${maxKcal} kcal/porção`;
  })();

  // PATCH 7.5.0: Derivar ingredientes evitados e favoritos (preferences → default)
  const appliedExclusions: string[] = (() => {
    // Nota: plans não tem campo exclusions/favorites, apenas user_preferences
    if (preferences?.exclusions) {
      // preferences.exclusions é text (JSON string ou array)
      if (Array.isArray(preferences.exclusions)) {
        return preferences.exclusions as string[];
      }
      try {
        const parsed = JSON.parse(preferences.exclusions as any);
        return Array.isArray(parsed) ? parsed : [];
      } catch {
        return [];
      }
    }
    return [];
  })();

  const appliedFavorites: string[] = (() => {
    if (preferences?.favorites) {
      if (Array.isArray(preferences.favorites)) {
        return preferences.favorites as string[];
      }
      try {
        const parsed = JSON.parse(preferences.favorites as any);
        return Array.isArray(parsed) ? parsed : [];
      } catch {
        return [];
      }
    }
    return [];
  })();

  // Parse com tratamento de erro (dados podem vir como string ou objeto)
  const dishes = typeof activePlan.dishes === 'string' ? JSON.parse(activePlan.dishes) : activePlan.dishes;
  const shoppingList = typeof activePlan.shoppingList === 'string' ? JSON.parse(activePlan.shoppingList) : activePlan.shoppingList;
  const prepSchedule = typeof activePlan.prepSchedule === 'string' ? JSON.parse(activePlan.prepSchedule) : activePlan.prepSchedule;
  
  // Parse dos novos campos JSON (estoque e substituições)
  const usedStock = activePlan.usedStock ? (typeof activePlan.usedStock === 'string' ? JSON.parse(activePlan.usedStock) : activePlan.usedStock) : null;
  const remainingStock = activePlan.remainingStock ? (typeof activePlan.remainingStock === 'string' ? JSON.parse(activePlan.remainingStock) : activePlan.remainingStock) : null;
  const substitutions = activePlan.substitutions ? (typeof activePlan.substitutions === 'string' ? JSON.parse(activePlan.substitutions) : activePlan.substitutions) : null;
  
  // Dados nutricionais (podem não existir em planos antigos)
  const planData = {
    totalKcal: activePlan.totalKcal,
    avgKcalPerServing: activePlan.avgKcalPerServing,
  };

  // Agrupa lista de compras por categoria
  const groupedShopping = shoppingList.reduce((acc: any, item: any) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {});

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-gradient-to-br from-primary/5 via-accent/5 to-background">

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto space-y-8">
          {/* PATCH 7.9.0: Banner de plano anônimo */}
          {(() => {
            // Verificar se é plano anônimo checando se sessionId é 0 (placeholder)
            const isAnonymous = activePlan?.sessionId === 0;
            if (!isAnonymous) return null;
            
            return (
              <Alert className="border-amber-300 bg-amber-50 text-amber-900">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  <div className="font-semibold">Plano de teste (não salvo)</div>
                  <div className="text-xs mt-1 mb-2">
                    Para salvar, editar e gerar novos planos, crie sua conta grátis.
                  </div>
                  <Button size="sm" onClick={() => setSignupModalOpen(true)} className="mt-2">
                    Criar conta agora
                  </Button>
                </AlertDescription>
              </Alert>
            );
          })()}

          {/* Header do Plano */}
          <div className="text-center space-y-4">
            <div className="flex flex-col items-center gap-3">
              <h1 className="text-4xl font-bold">Seu Plano Semanal</h1>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <p className="text-lg text-muted-foreground">
                  Plano criado em {new Date(plan.createdAt).toLocaleDateString("pt-BR")}
                </p>
                {/* PATCH 7.3.1: Badge de modo do plano */}
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-emerald-100 text-emerald-800 cursor-help">
                        {planModeLabel}
                      </span>
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <p>{planModeDescription}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
            </div>
            <div className="flex justify-center gap-4">
              <Button
                size="lg"
                className="gap-2"
                onClick={() => {
                  if (!planId) return;
                  exportPDF.mutate(
                    { planId: parseInt(planId) },
                    {
                      onSuccess: (data) => {
                        // Cria um blob com o HTML e faz download
                        const blob = new Blob([data.html], { type: 'text/html' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `plano-marmitas-${planId}.html`;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);
                        
                        // Também abre em nova janela para impressão
                        const printWindow = window.open("", "_blank");
                        if (printWindow) {
                          printWindow.document.write(data.html);
                          printWindow.document.close();
                          printWindow.focus();
                        }
                      },
                    }
                  );
                }}
                disabled={exportPDF.isPending}
              >
                {exportPDF.isPending ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Download className="w-5 h-5" />
                )}
                Baixar PDF
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="gap-2"
                onClick={() => {
                  if (whatsappData?.text) {
                    const encodedText = encodeURIComponent(whatsappData.text);
                    window.open(`https://wa.me/?text=${encodedText}`, "_blank");
                  }
                }}
                disabled={!whatsappData}
              >
                <ShoppingCart className="w-5 h-5" />
                Enviar Tudo para WhatsApp
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="gap-2"
                onClick={() => {
                  // Exportar apenas lista de compras
                  const shoppingText = `*🛍️ Lista de Compras - Planna*\n\n${shoppingList.map((cat: any) => 
                    `*${cat.category}*\n${cat.items.map((item: any) => `• ${item.quantity} ${item.unit} de ${item.item}`).join('\n')}`
                  ).join('\n\n')}`;
                  const encodedText = encodeURIComponent(shoppingText);
                  window.open(`https://wa.me/?text=${encodedText}`, "_blank");
                }}
              >
                <ShoppingCart className="w-5 h-5" />
                Lista de Compras (WhatsApp)
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="gap-2"
                onClick={() => setShareModalOpen(true)}
              >
                <Share2 className="w-5 h-5" />
                Compartilhar
              </Button>
            </div>
          </div>

          {/* PATCH 7.4.0: Card de Preferências Aplicadas */}
          <section className="mt-6">
            <div className="border rounded-lg p-4 bg-muted/40">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  ⚙️ Parâmetros do Plano
                </h2>
                <p className="text-xs text-muted-foreground">
                  Configurações usadas para gerar este plano
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 text-sm">
                {/* Dieta / Perfil nutricional */}
                <div className="space-y-0.5">
                  <p className="text-xs text-muted-foreground">🥗 Dieta</p>
                  <p className="font-medium">{appliedDietSummary}</p>
                </div>

                {/* Modo de planejamento */}
                <div className="space-y-0.5">
                  <p className="text-xs text-muted-foreground">🔄 Modo</p>
                  <p className="font-medium">{planModeLabel}</p>
                </div>

                {/* Nível de habilidade */}
                <div className="space-y-0.5">
                  <p className="text-xs text-muted-foreground">👨‍🍳 Nível</p>
                  <p className="font-medium">
                    {activePlan?.skillLevel === "beginner" && "Iniciante"}
                    {activePlan?.skillLevel === "intermediate" && "Intermediário"}
                    {activePlan?.skillLevel === "advanced" && "Avançado"}
                    {!activePlan?.skillLevel && "Não definido"}
                  </p>
                </div>

                {/* Porções planejadas */}
                <div className="space-y-0.5">
                  <p className="text-xs text-muted-foreground">🍲 Porções</p>
                  <p className="font-medium">
                    {appliedServings ?? "Não definido"}
                  </p>
                </div>

                {/* Variedades de pratos */}
                <div className="space-y-0.5">
                  <p className="text-xs text-muted-foreground">🍽️ Variedades</p>
                  <p className="font-medium">
                    {appliedVarieties ?? "Não definido"}
                  </p>
                </div>

                {/* Tempo estimado */}
                <div className="space-y-0.5">
                  <p className="text-xs text-muted-foreground">⏱️ Tempo estimado</p>
                  <p className="font-medium">
                    {activePlan?.totalPlanTime
                      ? `${Math.round(activePlan.totalPlanTime / 60)}h${activePlan.totalPlanTime % 60 > 0 ? (activePlan.totalPlanTime % 60).toString().padStart(2, '0') + 'min' : ''} (margem: ~30-50%)`
                      : appliedTime
                      ? `~${Math.round(appliedTime / 60)}h (solicitado)`
                      : "Não informado"}
                  </p>
                </div>

                {/* Novos ingredientes */}
                <div className="space-y-0.5">
                  <p className="text-xs text-muted-foreground">🛍️ Novos ingredientes</p>
                  <p className="font-medium">
                    {appliedAllowNewIngredients
                      ? "Permitidos além do estoque"
                      : "Usar apenas o que já tem"}
                  </p>
                </div>

                {/* PATCH 7.5.0: Ingredientes evitados */}
                <div className="space-y-0.5">
                  <p className="text-xs text-muted-foreground">🚫 Ingredientes evitados</p>
                  <p className="font-medium">
                    {appliedExclusions.length > 0
                      ? appliedExclusions.join(", ")
                      : "Nenhum cadastrado"}
                  </p>
                </div>

                {/* PATCH 7.5.0: Ingredientes favoritos */}
                <div className="space-y-0.5">
                  <p className="text-xs text-muted-foreground">⭐ Favoritos</p>
                  <p className="font-medium">
                    {appliedFavorites.length > 0
                      ? appliedFavorites.join(", ")
                      : "Nenhum destaque"}
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Misturas e Porções - Pedidas vs Geradas */}
          {(plan.requestedVarieties || plan.requestedServings) && (
            <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-800">
                  🎯 Resumo do Plano
                </CardTitle>
                <CardDescription>
                  Comparação entre o que foi pedido e o que foi gerado
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {/* Misturas */}
                  {plan.requestedVarieties && (
                    <div className="bg-white/60 p-4 rounded-lg">
                      <div className="text-sm text-muted-foreground mb-1">Misturas (Variedades)</div>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-blue-700">
                          {dishes.length}
                        </span>
                        <span className="text-sm text-muted-foreground">/</span>
                        <span className="text-lg text-muted-foreground">
                          {plan.requestedVarieties} pedidas
                        </span>
                      </div>
                      {dishes.length !== plan.requestedVarieties && (
                        <p className="text-xs text-amber-600 mt-2">
                          ⚠️ O sistema ajustou o número de misturas
                        </p>
                      )}
                    </div>
                  )}
                  
                  {/* Porções */}
                  {plan.requestedServings && (
                    <div className="bg-white/60 p-4 rounded-lg">
                      <div className="text-sm text-muted-foreground mb-1">Porções Totais</div>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-blue-700">
                          {dishes.reduce((sum: number, dish: any) => sum + dish.servings, 0)}
                        </span>
                        <span className="text-sm text-muted-foreground">/</span>
                        <span className="text-lg text-muted-foreground">
                          {plan.requestedServings} pedidas
                        </span>
                      </div>
                      {dishes.reduce((sum: number, dish: any) => sum + dish.servings, 0) < plan.requestedServings && (
                        <p className="text-xs text-amber-600 mt-2">
                          ⚠️ O sistema gerou menos porções que o solicitado
                        </p>
                      )}
                    </div>
                  )}
                </div>
                

              </CardContent>
            </Card>
          )}

          {/* Ajustes Automáticos */}
          {plan.adjustmentReason && plan.adjustmentReason.trim().length > 0 ? (
            <div className="border rounded-xl bg-yellow-50 border-yellow-300 p-4 mt-6">
              <h2 className="text-lg font-semibold text-yellow-700 mb-1">
                ⚠️ Ajustes automáticos
              </h2>
              <p className="text-sm text-yellow-800 leading-relaxed whitespace-pre-line">
                {plan.adjustmentReason}
              </p>
            </div>
          ) : (
            <div className="border rounded-xl bg-gray-50 border-gray-200 p-4 mt-6">
              <h2 className="text-lg font-semibold text-gray-700 mb-1">
                ℹ️ Ajustes do Plano
              </h2>
              <p className="text-sm text-gray-600">
                Plano gerado conforme solicitado, sem ajustes automáticos.
              </p>
            </div>
          )}

          {/* ESTOQUE UTILIZADO */}
          {usedStock && Object.keys(usedStock).length > 0 && (
            <div className="border rounded-xl bg-blue-50 border-blue-300 p-4 mt-6">
              <h2 className="text-lg font-semibold text-blue-700 mb-2">
                📦 Estoque utilizado
              </h2>
              <ul className="text-sm text-blue-900 space-y-1">
                {Object.entries(usedStock).map(([item, qtd]) => (
                  <li key={item}>
                    <span className="font-medium">{item}:</span> {String(qtd)}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* ESTOQUE REMANESCENTE */}
          {remainingStock && Object.keys(remainingStock).length > 0 && (
            <div className="border rounded-xl bg-green-50 border-green-300 p-4 mt-4">
              <h2 className="text-lg font-semibold text-green-700 mb-2">
                🟢 Estoque remanescente
              </h2>
              <ul className="text-sm text-green-900 space-y-1">
                {Object.entries(remainingStock).map(([item, qtd]) => (
                  <li key={item}>
                    <span className="font-medium">{item}:</span> {String(qtd)}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* SUBSTITUIÇÕES */}
          {substitutions && substitutions.length > 0 && (
            <div className="border rounded-xl bg-orange-50 border-orange-300 p-4 mt-4">
              <h2 className="text-lg font-semibold text-orange-700 mb-2">
                🔁 Substituições automáticas
              </h2>
              <ul className="text-sm text-orange-900 space-y-1">
                {substitutions.map((sub: any, idx: number) => (
                  <li key={idx}>
                    <span className="font-medium">{sub.original}</span> → {sub.replacement}
                  </li>
                ))}
              </ul>
            </div>
          )}


          {/* Resumo Nutricional */}
          {(planData.totalKcal || planData.avgKcalPerServing) && (
            <Card className="bg-gradient-to-br from-orange-50 to-amber-50 border-orange-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-800">
                  🍎 Informações Nutricionais
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {planData.totalKcal && (
                    <div className="bg-white/60 p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground">Calorias Totais do Plano</p>
                      <p className="text-3xl font-bold text-orange-600">
                        {Math.round(planData.totalKcal).toLocaleString()} kcal
                      </p>
                    </div>
                  )}
                  {planData.avgKcalPerServing && (
                    <div className="bg-white/60 p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground">Média por Porção</p>
                      <p className="text-3xl font-bold text-orange-600">
                        {Math.round(planData.avgKcalPerServing)} kcal
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Aviso de Tempo Insuficiente */}
          {plan.timeFits === false && plan.availableTime && plan.totalPlanTime && (
            <Alert className="bg-yellow-50 border-yellow-200">
              <AlertCircle className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800">
                <strong>⚠️ Atenção: Tempo Apertado</strong>
                <p className="mt-2">
                  Com o tempo que você informou ({plan.availableTime}h), este plano pode ficar apertado. 
                  O tempo estimado é de <strong>{Math.round(plan.totalPlanTime / 60)}h{plan.totalPlanTime % 60 > 0 ? `${plan.totalPlanTime % 60}min` : ''}</strong>.
                </p>
                <p className="mt-2">
                  <strong>Considere:</strong>
                </p>
                <ul className="list-disc list-inside mt-1 space-y-1">
                  <li>Reduzir o número de marmitas</li>
                  <li>Simplificar as receitas</li>
                  <li>Cozinhar em mais de uma sessão</li>
                </ul>
              </AlertDescription>
            </Alert>
          )}

          {/* Cardápio */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ChefHat className="w-6 h-6" />
                Cardápio da Semana
              </CardTitle>
              <CardDescription>
                {dishes.length} pratos base para suas marmitas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {dishes.map((dish: any, index: number) => (
                <div key={index} className="border-b last:border-0 pb-6 last:pb-0">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="text-xl font-semibold">{dish.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {dish.servings} porções • {dish.prepTime} min
                        {dish.kcalPerServing && (
                          <span className="ml-2 font-medium text-orange-600">
                            • {Math.round(dish.kcalPerServing)} kcal/porção
                          </span>
                        )}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          regenerateDish.mutate({
                            planId: parseInt(planId || "0"),
                            dishIndex: index,
                          })
                        }
                        disabled={regenerateDish.isPending && regenerateDish.variables?.dishIndex === index}
                        className="gap-1"
                      >
                        {regenerateDish.isPending && regenerateDish.variables?.dishIndex === index ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            Regenerando...
                          </>
                        ) : (
                          <>
                            <RefreshCw className="w-4 h-4" />
                            Regenerar
                          </>
                        )}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleFeedback(dish.name, "liked")}
                        className="gap-1"
                      >
                        <ThumbsUp className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleFeedback(dish.name, "disliked")}
                        className="gap-1"
                      >
                        <ThumbsDown className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium mb-2 text-sm">Ingredientes:</h4>
                       <ul className="text-sm space-y-1 text-muted-foreground">
                        {dish.ingredients.map((ing: any, i: number) => (
                          <li key={i}>
                            • {ing.name}: {ing.quantity} {ing.unit}
                            {ing.kcal && (
                              <span className="text-xs text-orange-600 ml-1">
                                ({Math.round(ing.kcal)} kcal)
                              </span>
                            )}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2 text-sm">Modo de preparo:</h4>
                      <ol className="text-sm space-y-1 text-muted-foreground list-decimal list-inside">
                        {dish.steps.map((step: string, i: number) => (
                          <li key={i}>{step}</li>
                        ))}
                      </ol>
                    </div>
                  </div>

                  {dish.variations && dish.variations.length > 0 && (
                    <div className="mt-3 bg-accent/10 p-3 rounded-lg">
                      <h4 className="font-medium text-sm mb-2">💡 Variações:</h4>
                      <ul className="text-sm space-y-1 text-muted-foreground">
                        {dish.variations.map((variation: string, i: number) => (
                          <li key={i}>• {variation}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Indicador de regeneração */}
                  {regenerateDish.isSuccess && regenerateDish.variables?.dishIndex === index && (
                    <div className="mt-3 flex items-center gap-3 text-sm text-green-600">
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4" />
                        <span>✓ Prato regenerado com sucesso</span>
                      </div>
                      {lastDiff && diffDishIndex === index && (
                        <button
                          type="button"
                          className="text-xs underline decoration-dotted underline-offset-2"
                          onClick={() => setDiffDialogOpen(true)}
                        >
                          Ver mudanças
                        </button>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Lista de Compras */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <ShoppingCart className="w-6 h-6" />
                    Lista de Compras
                  </CardTitle>
                  <CardDescription>
                    Tudo que você precisa comprar, organizado por seção
                  </CardDescription>
                </div>
                {/* PATCH 8.6.0: Botão de regeneração */}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => requireAuthForAction(handleRegenerateShoppingList)}
                  disabled={regenerateShoppingList.isPending}
                  className="gap-2"
                >
                  {regenerateShoppingList.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Regenerando...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-4 h-4" />
                      Regenerar Lista
                    </>
                  )}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                {Object.entries(groupedShopping).map(([category, items]: [string, any]) => (
                  <div key={category}>
                    <h3 className="font-semibold mb-3 text-primary">{category}</h3>
                    <ul className="space-y-2">
                      {items.map((item: any, index: number) => {
                        const itemKey = `${category}-${item.item}-${index}`;
                        const isChecked = checkedItems.has(itemKey);
                        return (
                          <li key={index}>
                            <button
                              onClick={() => toggleCheck(itemKey)}
                              className={`flex items-center gap-3 w-full text-left p-2 rounded hover:bg-muted/50 transition-colors ${
                                isChecked ? "line-through text-muted-foreground" : ""
                              }`}
                            >
                              <div
                                className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                                  isChecked
                                    ? "bg-primary border-primary"
                                    : "border-muted-foreground"
                                }`}
                              >
                                {isChecked && <Check className="w-3 h-3 text-primary-foreground" />}
                              </div>
                              <span className="flex-1">
                                {item.item} - {item.quantity} {item.unit}
                              </span>
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Roteiro de Preparo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-6 h-6" />
                Roteiro de Preparo Otimizado
              </CardTitle>
              <CardDescription>
                Siga esta ordem para preparar tudo de forma eficiente
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {prepSchedule
                  .sort((a: any, b: any) => a.order - b.order)
                  .map((step: any, index: number) => {
                    const isExpanded = expandedSteps.has(step.order);
                    const hasDetails = step.details && step.details.length > 0;
                    return (
                      <div
                        key={index}
                        className="bg-muted/30 rounded-lg overflow-hidden border border-border/50"
                      >
                        <button
                          onClick={() => hasDetails && toggleStep(step.order)}
                          className={`flex items-start gap-4 p-4 w-full text-left transition-colors ${
                            hasDetails ? "hover:bg-muted/50 cursor-pointer" : "cursor-default"
                          }`}
                        >
                          <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-semibold flex-shrink-0">
                            {step.order}
                          </div>
                          <div className="flex-1">
                            <p className="font-medium">{step.action}</p>
                            <p className="text-sm text-muted-foreground">
                              {step.duration} min
                              {step.parallel && " • Pode fazer em paralelo"}
                            </p>
                            {hasDetails && (
                              <p className="text-xs text-primary mt-1">
                                Clique para ver detalhes →
                              </p>
                            )}
                          </div>
                          {hasDetails && (
                            <ChevronDown
                              className={`w-5 h-5 text-muted-foreground transition-transform ${
                                isExpanded ? "rotate-180" : ""
                              }`}
                            />
                          )}
                        </button>

                        {hasDetails && isExpanded && (
                          <div className="px-4 pb-4 space-y-3 border-t border-border/50 pt-4 bg-background/50">
                            <div>
                              <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                                👨‍🍳 Passo a passo detalhado:
                              </h4>
                              <ol className="space-y-2 text-sm">
                                {step.details.map((detail: string, i: number) => (
                                  <li key={i} className="flex items-start gap-2">
                                    <span className="font-semibold text-primary min-w-[1.5rem]">
                                      {i + 1}.
                                    </span>
                                    <span className="text-muted-foreground">{detail}</span>
                                  </li>
                                ))}
                              </ol>
                            </div>

                            {step.tips && (
                              <div className="bg-accent/20 p-3 rounded-lg">
                                <h4 className="font-semibold text-sm mb-1 flex items-center gap-2">
                                  <Lightbulb className="w-4 h-4 text-yellow-600" />
                                  Dica:
                                </h4>
                                <p className="text-sm text-muted-foreground">{step.tips}</p>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
              </div>
            </CardContent>
          </Card>

          {/* Histórico de versões */}
          <section className="mt-8">
            <h2 className="text-lg font-semibold mb-3">Histórico de versões do plano</h2>

            {isLoadingVersions && (
              <p className="text-sm text-muted-foreground">Carregando histórico...</p>
            )}

            {!isLoadingVersions && (!versions || versions.length === 0) && (
              <p className="text-sm text-muted-foreground">
                Ainda não há versões registradas para este plano.
              </p>
            )}

            {!isLoadingVersions && versions && versions.length > 0 && (
              <div className="border rounded-lg p-3 space-y-2">
                {versions.map((v, index) => {
                  const isCurrent = index === 0; // primeira da lista é a mais recente
                  const createdAt =
                    v.createdAt instanceof Date
                      ? v.createdAt
                      : new Date(v.createdAt as any);

                  return (
                    <div
                      key={v.id}
                      className="flex items-center justify-between text-sm"
                    >
                      <div className="flex flex-col">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">Versão {v.version}</span>
                          {isCurrent && (
                            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
                              Atual
                            </span>
                          )}
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {format(createdAt, "dd/MM/yyyy HH:mm", { locale: ptBR })}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        {!isCurrent && (
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={rollbackToVersion.isPending}
                            onClick={() => {
                              const confirmRollback = window.confirm(
                                `Tem certeza que deseja reverter o plano para a versão ${v.version}?`
                              );
                              if (!confirmRollback) return;

                              rollbackToVersion.mutate(
                                { planId: numericPlanId, version: v.version },
                                {
                                  onSuccess: () => {
                                    refetchVersions();
                                  },
                                }
                              );
                            }}
                          >
                            {rollbackToVersion.isPending ? "Revertendo..." : "Reverter"}
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          {/* PATCH 8.1.0: Bloco de compartilhamento reforçado */}
          <section className="mt-8 border rounded-lg p-4 bg-muted/40">
            <h2 className="text-sm font-semibold mb-2 flex items-center gap-2">
              🤝 Compartilhe seu plano
            </h2>
            {!isAuthenticated ? (
              <p className="text-sm text-muted-foreground mb-3">
                Curtiu o plano de teste? Envie para alguém que também precisa organizar as marmitas da semana.
              </p>
            ) : (
              <p className="text-sm text-muted-foreground mb-3">
                Compartilhe este plano com alguém para facilitar a organização das marmitas em dupla.
              </p>
            )}

            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShareModalOpen(true)}
              >
                Compartilhar link
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  // Gerar link de compartilhamento e abrir WhatsApp
                  const origin = window.location.origin;
                  const shareUrl = `${origin}/plan/${planId}?src=share_whatsapp`;
                  const text = encodeURIComponent(`Olha o plano de marmitas que montei no Planna:`);
                  const url = encodeURIComponent(shareUrl);
                  window.open(`https://wa.me/?text=${text}%20${url}`, "_blank");
                }}
              >
                Compartilhar no WhatsApp
              </Button>
            </div>
          </section>

          {/* CTA */}
          <div className="text-center py-8">
            <Button 
              size="lg" 
              onClick={() => requireAuthForAction(() => window.location.href = '/planner')}
            >
              Criar Outro Plano
            </Button>
          </div>
        </div>
        </main>
        <AuthModal
          open={authModalOpen}
          onOpenChange={setAuthModalOpen}
          defaultMode={authMode}
        />
        <ShareModal
          open={shareModalOpen}
          onClose={() => setShareModalOpen(false)}
          planId={parseInt(planId || "0")}
        />
        <DishDiffDialog
          open={diffDialogOpen}
          onOpenChange={setDiffDialogOpen}
          oldDish={lastDiff?.oldDish ?? null}
          newDish={lastDiff?.newDish ?? null}
        />
        {/* PATCH 8.6.0: Modal de comparação de lista de compras */}
        <ShoppingListDiffDialog
          open={shoppingListDiffDialogOpen}
          onOpenChange={setShoppingListDiffDialogOpen}
          oldList={lastShoppingListDiff?.oldList ?? []}
          newList={lastShoppingListDiff?.newList ?? []}
        />
        <SignupModal
          open={signupModalOpen}
          onOpenChange={setSignupModalOpen}
        />
      </div>
    </DashboardLayout>
  );
}

