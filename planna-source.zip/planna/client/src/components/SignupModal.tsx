import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { getLastSource } from "@/lib/source"; // PATCH 8.1.0

export function SignupModal({
  open,
  onOpenChange,
  onSuccess,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [verificationCode, setVerificationCode] = useState("");
  const [userId, setUserId] = useState<number | null>(null);
  const [mode, setMode] = useState<"register" | "verify">("register");

  const register = trpc.auth.registerLocal.useMutation({
    onSuccess: (data) => {
      setUserId(data.userId);
      toast.success("Código de verificação enviado para seu email!");
      setMode("verify");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao criar conta");
    },
  });

  const verify = trpc.auth.verifyEmailCode.useMutation({
    onSuccess: () => {
      toast.success("Conta criada com sucesso!");
      onOpenChange(false);
      onSuccess?.();
      window.location.reload();
    },
    onError: (error) => {
      toast.error(error.message || "Código inválido");
    },
  });

  const resend = trpc.auth.resendVerificationCode.useMutation({
    onSuccess: () => {
      toast.success("Código reenviado!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao reenviar código");
    },
  });

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    // PATCH 8.1.0: Incluir source no cadastro
    const source = getLastSource() || "unknown";
    register.mutate({ name, email, password, source });
  };

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId) {
      toast.error("Erro: ID de usuário não encontrado");
      return;
    }
    verify.mutate({ userId, code: verificationCode });
  };

  const handleResend = () => {
    if (!userId) {
      toast.error("Erro: ID de usuário não encontrado");
      return;
    }
    resend.mutate({ userId });
  };

  const handleBack = () => {
    setMode("register");
    setVerificationCode("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {mode === "register" ? "Crie sua conta grátis" : "Confirme seu email"}
          </DialogTitle>
        </DialogHeader>

        {mode === "register" ? (
          <>
            <p className="text-sm text-muted-foreground mb-3">
              Pra salvar seu plano e continuar usando o Planna, crie sua conta grátis.
            </p>
            <form onSubmit={handleRegister} className="space-y-3">
              <Input
                placeholder="Nome"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
              <Input
                type="email"
                placeholder="E-mail"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <Input
                type="password"
                placeholder="Senha"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />

              <Button type="submit" className="w-full" disabled={register.isPending}>
                {register.isPending ? "Criando conta..." : "Criar conta grátis"}
              </Button>
            </form>
          </>
        ) : (
          <>
            <p className="text-sm text-muted-foreground mb-3">
              Digite o código de 6 dígitos que enviamos para <strong>{email}</strong>
            </p>
            <form onSubmit={handleVerify} className="space-y-3">
              <Input
                placeholder="000000"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                maxLength={6}
                className="text-center text-2xl tracking-widest font-mono"
                required
              />

              <Button type="submit" className="w-full" disabled={verify.isPending}>
                {verify.isPending ? "Verificando..." : "Confirmar código"}
              </Button>

              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={handleBack}
                  disabled={verify.isPending || resend.isPending}
                >
                  Voltar
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={handleResend}
                  disabled={verify.isPending || resend.isPending}
                >
                  {resend.isPending ? "Enviando..." : "Reenviar código"}
                </Button>
              </div>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
