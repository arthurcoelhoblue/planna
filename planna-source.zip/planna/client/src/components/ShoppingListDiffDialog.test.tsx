/**
 * PATCH 8.6.0: Testes para ShoppingListDiffDialog
 * Valida renderização e lógica de comparação de listas
 */

import { describe, it, expect } from "vitest";
import { ShoppingListDiffDialog } from "./ShoppingListDiffDialog";

describe("ShoppingListDiffDialog", () => {
  const oldList = [
    {
      category: "Hortifruti",
      items: [
        { item: "Tomate", quantity: "500", unit: "g" },
        { item: "Cebola", quantity: "3", unit: "unidades" },
      ],
    },
    {
      category: "Açougue",
      items: [
        { item: "Frango", quantity: "1", unit: "kg" },
      ],
    },
  ];

  const newList = [
    {
      category: "Hortifruti",
      items: [
        { item: "Tomate", quantity: "500", unit: "g" }, // Mantido
        { item: "Alho", quantity: "2", unit: "dentes" }, // Adicionado
      ],
    },
    {
      category: "Açougue",
      items: [
        { item: "Frango", quantity: "1", unit: "kg" }, // Mantido
      ],
    },
  ];

  it("deve calcular itens adicionados corretamente", () => {
    // Simular normalização de itens
    const normalizeItem = (item: any) => {
      return `${item.item}-${item.quantity}-${item.unit}`.toLowerCase();
    };

    const oldItems = new Set<string>();
    oldList.forEach((cat) => {
      cat.items?.forEach((item: any) => {
        oldItems.add(normalizeItem(item));
      });
    });

    const newItems = new Set<string>();
    newList.forEach((cat) => {
      cat.items?.forEach((item: any) => {
        newItems.add(normalizeItem(item));
      });
    });

    const added: string[] = [];
    newItems.forEach((key) => {
      if (!oldItems.has(key)) {
        added.push(key);
      }
    });

    // Alho foi adicionado
    expect(added.length).toBe(1);
    expect(added[0]).toContain("alho");
  });

  it("deve calcular itens removidos corretamente", () => {
    const normalizeItem = (item: any) => {
      return `${item.item}-${item.quantity}-${item.unit}`.toLowerCase();
    };

    const oldItems = new Set<string>();
    oldList.forEach((cat) => {
      cat.items?.forEach((item: any) => {
        oldItems.add(normalizeItem(item));
      });
    });

    const newItems = new Set<string>();
    newList.forEach((cat) => {
      cat.items?.forEach((item: any) => {
        newItems.add(normalizeItem(item));
      });
    });

    const removed: string[] = [];
    oldItems.forEach((key) => {
      if (!newItems.has(key)) {
        removed.push(key);
      }
    });

    // Cebola foi removida
    expect(removed.length).toBe(1);
    expect(removed[0]).toContain("cebola");
  });

  it("deve calcular itens mantidos corretamente", () => {
    const normalizeItem = (item: any) => {
      return `${item.item}-${item.quantity}-${item.unit}`.toLowerCase();
    };

    const oldItems = new Set<string>();
    oldList.forEach((cat) => {
      cat.items?.forEach((item: any) => {
        oldItems.add(normalizeItem(item));
      });
    });

    const newItems = new Set<string>();
    newList.forEach((cat) => {
      cat.items?.forEach((item: any) => {
        newItems.add(normalizeItem(item));
      });
    });

    const kept: string[] = [];
    newItems.forEach((key) => {
      if (oldItems.has(key)) {
        kept.push(key);
      }
    });

    // Tomate e Frango foram mantidos
    expect(kept.length).toBe(2);
  });

  it("deve validar estrutura dos itens", () => {
    // Validar que todos os itens têm as propriedades necessárias
    const allItems = [...oldList, ...newList];
    
    allItems.forEach((category) => {
      expect(category).toHaveProperty("category");
      expect(category).toHaveProperty("items");
      expect(Array.isArray(category.items)).toBe(true);

      category.items.forEach((item: any) => {
        expect(item).toHaveProperty("item");
        expect(item).toHaveProperty("quantity");
        expect(item).toHaveProperty("unit");
      });
    });
  });

  it("deve calcular total de itens na nova lista", () => {
    let totalItems = 0;
    newList.forEach((cat) => {
      totalItems += cat.items.length;
    });

    // Total de itens na nova lista (Tomate, Alho, Frango = 3)
    expect(totalItems).toBe(3);
  });




});
